"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.extractGroupCode = extractGroupCode;exports.isYbGroupChat = isYbGroupChat;exports.json = json;exports.msgBodyDesensitization = msgBodyDesensitization;exports.text = text;exports.textDesensitization = textDesensitization; // Session check
/**
 * Check if the current session is a Yuanbao channel group chat.
 *
 * Returns true only when both conditions are met:
 * 1. sessionKey contains `:group:` (group chat)
 * 2. messageChannel is `yuanbao`
 */
function isYbGroupChat(ctx) {
  if (ctx.messageChannel === "yuanbao") {
    return ctx.sessionKey?.includes("yuanbao:group:") ?? false;
  }
  return false;
}
// Session parsing
/**
 * Extract groupCode from a Yuanbao group chat sessionKey.
 *
 * sessionKey format: `agent:<agentId>:yuanbao:group:<groupCode>`
 * Matches `yuanbao:group:` and returns the trailing part as groupCode.
 */
function extractGroupCode(sessionKey) {
  const prefix = "yuanbao:group:";
  const idx = sessionKey.indexOf(prefix);
  if (idx === -1) {
    return "";
  }
  return sessionKey.slice(idx + prefix.length);
}
// MCP response builders
/**
 * Build a plain-text MCP content response.
 */
function text(t) {
  return { content: [{ type: "text", text: t }] };
}
/**
 * Build a JSON MCP content response.
 *
 * Serializes data as formatted JSON text, with raw data preserved in `details`.
 */
function json(data) {
  return {
    content: [{ type: "text", text: JSON.stringify(data, null, 2) }],
    details: data
  };
}
// Log desensitization
/**
 * Desensitize a MsgBody array for safe logging.
 * Text messages (TIMTextElem) are masked; other types retain original structure for debugging.
 */function msgBodyDesensitization(msg_body) {
  let log = "";
  msg_body.forEach((item) => {
    if (item.msg_type === "TIMTextElem") {
      log += `[text:${textDesensitization(item.msg_content?.text ?? "") ?? "-"}]`;
    } else
    {
      log += `[${item.msg_type}:${JSON.stringify(item.msg_content)}]`;
    }
  });
  return log;
}
/**
 * Desensitize text by keeping first and last 2 chars, masking the middle.
 * Returns text as-is when length <= 5.
 */function textDesensitization(text) {
  if (text.length > 5) {
    return `${text.slice(0, 2)}***(${text.length - 4})***${text.slice(-2)}`;
  }
  return text;
} /* v9-535d936272c99325 */
