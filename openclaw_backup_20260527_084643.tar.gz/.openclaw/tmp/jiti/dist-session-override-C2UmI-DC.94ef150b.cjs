"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = resolveSessionAuthProfileOverride;exports.t = clearSessionAuthProfileOverride;var _lazyPromiseDjskx0qC = require("./lazy-promise-Djskx0qC.js");
var _storeBMQkMM4l = require("./store-BMQkMM4l.js");
var _sourceCheckBMw3fGLx = require("./source-check-BMw3fGLx.js");
var _orderDJrj83KE = require("./order-DJrj83KE.js");
require("./usage-DbhCKKrr.js");function _interopRequireWildcard(e, t) {if ("function" == typeof WeakMap) var r = new WeakMap(),n = new WeakMap();return (_interopRequireWildcard = function (e, t) {if (!t && e && e.__esModule) return e;var o,i,f = { __proto__: null, default: e };if (null === e || "object" != typeof e && "function" != typeof e) return f;if (o = t ? n : r) {if (o.has(e)) return o.get(e);o.set(e, f);}for (const t in e) "default" !== t && {}.hasOwnProperty.call(e, t) && ((i = (o = Object.defineProperty) && Object.getOwnPropertyDescriptor(e, t)) && (i.get || i.set) ? o(f, t, i) : f[t] = e[t]);return f;})(e, t);}
//#region src/agents/auth-profiles/session-override.ts
const sessionStoreRuntimeLoader = (0, _lazyPromiseDjskx0qC.t)(() => Promise.resolve().then(() => jitiImport("./store.runtime.js").then((m) => _interopRequireWildcard(m))));
function loadSessionStoreRuntime() {
  return sessionStoreRuntimeLoader.load();
}
function isProfileForProvider(params) {
  const entry = params.store.profiles[params.profileId];
  if (entry) {
    if (!entry.provider) return false;
    return params.providers.some((provider) => (0, _orderDJrj83KE.n)({
      cfg: params.cfg,
      provider,
      credential: entry
    }));
  }
  return params.providers.some((provider) => (0, _orderDJrj83KE.t)({
    cfg: params.cfg,
    provider,
    profileId: params.profileId
  }));
}
function uniqueProviders(provider, acceptedProviderIds) {
  const providers = /* @__PURE__ */new Set();
  const push = (value) => {
    const normalized = value?.trim();
    if (normalized) providers.add(normalized);
  };
  (acceptedProviderIds && acceptedProviderIds.length > 0 ? acceptedProviderIds : [provider]).forEach(push);
  return [...providers];
}
async function clearSessionAuthProfileOverride(params) {
  const { sessionEntry, sessionStore, sessionKey, storePath } = params;
  delete sessionEntry.authProfileOverride;
  delete sessionEntry.authProfileOverrideSource;
  delete sessionEntry.authProfileOverrideCompactionCount;
  sessionEntry.updatedAt = Date.now();
  sessionStore[sessionKey] = sessionEntry;
  if (storePath) await (await loadSessionStoreRuntime()).updateSessionStore(storePath, (store) => {
    store[sessionKey] = sessionEntry;
  });
}
async function resolveSessionAuthProfileOverride(params) {
  const { cfg, provider, agentDir, sessionEntry, sessionStore, sessionKey, storePath, isNewSession } = params;
  if (!sessionEntry || !sessionStore || !sessionKey) return sessionEntry?.authProfileOverride;
  const hasConfiguredAuthProfiles = Boolean(params.cfg.auth?.profiles && Object.keys(params.cfg.auth.profiles).length > 0) || Boolean(params.cfg.auth?.order && Object.keys(params.cfg.auth.order).length > 0);
  if (!sessionEntry.authProfileOverride?.trim() && !hasConfiguredAuthProfiles && !(0, _sourceCheckBMw3fGLx.t)(agentDir)) return;
  const store = (0, _storeBMQkMM4l.n)(agentDir, { allowKeychainPrompt: false });
  const providers = uniqueProviders(provider, params.acceptedProviderIds);
  const order = [...new Set(providers.flatMap((candidateProvider) => (0, _orderDJrj83KE.i)({
    cfg,
    store,
    provider: candidateProvider
  })))];
  let current = sessionEntry.authProfileOverride?.trim();
  const source = sessionEntry.authProfileOverrideSource ?? (typeof sessionEntry.authProfileOverrideCompactionCount === "number" ? "auto" : current ? "user" : void 0);
  const currentProfileId = current;
  if (currentProfileId && !store.profiles[currentProfileId] && !providers.some((candidateProvider) => (0, _orderDJrj83KE.t)({
    cfg,
    provider: candidateProvider,
    profileId: currentProfileId
  }))) {
    await clearSessionAuthProfileOverride({
      sessionEntry,
      sessionStore,
      sessionKey,
      storePath
    });
    current = void 0;
  }
  if (current && !isProfileForProvider({
    cfg,
    providers,
    profileId: current,
    store
  })) {
    await clearSessionAuthProfileOverride({
      sessionEntry,
      sessionStore,
      sessionKey,
      storePath
    });
    current = void 0;
  }
  if (current && order.length > 0 && !order.includes(current) && source !== "user") {
    await clearSessionAuthProfileOverride({
      sessionEntry,
      sessionStore,
      sessionKey,
      storePath
    });
    current = void 0;
  }
  if (order.length === 0) return;
  const pickFirstAvailable = () => order.find((profileId) => !(0, _orderDJrj83KE.l)(store, profileId)) ?? order[0];
  const pickNextAvailable = (active) => {
    const startIndex = order.indexOf(active);
    if (startIndex < 0) return pickFirstAvailable();
    for (let offset = 1; offset <= order.length; offset += 1) {
      const candidate = order[(startIndex + offset) % order.length];
      if (!(0, _orderDJrj83KE.l)(store, candidate)) return candidate;
    }
    return order[startIndex] ?? order[0];
  };
  const compactionCount = sessionEntry.compactionCount ?? 0;
  const storedCompaction = typeof sessionEntry.authProfileOverrideCompactionCount === "number" ? sessionEntry.authProfileOverrideCompactionCount : compactionCount;
  const replacementForUnusableCurrent = current && (0, _orderDJrj83KE.l)(store, current) ? order.find((profileId) => profileId !== current && !(0, _orderDJrj83KE.l)(store, profileId)) : void 0;
  if (replacementForUnusableCurrent) current = void 0;
  if (source === "user" && current && !isNewSession) return current;
  let next = current;
  if (replacementForUnusableCurrent) next = replacementForUnusableCurrent;else
  if (isNewSession) next = current ? pickNextAvailable(current) : pickFirstAvailable();else
  if (current && compactionCount > storedCompaction) next = pickNextAvailable(current);else
  if (!current || (0, _orderDJrj83KE.l)(store, current)) next = pickFirstAvailable();
  if (!next) return current;
  if (next !== sessionEntry.authProfileOverride || sessionEntry.authProfileOverrideSource !== "auto" || sessionEntry.authProfileOverrideCompactionCount !== compactionCount) {
    sessionEntry.authProfileOverride = next;
    sessionEntry.authProfileOverrideSource = "auto";
    sessionEntry.authProfileOverrideCompactionCount = compactionCount;
    sessionEntry.updatedAt = Date.now();
    sessionStore[sessionKey] = sessionEntry;
    if (storePath) await (await loadSessionStoreRuntime()).updateSessionStore(storePath, (store) => {
      store[sessionKey] = sessionEntry;
    });
  }
  return next;
}
//#endregion /* v9-c26643d33ba1ac86 */
