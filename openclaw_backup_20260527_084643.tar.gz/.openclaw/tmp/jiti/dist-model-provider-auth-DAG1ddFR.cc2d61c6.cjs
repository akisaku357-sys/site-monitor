"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.i = warmCurrentProviderAuthState;exports.n = createProviderAuthChecker;exports.r = hasAuthForModelProvider;exports.t = clearCurrentProviderAuthState;var _providerIdZTW9Rdln = require("./provider-id-zTW9Rdln.js");
var _workspaceDefaultMMaLHGD = require("./workspace-default--mMaLHGD.js");
var _agentScopeConfigCMp71_ = require("./agent-scope-config-CMp71_27.js");
var _runtimeSnapshotDgdkBEdP = require("./runtime-snapshot-DgdkBEdP.js");
var _storeBMQkMM4l = require("./store-BMQkMM4l.js");
require("./model-selection-P-81eBKx.js");
var _modelCatalogDhWpNp = require("./model-catalog-DhWpNp70.js");
require("./workspace-DTx8zuCN.js");
require("./auth-profiles-D6NMnufG.js");
var _externalCliDiscoveryD0JQl8du = require("./external-cli-discovery-D0JQl8du.js");
var _profileListC0HtPlut = require("./profile-list-C0HtPlut.js");
var _modelAuthDbJGIrg = require("./model-auth-Db-JGIrg.js");
//#region src/agents/model-provider-auth.ts
let currentProviderAuthStates = null;
const configFingerprintCache = /* @__PURE__ */new WeakMap();
let currentProviderAuthStateGeneration = 0;
function clearCurrentProviderAuthState() {
  currentProviderAuthStates = null;
  currentProviderAuthStateGeneration += 1;
}
function resolvePreparedStateForCaller(params) {
  if (!params.states) return null;
  if (params.callerAgentId !== void 0) return params.states.get(params.callerAgentId) ?? null;
  if (!params.cfg) return null;
  return params.states.get((0, _agentScopeConfigCMp71_.c)(params.cfg)) ?? null;
}
function resolveProviderAuthConfigFingerprint(cfg) {
  if (!cfg) return null;
  const cached = configFingerprintCache.get(cfg);
  if (cached !== void 0) return cached;
  const fingerprint = (0, _runtimeSnapshotDgdkBEdP.c)(cfg);
  configFingerprintCache.set(cfg, fingerprint);
  return fingerprint;
}
async function hasAuthForModelProvider(params) {
  const provider = (0, _providerIdZTW9Rdln.r)(params.provider);
  const preparedStates = currentProviderAuthStates;
  const workspaceDir = params.workspaceDir ?? (0, _workspaceDefaultMMaLHGD.n)();
  const configFingerprint = resolveProviderAuthConfigFingerprint(params.cfg);
  const preparedState = resolvePreparedStateForCaller({
    states: preparedStates,
    cfg: params.cfg,
    callerAgentId: params.agentId
  });
  const expectedWorkspaceDir = preparedState !== null && params.cfg ? (0, _agentScopeConfigCMp71_.o)(params.cfg, preparedState.agentId) : null;
  if (preparedState !== null && configFingerprint === preparedState.configFingerprint && workspaceDir === expectedWorkspaceDir && params.discoverExternalCliAuth !== false && params.allowPluginSyntheticAuth !== false && params.env === void 0 && params.store === void 0) {
    const preparedAnswer = preparedState.providers.get(provider);
    if (preparedAnswer !== void 0) return preparedAnswer;
  }
  await new Promise((resolve) => setImmediate(resolve));
  if ((0, _modelAuthDbJGIrg.s)({
    provider,
    cfg: params.cfg,
    workspaceDir: params.workspaceDir,
    env: params.env,
    allowPluginSyntheticAuth: params.allowPluginSyntheticAuth,
    runtimeLookup: params.runtimeAuthLookup ?? params.resolveRuntimeAuthLookup?.()
  })) return true;
  const slowPathAgentDir = params.agentId && params.cfg ? (0, _agentScopeConfigCMp71_.a)(params.cfg, params.agentId) : void 0;
  if ((0, _profileListC0HtPlut.n)(params.store ?? (params.discoverExternalCliAuth === false ? (0, _storeBMQkMM4l.i)(slowPathAgentDir, { allowKeychainPrompt: false }) : (0, _storeBMQkMM4l.n)(slowPathAgentDir, { externalCli: (0, _externalCliDiscoveryD0JQl8du.r)({
      cfg: params.cfg,
      provider
    }) })), provider).length > 0) return true;
  return false;
}
function createProviderAuthChecker(params) {
  const authCache = /* @__PURE__ */new Map();
  let runtimeAuthLookup;
  return async (provider) => {
    const key = (0, _providerIdZTW9Rdln.r)(provider);
    const cached = authCache.get(key);
    if (cached !== void 0) return cached;
    const value = await hasAuthForModelProvider({
      provider: key,
      cfg: params.cfg,
      workspaceDir: params.workspaceDir,
      agentId: params.agentId,
      env: params.env,
      allowPluginSyntheticAuth: params.allowPluginSyntheticAuth,
      discoverExternalCliAuth: params.discoverExternalCliAuth,
      resolveRuntimeAuthLookup: () => runtimeAuthLookup ??= (0, _modelAuthDbJGIrg.r)({
        cfg: params.cfg,
        workspaceDir: params.workspaceDir,
        env: params.env
      })
    });
    authCache.set(key, value);
    return value;
  };
}
async function warmCurrentProviderAuthState(cfg, options = {}) {
  currentProviderAuthStateGeneration += 1;
  const ownGeneration = currentProviderAuthStateGeneration;
  const isWarmStale = () => options.isCancelled?.() === true || ownGeneration !== currentProviderAuthStateGeneration;
  const catalog = await (0, _modelCatalogDhWpNp.n)({ config: cfg });
  if (isWarmStale()) return;
  const providers = /* @__PURE__ */new Set();
  for (const entry of catalog) providers.add((0, _providerIdZTW9Rdln.r)(entry.provider));
  const providerList = [...providers];
  const configFingerprint = resolveProviderAuthConfigFingerprint(cfg) ?? "";
  const states = /* @__PURE__ */new Map();
  for (const agentId of (0, _agentScopeConfigCMp71_.n)(cfg)) {
    if (isWarmStale()) return;
    const workspaceDir = (0, _agentScopeConfigCMp71_.o)(cfg, agentId);
    const agentDir = (0, _agentScopeConfigCMp71_.a)(cfg, agentId);
    const runtimeAuthLookup = (0, _modelAuthDbJGIrg.r)({
      cfg,
      workspaceDir
    });
    const store = (0, _storeBMQkMM4l.n)(agentDir, {
      config: cfg,
      externalCli: (0, _externalCliDiscoveryD0JQl8du.i)({
        cfg,
        providers: providerList
      })
    });
    const state = /* @__PURE__ */new Map();
    for (const provider of providers) {
      if (isWarmStale()) return;
      const value = await hasAuthForModelProvider({
        provider,
        cfg,
        workspaceDir,
        agentId,
        store,
        runtimeAuthLookup
      });
      state.set(provider, value);
    }
    states.set(agentId, {
      agentId,
      configFingerprint,
      providers: state
    });
  }
  if (options.isCancelled?.() || ownGeneration !== currentProviderAuthStateGeneration) return;
  currentProviderAuthStates = states;
}
//#endregion /* v9-cae1dc2d86438609 */
