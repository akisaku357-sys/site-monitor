"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.t = buildAgentRuntimeAuthPlan;var _providerAuthAliases4jqi6Djx = require("./provider-auth-aliases-4jqi6Djx.js");
var _runtimeFVbSwiLb = require("./runtime-fVbSwiLb.js");
var _openaiCodexRoutingDwRY_VI = require("./openai-codex-routing-DwRY-_VI.js");
//#region src/agents/runtime-plan/auth.ts
const CODEX_HARNESS_AUTH_PROVIDER = "openai-codex";
const OPENAI_PROVIDER = "openai";
function resolveHarnessAuthProvider(params) {
  const harnessId = (0, _runtimeFVbSwiLb.t)(params.harnessId);
  const runtime = (0, _runtimeFVbSwiLb.t)(params.harnessRuntime);
  return harnessId === "codex" || runtime === "codex" ? CODEX_HARNESS_AUTH_PROVIDER : void 0;
}
function buildAgentRuntimeAuthPlan(params) {
  const aliasLookupParams = {
    config: params.config,
    workspaceDir: params.workspaceDir
  };
  const providerForAuth = (0, _providerAuthAliases4jqi6Djx.r)(params.provider, aliasLookupParams);
  const authProfileProviderForAuth = (0, _providerAuthAliases4jqi6Djx.r)(params.authProfileProvider ?? params.provider, aliasLookupParams);
  const harnessAuthProvider = resolveHarnessAuthProvider(params);
  const harnessProviderForAuth = harnessAuthProvider ? (0, _providerAuthAliases4jqi6Djx.r)(harnessAuthProvider, aliasLookupParams) : void 0;
  const harnessCanForwardProfile = params.allowHarnessAuthProfileForwarding !== false && harnessProviderForAuth && (harnessProviderForAuth === authProfileProviderForAuth || harnessProviderForAuth === CODEX_HARNESS_AUTH_PROVIDER && authProfileProviderForAuth === OPENAI_PROVIDER && params.authProfileMode === "api_key");
  const openAIPiCanForwardCodexProfile = (0, _openaiCodexRoutingDwRY_VI.d)({
    provider: providerForAuth,
    harnessRuntime: params.harnessRuntime,
    agentHarnessId: params.harnessId,
    authProfileProvider: authProfileProviderForAuth,
    authProfileId: params.sessionAuthProfileId,
    config: params.config,
    workspaceDir: params.workspaceDir
  });
  const canForwardProfile = !harnessProviderForAuth && providerForAuth === authProfileProviderForAuth || harnessCanForwardProfile || openAIPiCanForwardCodexProfile;
  return {
    providerForAuth,
    authProfileProviderForAuth,
    ...(harnessProviderForAuth ? { harnessAuthProvider: harnessProviderForAuth } : {}),
    ...(canForwardProfile ? { forwardedAuthProfileId: params.sessionAuthProfileId } : {}),
    ...(canForwardProfile && params.sessionAuthProfileCandidateIds?.length ? { forwardedAuthProfileCandidateIds: params.sessionAuthProfileCandidateIds } : {})
  };
}
//#endregion /* v9-0c087abba764a62f */
