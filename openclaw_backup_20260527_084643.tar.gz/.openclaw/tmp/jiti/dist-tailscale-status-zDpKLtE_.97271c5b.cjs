"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = resolveGatewayBindUrl;exports.t = resolveTailnetHostWithRunner;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _schemasDel5uzR = require("./schemas-Del5uzR8.js");
var _zodParseB4dzFRWI = require("./zod-parse-B4dzFRWI.js");
//#region src/shared/gateway-bind-url.ts
function resolveGatewayBindUrl(params) {
  const bind = params.bind ?? "loopback";
  if (bind === "custom") {
    const host = (0, _stringCoerceDyL154ka.c)(params.customBindHost);
    if (host) return {
      url: `${params.scheme}://${host}:${params.port}`,
      source: "gateway.bind=custom"
    };
    return { error: "gateway.bind=custom requires gateway.customBindHost." };
  }
  if (bind === "tailnet") {
    const host = params.pickTailnetHost();
    if (host) return {
      url: `${params.scheme}://${host}:${params.port}`,
      source: "gateway.bind=tailnet"
    };
    return { error: "gateway.bind=tailnet set, but no tailnet IP was found." };
  }
  if (bind === "lan") {
    const host = params.pickLanHost();
    if (host) return {
      url: `${params.scheme}://${host}:${params.port}`,
      source: "gateway.bind=lan"
    };
    return { error: "gateway.bind=lan set, but no private LAN IP was found." };
  }
  return null;
}
//#endregion
//#region src/shared/tailscale-status.ts
const TAILSCALE_STATUS_COMMAND_CANDIDATES = ["tailscale", "/Applications/Tailscale.app/Contents/MacOS/Tailscale"];
const TailscaleStatusSchema = (0, _schemasDel5uzR.Tn)({ Self: (0, _schemasDel5uzR.Tn)({
    DNSName: (0, _schemasDel5uzR.Rn)().optional(),
    TailscaleIPs: (0, _schemasDel5uzR.Et)((0, _schemasDel5uzR.Rn)()).optional()
  }).optional() });
function parsePossiblyNoisyStatus(raw) {
  const start = raw.indexOf("{");
  const end = raw.lastIndexOf("}");
  if (start === -1 || end <= start) return null;
  return (0, _zodParseB4dzFRWI.t)(TailscaleStatusSchema, raw.slice(start, end + 1));
}
function extractTailnetHostFromStatusJson(raw) {
  const parsed = parsePossiblyNoisyStatus(raw);
  const dns = parsed?.Self?.DNSName;
  if (dns && dns.length > 0) return dns.replace(/\.$/, "");
  const ips = parsed?.Self?.TailscaleIPs ?? [];
  return ips.length > 0 ? ips[0] ?? null : null;
}
async function resolveTailnetHostWithRunner(runCommandWithTimeout) {
  if (!runCommandWithTimeout) return null;
  for (const candidate of TAILSCALE_STATUS_COMMAND_CANDIDATES) try {
    const result = await runCommandWithTimeout([
    candidate,
    "status",
    "--json"],
    { timeoutMs: 5e3 });
    if (result.code !== 0) continue;
    const raw = result.stdout.trim();
    if (!raw) continue;
    const host = extractTailnetHostFromStatusJson(raw);
    if (host) return host;
  } catch {
    continue;
  }
  return null;
}
//#endregion /* v9-8a6129925fb0044d */
