"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.a = saveRemoteMedia;exports.i = readRemoteMediaBuffer;exports.n = void 0;exports.o = saveResponseMedia;exports.t = exports.r = void 0;var _redactOk5Q8nmw = require("./redact-ok5Q8nmw.js");
var _errorsB3ZrCRlt = require("./errors-b3ZrCRlt.js");
var _unhandledRejectionsKm9wbHjh = require("./unhandled-rejections-Km9wbHjh.js");
var _mimeDppuTPZ = require("./mime-DppuT-pZ.js");
var _fileNameR4prf02z = require("./file-name-r4prf02z.js");
var _storeRQFzzX5P = require("./store-rQFzzX5P.js");
var _fetchGuardBEAbHb5H = require("./fetch-guard-BEAbHb5H.js");
var _retryCryZAmlE = require("./retry-CryZAmlE.js");
var _readResponseWithLimitS6PVjcFB = require("./read-response-with-limit-S6PVjcFB.js");
//#region src/media/fetch.ts
const DEFAULT_FETCH_MEDIA_MAX_BYTES = exports.t = _mimeDppuTPZ.p;
var MediaFetchError = class extends Error {
  constructor(code, message, options) {
    super(message, options);
    this.code = code;
    this.status = options?.status;
    this.name = "MediaFetchError";
  }
};exports.n = MediaFetchError;
function stripQuotes(value) {
  return value.replace(/^["']|["']$/g, "");
}
function parseContentDispositionFileName(header) {
  if (!header) return;
  const starMatch = /filename\*\s*=\s*([^;]+)/i.exec(header);
  if (starMatch?.[1]) {
    const cleaned = stripQuotes(starMatch[1].trim());
    const encoded = cleaned.split("''").slice(1).join("''") || cleaned;
    try {
      return (0, _fileNameR4prf02z.t)(decodeURIComponent(encoded));
    } catch {
      return (0, _fileNameR4prf02z.t)(encoded);
    }
  }
  const match = /filename\s*=\s*([^;]+)/i.exec(header);
  if (match?.[1]) return (0, _fileNameR4prf02z.t)(stripQuotes(match[1].trim()));
}
function basenameFromUrlPathname(pathname) {
  const base = (0, _fileNameR4prf02z.t)(pathname);
  if (!base) return "";
  try {
    return decodeURIComponent(base).replace(/[\\/]/g, "_");
  } catch {
    return base;
  }
}
async function readErrorBodySnippet(res, opts) {
  try {
    return await (0, _readResponseWithLimitS6PVjcFB.t)(res, {
      maxBytes: 8 * 1024,
      maxChars: opts?.maxChars,
      chunkTimeoutMs: opts?.chunkTimeoutMs
    });
  } catch {
    return;
  }
}
function redactMediaUrl(url) {
  return (0, _redactOk5Q8nmw.s)(url);
}
async function fetchGuardedMediaResponse(options) {
  const { url, fetchImpl, requestInit, maxRedirects, timeoutMs, ssrfPolicy, lookupFn, dispatcherPolicy, dispatcherAttempts, shouldRetryFetchError, trustExplicitProxyDns } = options;
  const sourceUrl = redactMediaUrl(url);
  const attempts = dispatcherAttempts && dispatcherAttempts.length > 0 ? dispatcherAttempts : [{
    dispatcherPolicy,
    lookupFn
  }];
  const runGuardedFetch = async (attempt) => await (0, _fetchGuardBEAbHb5H.n)((trustExplicitProxyDns && attempt.dispatcherPolicy?.mode === "explicit-proxy" ? _fetchGuardBEAbHb5H.o : _fetchGuardBEAbHb5H.i)({
    url,
    fetchImpl,
    init: requestInit,
    maxRedirects,
    ...(timeoutMs !== void 0 ? { timeoutMs } : {}),
    policy: ssrfPolicy,
    lookupFn: attempt.lookupFn ?? lookupFn,
    dispatcherPolicy: attempt.dispatcherPolicy
  }));
  try {
    let result;
    const attemptErrors = [];
    for (let i = 0; i < attempts.length; i += 1) try {
      result = await runGuardedFetch(attempts[i]);
      break;
    } catch (err) {
      if (typeof shouldRetryFetchError !== "function" || !shouldRetryFetchError(err) || i === attempts.length - 1) {
        if (attemptErrors.length > 0) {
          const combined = new Error(`Primary fetch failed and fallback fetch also failed for ${sourceUrl}`, { cause: err });
          combined.primaryError = attemptErrors[0];
          combined.attemptErrors = [...attemptErrors, err];
          throw combined;
        }
        throw err;
      }
      attemptErrors.push(err);
    }
    return {
      response: result.response,
      finalUrl: result.finalUrl,
      release: result.release,
      sourceUrl
    };
  } catch (err) {
    throw new MediaFetchError("fetch_failed", `Failed to fetch media from ${sourceUrl}: ${(0, _errorsB3ZrCRlt.i)(err)}`, { cause: err });
  }
}
async function assertMediaResponseOk(params) {
  const { res, url, finalUrl, sourceUrl, readIdleTimeoutMs } = params;
  if (res.ok) return;
  const statusText = res.statusText ? ` ${res.statusText}` : "";
  const redirected = finalUrl !== url ? ` (redirected to ${redactMediaUrl(finalUrl)})` : "";
  let detail = `HTTP ${res.status}${statusText}`;
  if (!res.body) detail = `HTTP ${res.status}${statusText}; empty response body`;else
  {
    const snippet = await readErrorBodySnippet(res, { chunkTimeoutMs: readIdleTimeoutMs });
    if (snippet) detail += `; body: ${snippet}`;
  }
  throw new MediaFetchError("http_error", `Failed to fetch media from ${sourceUrl}${redirected}: ${(0, _redactOk5Q8nmw.s)(detail)}`, { status: res.status });
}
function assertMediaContentLength(params) {
  const contentLength = params.res.headers.get("content-length");
  if (!contentLength) return;
  const length = Number(contentLength);
  if (Number.isFinite(length) && length > params.maxBytes) throw new MediaFetchError("max_bytes", `Failed to fetch media from ${params.sourceUrl}: content length ${length} exceeds maxBytes ${params.maxBytes}`);
}
function resolveRemoteFileName(params) {
  let fileNameFromUrl;
  try {
    fileNameFromUrl = basenameFromUrlPathname(new URL(params.finalUrl).pathname) || void 0;
  } catch {}
  return parseContentDispositionFileName(params.res.headers.get("content-disposition")) || (params.filePathHint ? (0, _fileNameR4prf02z.t)(params.filePathHint) : void 0) || fileNameFromUrl;
}
function isGenericResponseContentType(value) {
  const normalized = value?.split(";")[0]?.trim().toLowerCase();
  return !normalized || normalized === "application/octet-stream" || normalized === "binary/octet-stream" || normalized === "application/zip";
}
function resolveResponseContentType(params) {
  if (!params.fallbackContentType) return params.headerContentType ?? void 0;
  if (isGenericResponseContentType(params.headerContentType)) return params.fallbackContentType;
  const headerContentType = params.headerContentType?.split(";")[0]?.trim().toLowerCase();
  const fallbackContentType = params.fallbackContentType.split(";")[0]?.trim().toLowerCase();
  if (headerContentType?.startsWith("video/") && fallbackContentType?.startsWith("audio/") && headerContentType.slice(6) === fallbackContentType.slice(6)) return params.fallbackContentType;
  return params.headerContentType ?? params.fallbackContentType;
}
async function readChunkWithIdleTimeout(reader, chunkTimeoutMs) {
  let timeoutId;
  let timedOut = false;
  return await new Promise((resolve, reject) => {
    const clear = () => {
      if (timeoutId !== void 0) {
        clearTimeout(timeoutId);
        timeoutId = void 0;
      }
    };
    timeoutId = setTimeout(() => {
      timedOut = true;
      clear();
      reader.cancel().catch(() => void 0);
      reject(/* @__PURE__ */new Error(`Media download stalled: no data received for ${chunkTimeoutMs}ms`));
    }, chunkTimeoutMs);
    reader.read().then((result) => {
      clear();
      if (!timedOut) resolve(result);
    }, (err) => {
      clear();
      if (!timedOut) reject(err);
    });
  });
}
async function* responseBodyChunks(body, readIdleTimeoutMs) {
  const reader = body.getReader();
  let completed = false;
  try {
    while (true) {
      const { done, value } = readIdleTimeoutMs ? await readChunkWithIdleTimeout(reader, readIdleTimeoutMs) : await reader.read();
      if (done) {
        completed = true;
        return;
      }
      if (value?.byteLength) yield value;
    }
  } finally {
    if (!completed) await reader.cancel().catch(() => void 0);
    try {
      reader.releaseLock();
    } catch {}
  }
}
function isMediaLimitError(err) {
  return err instanceof Error && /Media exceeds .* limit/.test(err.message);
}
async function saveOkMediaResponse(params) {
  assertMediaContentLength({
    res: params.res,
    sourceUrl: params.sourceUrl,
    maxBytes: params.maxBytes
  });
  const fileName = resolveRemoteFileName({
    res: params.res,
    finalUrl: params.finalUrl,
    filePathHint: params.filePathHint
  });
  const contentType = resolveResponseContentType({
    headerContentType: params.res.headers.get("content-type"),
    fallbackContentType: params.fallbackContentType
  });
  const detectionFilePathHint = isGenericResponseContentType(contentType) ? params.filePathHint : void 0;
  try {
    return {
      ...(params.res.body ? await (0, _storeRQFzzX5P.f)(responseBodyChunks(params.res.body, params.readIdleTimeoutMs), contentType ?? void 0, params.subdir ?? "inbound", params.maxBytes, params.originalFilename, detectionFilePathHint) : await (0, _storeRQFzzX5P.u)(Buffer.alloc(0), contentType ?? void 0, params.subdir ?? "inbound", params.maxBytes, params.originalFilename, detectionFilePathHint)),
      ...(fileName ? { fileName } : {})
    };
  } catch (err) {
    if (err instanceof MediaFetchError) throw err;
    if (isMediaLimitError(err)) throw new MediaFetchError("max_bytes", `Failed to fetch media from ${params.sourceUrl}: payload exceeds maxBytes ${params.maxBytes}`, { cause: err });
    throw new MediaFetchError("fetch_failed", `Failed to fetch media from ${params.sourceUrl}: ${(0, _errorsB3ZrCRlt.i)(err)}`, { cause: err });
  }
}
function shouldRetryMediaFetch(err) {
  if (err instanceof MediaFetchError) {
    if (err.code === "max_bytes") return false;
    if (err.code === "http_error") return typeof err.status === "number" && (err.status === 408 || err.status >= 500);
    if (err.code === "fetch_failed") {
      if ((0, _unhandledRejectionsKm9wbHjh.n)(err) || (0, _unhandledRejectionsKm9wbHjh.n)(err.cause)) return false;
      return (0, _unhandledRejectionsKm9wbHjh.a)(err.cause ?? err);
    }
    return false;
  }
  return (0, _unhandledRejectionsKm9wbHjh.a)(err);
}
async function withMediaFetchRetry(options, fn) {
  const retry = options.retry;
  if (!retry) return await fn();
  const callerShouldRetry = retry.shouldRetry;
  return await (0, _retryCryZAmlE.n)(fn, {
    label: "media:fetch",
    ...retry,
    shouldRetry: (err, attempt) => callerShouldRetry ? callerShouldRetry(err, attempt) : shouldRetryMediaFetch(err)
  });
}
async function saveResponseMedia(res, options = {}) {
  const sourceUrl = redactMediaUrl((options.sourceUrl ?? res.url) || "response");
  const finalUrl = options.sourceUrl ?? res.url;
  await assertMediaResponseOk({
    res,
    url: options.sourceUrl ?? finalUrl,
    finalUrl,
    sourceUrl,
    readIdleTimeoutMs: options.readIdleTimeoutMs
  });
  return await saveOkMediaResponse({
    res,
    finalUrl,
    sourceUrl,
    filePathHint: options.filePathHint,
    maxBytes: options.maxBytes ?? DEFAULT_FETCH_MEDIA_MAX_BYTES,
    readIdleTimeoutMs: options.readIdleTimeoutMs,
    fallbackContentType: options.fallbackContentType,
    subdir: options.subdir,
    originalFilename: options.originalFilename
  });
}
async function saveRemoteMedia(options) {
  return await withMediaFetchRetry(options, () => saveRemoteMediaOnce(options));
}
async function saveRemoteMediaOnce(options) {
  const { response: res, finalUrl, release, sourceUrl } = await fetchGuardedMediaResponse(options);
  try {
    await assertMediaResponseOk({
      res,
      url: options.url,
      finalUrl,
      sourceUrl,
      readIdleTimeoutMs: options.readIdleTimeoutMs
    });
    return await saveOkMediaResponse({
      res,
      finalUrl,
      sourceUrl,
      filePathHint: options.filePathHint,
      maxBytes: options.maxBytes ?? DEFAULT_FETCH_MEDIA_MAX_BYTES,
      readIdleTimeoutMs: options.readIdleTimeoutMs,
      fallbackContentType: options.fallbackContentType,
      subdir: options.subdir,
      originalFilename: options.originalFilename
    });
  } finally {
    if (release) await release();
  }
}
async function readRemoteMediaBuffer(options) {
  return await withMediaFetchRetry(options, () => readRemoteMediaBufferOnce(options));
}
/** @deprecated Use `readRemoteMediaBuffer` for buffer reads or `saveRemoteMedia` for URL-to-store. */
const fetchRemoteMedia = exports.r = readRemoteMediaBuffer;
async function readRemoteMediaBufferOnce(options) {
  const { response: res, finalUrl, release, sourceUrl } = await fetchGuardedMediaResponse(options);
  try {
    await assertMediaResponseOk({
      res,
      url: options.url,
      finalUrl,
      sourceUrl,
      readIdleTimeoutMs: options.readIdleTimeoutMs
    });
    const effectiveMaxBytes = options.maxBytes ?? DEFAULT_FETCH_MEDIA_MAX_BYTES;
    assertMediaContentLength({
      res,
      sourceUrl,
      maxBytes: effectiveMaxBytes
    });
    let buffer;
    try {
      buffer = await (0, _readResponseWithLimitS6PVjcFB.n)(res, effectiveMaxBytes, {
        onOverflow: ({ maxBytes, res }) => new MediaFetchError("max_bytes", `Failed to fetch media from ${redactMediaUrl(res.url || options.url)}: payload exceeds maxBytes ${maxBytes}`),
        chunkTimeoutMs: options.readIdleTimeoutMs
      });
    } catch (err) {
      if (err instanceof MediaFetchError) throw err;
      throw new MediaFetchError("fetch_failed", `Failed to fetch media from ${redactMediaUrl(res.url || options.url)}: ${(0, _errorsB3ZrCRlt.i)(err)}`, { cause: err });
    }
    let fileName = resolveRemoteFileName({
      res,
      finalUrl,
      filePathHint: options.filePathHint
    });
    const filePathForMime = fileName && (0, _fileNameR4prf02z.n)(fileName) ? fileName : options.filePathHint ?? finalUrl;
    const contentType = await (0, _mimeDppuTPZ.n)({
      buffer,
      headerMime: res.headers.get("content-type"),
      filePath: filePathForMime
    });
    if (fileName && !(0, _fileNameR4prf02z.n)(fileName) && contentType) {
      const ext = (0, _mimeDppuTPZ.r)(contentType);
      if (ext) fileName = `${fileName}${ext}`;
    }
    return {
      buffer,
      contentType: contentType ?? void 0,
      fileName
    };
  } finally {
    if (release) await release();
  }
}
//#endregion /* v9-e61da9631b2a7b10 */
