"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = loadEnabledBundleLspConfig;exports.t = inspectBundleLspRuntimeSupport;var _utilsSBTEdeml = require("./utils-sBTEdeml.js");
var _bundleManifestS4nKSc4m = require("./bundle-manifest-s4nKSc4m.js");
var _jsonFilesC2hqjU = require("./json-files-C2hqjU--.js");
var _mergePatchBAO515t_ = require("./merge-patch-BAO515t_.js");
var _bundleMcpCrALtTOT = require("./bundle-mcp-CrALtTOT.js");
var _nodeFs = _interopRequireDefault(require("node:fs"));
var _nodePath = _interopRequireDefault(require("node:path"));function _interopRequireDefault(e) {return e && e.__esModule ? e : { default: e };}
//#region src/plugins/bundle-lsp.ts
const MANIFEST_PATH_BY_FORMAT = { claude: _bundleManifestS4nKSc4m.t };
function extractLspServerMap(raw) {
  if (!(0, _utilsSBTEdeml.c)(raw)) return {};
  const nested = (0, _utilsSBTEdeml.c)(raw.lspServers) ? raw.lspServers : raw;
  if (!(0, _utilsSBTEdeml.c)(nested)) return {};
  const result = {};
  for (const [serverName, serverRaw] of Object.entries(nested)) {
    if (!(0, _utilsSBTEdeml.c)(serverRaw)) continue;
    result[serverName] = { ...serverRaw };
  }
  return result;
}
function resolveBundleLspConfigPaths(params) {
  const declared = (0, _bundleManifestS4nKSc4m.s)(params.raw.lspServers);
  return (0, _bundleManifestS4nKSc4m.o)(_nodeFs.default.existsSync(_nodePath.default.join(params.rootDir, ".lsp.json")) ? [".lsp.json"] : [], declared);
}
function loadBundleLspConfigFile(params) {
  const result = (0, _jsonFilesC2hqjU.u)({
    rootDir: params.rootDir,
    relativePath: params.relativePath,
    boundaryLabel: "plugin root",
    rejectHardlinks: true
  });
  if (!result.ok) {
    if (result.reason === "open") return {
      config: { lspServers: {} },
      diagnostics: result.failure.reason === "path" ? [] : [`unable to read ${params.relativePath}: ${result.failure.reason}`]
    };
    return {
      config: { lspServers: {} },
      diagnostics: [`unable to read ${params.relativePath}: ${result.error}`]
    };
  }
  return {
    config: { lspServers: extractLspServerMap(result.value) },
    diagnostics: []
  };
}
function loadBundleLspConfig(params) {
  const manifestRelativePath = MANIFEST_PATH_BY_FORMAT[params.bundleFormat];
  if (!manifestRelativePath) return {
    config: { lspServers: {} },
    diagnostics: []
  };
  const manifestLoaded = (0, _bundleMcpCrALtTOT.o)({
    rootDir: params.rootDir,
    relativePath: manifestRelativePath
  });
  if (!manifestLoaded.ok) return {
    config: { lspServers: {} },
    diagnostics: [manifestLoaded.error]
  };
  let merged = { lspServers: {} };
  const filePaths = resolveBundleLspConfigPaths({
    raw: manifestLoaded.raw,
    rootDir: params.rootDir
  });
  const diagnostics = [];
  for (const relativePath of filePaths) {
    const loaded = loadBundleLspConfigFile({
      rootDir: params.rootDir,
      relativePath
    });
    diagnostics.push(...loaded.diagnostics);
    merged = (0, _mergePatchBAO515t_.t)(merged, loaded.config);
  }
  return {
    config: merged,
    diagnostics
  };
}
function inspectBundleLspRuntimeSupport(params) {
  const support = (0, _bundleMcpCrALtTOT.i)({
    loaded: loadBundleLspConfig(params),
    resolveServers: (config) => config.lspServers
  });
  return {
    hasStdioServer: support.hasSupportedServer,
    supportedServerNames: support.supportedServerNames,
    unsupportedServerNames: support.unsupportedServerNames,
    diagnostics: support.diagnostics
  };
}
function loadEnabledBundleLspConfig(params) {
  return (0, _bundleMcpCrALtTOT.a)({
    workspaceDir: params.workspaceDir,
    cfg: params.cfg,
    createEmptyConfig: () => ({ lspServers: {} }),
    loadBundleConfig: loadBundleLspConfig,
    createDiagnostic: (pluginId, message) => ({
      pluginId,
      message
    })
  });
}
//#endregion /* v9-5c4d7c011aee70aa */
