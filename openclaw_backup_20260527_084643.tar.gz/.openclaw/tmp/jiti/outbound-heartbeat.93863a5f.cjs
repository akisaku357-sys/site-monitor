"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.createReplyHeartbeatController = createReplyHeartbeatController;exports.emitReplyHeartbeat = emitReplyHeartbeat;var _types = require("../../access/ws/types.js");
var _logger = require("../../logger.js");
const HEARTBEAT_TIMEOUT_MS = 800;
const DEFAULT_RUNNING_HEARTBEAT_INTERVAL_MS = 2000;
const MAX_RUNNING_HEARTBEAT_IDLE_MS = 30000;
/**
 * Send reply status heartbeat (best effort, no throw, no interruption to main flow).
 */
async function emitReplyHeartbeat(params) {
  const { ctx, account, toAccount, groupCode, heartbeat, sendTime } = params;
  const log = (0, _logger.createLog)("reply-heartbeat");
  const fromAccount = account.botId?.trim() ?? "";
  const targetAccount = toAccount.trim();
  const withTimeout = async (promise, timeoutMs) => new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`heartbeat timeout(${timeoutMs}ms)`)), timeoutMs);
    promise.
    then((value) => {
      clearTimeout(timer);
      resolve(value);
    }).
    catch((err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
  if (!ctx.wsClient) {
    log.warn(`[${account.accountId}] heartbeat send failed: wsClient unavailable`);
    return;
  }
  if (!fromAccount || !targetAccount) {
    log.warn(`[${account.accountId}] heartbeat send failed: from/to account missing`, {
      fromAccount,
      toAccount: targetAccount,
      groupCode,
      heartbeat
    });
    return;
  }
  try {
    if (groupCode) {
      const rsp = await withTimeout(ctx.wsClient.sendGroupHeartbeat({
        from_account: fromAccount,
        to_account: targetAccount,
        group_code: groupCode,
        send_time: sendTime,
        heartbeat
      }), HEARTBEAT_TIMEOUT_MS);
      if (rsp.code !== 0) {
        log.warn(`[${account.accountId}] group reply heartbeat send failed: code=${rsp.code}, msg=${rsp.msg ?? rsp.message ?? ""}`);
      }
      return;
    }
    const rsp = await withTimeout(ctx.wsClient.sendPrivateHeartbeat({
      from_account: fromAccount,
      to_account: targetAccount,
      heartbeat
    }), HEARTBEAT_TIMEOUT_MS);
    if (rsp.code !== 0) {
      log.warn(`[${account.accountId}] C2C reply heartbeat send failed: code=${rsp.code}, msg=${rsp.msg ?? rsp.message ?? ""}`);
    }
  }
  catch (err) {
    log.warn(`[${account.accountId}] reply heartbeat send error: ${String(err)}`);
  }
}
function createReplyHeartbeatController(params) {
  const { meta } = params;
  const runningIntervalMs = params.runningIntervalMs ?? DEFAULT_RUNNING_HEARTBEAT_INTERVAL_MS;
  let runningHeartbeatTimer = null;
  let runningHeartbeatActive = false;
  let runningHeartbeatStartTime = null;
  let lastRunningEmitAt = null;
  const send = (heartbeat, sendTime) => {
    void emitReplyHeartbeat({
      ...meta,
      heartbeat,
      sendTime
    });
  };
  const sendRunningHeartbeatAndSchedule = async () => {
    if (!runningHeartbeatActive) {
      return;
    }
    if (runningHeartbeatStartTime === null) {
      return;
    }
    if (lastRunningEmitAt === null) {
      return;
    }
    if (Date.now() - lastRunningEmitAt > MAX_RUNNING_HEARTBEAT_IDLE_MS) {
      stop();
      return;
    }
    await emitReplyHeartbeat({
      ...meta,
      heartbeat: _types.WS_HEARTBEAT.RUNNING,
      sendTime: runningHeartbeatStartTime
    });
    if (!runningHeartbeatActive) {
      return;
    }
    runningHeartbeatTimer = setTimeout(() => {
      void sendRunningHeartbeatAndSchedule();
    }, runningIntervalMs);
  };
  const stop = () => {
    runningHeartbeatActive = false;
    runningHeartbeatStartTime = null;
    lastRunningEmitAt = null;
    if (runningHeartbeatTimer) {
      clearTimeout(runningHeartbeatTimer);
      runningHeartbeatTimer = null;
    }
  };
  const startRunning = () => {
    if (runningHeartbeatActive) {
      return;
    }
    runningHeartbeatActive = true;
    runningHeartbeatStartTime = Date.now();
    lastRunningEmitAt = Date.now();
    void sendRunningHeartbeatAndSchedule();
  };
  const emit = (heartbeat) => {
    if (heartbeat === _types.WS_HEARTBEAT.RUNNING) {
      if (runningHeartbeatActive) {
        lastRunningEmitAt = Date.now();
        return;
      }
      startRunning();
      return;
    }
    stop();
    send(heartbeat, Date.now());
  };
  return {
    emit,
    onReplySent: stop,
    stop
  };
} /* v9-c9d08f4c099bb5b6 */
