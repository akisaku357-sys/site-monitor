"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.t = buildOutboundBaseSessionKey;var _resolveRouteC8IahAyG = require("./resolve-route-C8IahAyG.js");
//#region src/infra/outbound/base-session-key.ts
function buildOutboundBaseSessionKey(params) {
  return (0, _resolveRouteC8IahAyG.t)({
    agentId: params.agentId,
    channel: params.channel,
    accountId: params.accountId,
    peer: params.peer,
    dmScope: params.cfg.session?.dmScope ?? "main",
    identityLinks: params.cfg.session?.identityLinks
  });
}
//#endregion /* v9-7bbab9f36c125b06 */
