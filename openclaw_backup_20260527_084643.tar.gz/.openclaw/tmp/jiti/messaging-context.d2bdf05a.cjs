"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.YUANBAO_MARKDOWN_HINT = void 0; /**
 * Message processing context, logging tools, and constants
 */
/** System prompt to prevent model from wrapping entire reply in markdown code block */
const YUANBAO_MARKDOWN_HINT = exports.YUANBAO_MARKDOWN_HINT = "⚠️ 格式规范（强制）：当回复内容包含 Markdown 表格时，禁止用 ```markdown 代码块包裹，直接输出表格内容即可，不需要外层 fence。"; /* v9-8c64cd13796db1ac */
