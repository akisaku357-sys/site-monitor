"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.i = resolveChannelDefaultAccountId;exports.n = formatPairingApproveHint;exports.r = parseOptionalDelimitedEntries;exports.t = buildAccountScopedDmSecurityPolicy;var _commandFormatBPjMauol = require("./command-format-BPjMauol.js");
var _accountIdB32JINN = require("./account-id-B32J-iNN.js");
//#region src/channels/plugins/helpers.ts
function resolveChannelDefaultAccountId(params) {
  const accountIds = params.accountIds ?? params.plugin.config.listAccountIds(params.cfg);
  return params.plugin.config.defaultAccountId?.(params.cfg) ?? accountIds[0] ?? "default";
}
function formatPairingApproveHint(channelId) {
  return `Approve via: ${(0, _commandFormatBPjMauol.t)(`openclaw pairing list ${channelId}`)} / ${(0, _commandFormatBPjMauol.t)(`openclaw pairing approve ${channelId} <code>`)}`;
}
function parseOptionalDelimitedEntries(value) {
  if (!value?.trim()) return;
  const parsed = value.split(/[\n,;]+/g).map((entry) => entry.trim()).filter(Boolean);
  return parsed.length > 0 ? parsed : void 0;
}
function buildAccountScopedDmSecurityPolicy(params) {
  const resolvedAccountId = params.accountId ?? params.fallbackAccountId ?? "default";
  const channelConfig = params.cfg.channels?.[params.channelKey];
  const rootBasePath = `channels.${params.channelKey}.`;
  const accountBasePath = `channels.${params.channelKey}.accounts.${resolvedAccountId}.`;
  const defaultBasePath = `channels.${params.channelKey}.accounts.${_accountIdB32JINN.t}.`;
  const accountConfig = channelConfig?.accounts?.[resolvedAccountId];
  const defaultAccountConfig = params.inheritSharedDefaultsFromDefaultAccount && resolvedAccountId !== "default" ? channelConfig?.accounts?.[_accountIdB32JINN.t] : void 0;
  const resolveFieldName = (suffix, fallbackField) => suffix == null || suffix === "" ? fallbackField : /^[A-Za-z0-9_-]+$/.test(suffix) ? suffix : null;
  const simplePolicyField = resolveFieldName(params.policyPathSuffix, "dmPolicy");
  const simpleAllowFromField = resolveFieldName(params.allowFromPathSuffix, "allowFrom");
  const matchesAnyField = (config, fields) => fields.some((field) => field != null && config?.[field] !== void 0);
  const basePath = simplePolicyField || simpleAllowFromField ? matchesAnyField(accountConfig, [simplePolicyField, simpleAllowFromField]) ? accountBasePath : matchesAnyField(defaultAccountConfig, [simplePolicyField, simpleAllowFromField]) ? defaultBasePath : matchesAnyField(channelConfig, [simplePolicyField, simpleAllowFromField]) ? rootBasePath : accountConfig ? accountBasePath : rootBasePath : accountConfig ? accountBasePath : rootBasePath;
  const allowFromPath = `${basePath}${params.allowFromPathSuffix ?? ""}`;
  const policyPath = params.policyPathSuffix != null ? `${basePath}${params.policyPathSuffix}` : void 0;
  return {
    policy: params.policy ?? params.defaultPolicy ?? "pairing",
    allowFrom: params.allowFrom ?? [],
    policyPath,
    allowFromPath,
    approveHint: params.approveHint ?? formatPairingApproveHint(params.approveChannelId ?? params.channelKey),
    normalizeEntry: params.normalizeEntry
  };
}
//#endregion /* v9-3e29c5ea9cfe3869 */
