"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = resolveSilentReplyPolicy;exports.r = resolveSilentReplySettings;exports.t = resolveCurrentTurnImages;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _errorsB3ZrCRlt = require("./errors-b3ZrCRlt.js");
var _globalsYU5FjfZK = require("./globals-YU5FjfZK.js");
var _agentTurnAttachmentsBM8XhuOm = require("./agent-turn-attachments-BM8XhuOm.js");
//#region src/shared/silent-reply-policy.ts
const DEFAULT_SILENT_REPLY_POLICY = {
  direct: "disallow",
  group: "allow",
  internal: "allow"
};
function classifySilentReplyConversationType(params) {
  if (params.conversationType) return params.conversationType;
  const normalizedSessionKey = (0, _stringCoerceDyL154ka.a)(params.sessionKey);
  if (normalizedSessionKey.includes(":group:") || normalizedSessionKey.includes(":channel:")) return "group";
  if (normalizedSessionKey.includes(":direct:") || normalizedSessionKey.includes(":dm:")) return "direct";
  if ((0, _stringCoerceDyL154ka.a)(params.surface) === "webchat") return "direct";
  return "internal";
}
function resolveSilentReplyPolicyFromPolicies(params) {
  if (params.conversationType === "direct") return "disallow";
  return params.surfacePolicy?.[params.conversationType] ?? params.defaultPolicy?.[params.conversationType] ?? DEFAULT_SILENT_REPLY_POLICY[params.conversationType];
}
//#endregion
//#region src/config/silent-reply.ts
function resolveSilentReplyConversationContext(params) {
  const conversationType = classifySilentReplyConversationType({
    sessionKey: params.sessionKey,
    surface: params.surface,
    conversationType: params.conversationType
  });
  const normalizedSurface = (0, _stringCoerceDyL154ka.a)(params.surface);
  const surface = normalizedSurface ? params.cfg?.surfaces?.[normalizedSurface] : void 0;
  return {
    conversationType,
    defaultPolicy: params.cfg?.agents?.defaults?.silentReply,
    surfacePolicy: surface?.silentReply
  };
}
function resolveSilentReplySettings(params) {
  return { policy: resolveSilentReplyPolicyFromPolicies(resolveSilentReplyConversationContext(params)) };
}
function resolveSilentReplyPolicy(params) {
  return resolveSilentReplySettings(params).policy;
}
//#endregion
//#region src/auto-reply/reply/current-turn-images.ts
function countCurrentImageAttachmentCandidates(ctx) {
  const pathsFromArray = Array.isArray(ctx.MediaPaths) ? ctx.MediaPaths : void 0;
  const paths = pathsFromArray && pathsFromArray.length > 0 ? pathsFromArray : (0, _stringCoerceDyL154ka.c)(ctx.MediaPath) ? [ctx.MediaPath] : [];
  if (paths.length === 0) return 0;
  const types = Array.isArray(ctx.MediaTypes) && ctx.MediaTypes.length === paths.length ? ctx.MediaTypes : void 0;
  let count = 0;
  for (const [index, pathValue] of paths.entries()) {
    const mediaPath = (0, _stringCoerceDyL154ka.c)(pathValue);
    const mediaType = (0, _stringCoerceDyL154ka.c)(types?.[index] ?? ctx.MediaType);
    if (mediaPath && mediaType?.startsWith("image/")) count++;
  }
  return count;
}
async function resolveCurrentTurnImages(params) {
  if (Array.isArray(params.images) && params.images.length > 0) return {
    images: params.images,
    imageOrder: params.imageOrder
  };
  const currentImageCandidateCount = countCurrentImageAttachmentCandidates(params.ctx);
  if (currentImageCandidateCount === 0) return {
    images: params.images,
    imageOrder: params.imageOrder
  };
  try {
    const images = (await (0, _agentTurnAttachmentsBM8XhuOm.n)({
      ctx: params.ctx,
      cfg: params.cfg,
      includeRecentHistoryImages: false
    })).attachments.map((attachment) => ({
      type: "image",
      data: attachment.data,
      mimeType: attachment.mediaType
    }));
    if (images.length < currentImageCandidateCount) {
      (0, _globalsYU5FjfZK.r)(`agent-runner: native PI media resolution produced ${images.length}/${currentImageCandidateCount} current image attachment(s); falling back to prompt image refs`);
      return {
        images: params.images,
        imageOrder: params.imageOrder
      };
    }
    return images.length > 0 ? {
      images,
      imageOrder: images.map(() => "inline")
    } : {
      images: params.images,
      imageOrder: params.imageOrder
    };
  } catch (error) {
    (0, _globalsYU5FjfZK.r)(`agent-runner: media attachment image resolution failed, proceeding without native images: ${(0, _errorsB3ZrCRlt.i)(error)}`);
    return {
      images: params.images,
      imageOrder: params.imageOrder
    };
  }
}
//#endregion /* v9-85bd3cc181043067 */
