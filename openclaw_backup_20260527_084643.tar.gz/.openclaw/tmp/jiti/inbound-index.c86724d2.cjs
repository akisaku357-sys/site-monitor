"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.handleInboundMessage = handleInboundMessage;






var _index = require("../../dispatcher/debouncer/index.js");
require("../messaging/callbacks/recall.js");
var _logger = require("../../logger.js");
var _systemCallbacks = require("../messaging/system-callbacks.js"); /**
 * Message inbound processing module.
 *
 * Unified entry point, single responsibility:
 * - System callbacks (Recall, etc.) dispatched synchronously, not debounced
 * - Normal messages delegated to dispatcher/debouncer for debounce + session-level serialization
 */ /**
 * Unified message processing entry.
 *
 * System callbacks (recall, etc.) are dispatched synchronously, not debounced;
 * normal messages are delegated to the dispatcher debouncer for debounce + session-level serialization.
 */async function handleInboundMessage(params) {const { msg, isGroup, account, config, core, wsClient, log, statusSink, abortSignal } = params; // System callbacks (Recall, etc.): dispatched synchronously, not entering debounce queue
  const callbackLog = (0, _logger.createLog)("system-callback", log);const callbackCtx = { account,
    config,
    core,
    log: {
      ...callbackLog,
      verbose: (...args) => callbackLog.debug(...args)
    },
    wsClient,
    abortSignal,
    statusSink
  };
  if ((0, _systemCallbacks.dispatchSystemCallback)({ ctx: callbackCtx, msg, isGroup })) {
    return;
  }
  // Delegate to dispatcher debouncer
  const d = (0, _index.ensureDebouncer)(config);
  await d.enqueue({ msg, isGroup, account, config, core, wsClient, log, statusSink, abortSignal });
} /* v9-f2668705cfa3a77d */
