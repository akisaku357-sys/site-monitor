"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.a = loadBundleManifest;exports.i = detectBundleManifestFormat;exports.n = void 0;exports.o = mergeBundlePathLists;exports.r = void 0;exports.s = normalizeBundlePathList;exports.t = void 0;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _rootFileJRMCpJW = require("./root-file-jRMCpJW4.js");
var _utilsSBTEdeml = require("./utils-sBTEdeml.js");
require("./boundary-file-read-CBe_wA_B.js");
require("./path-safety-CBe_wA_B.js");
var _jsonFilesC2hqjU = require("./json-files-C2hqjU--.js");
var _manifestCyo7Vmnr = require("./manifest-Cyo7Vmnr.js");
var _nodeFs = _interopRequireDefault(require("node:fs"));
var _json = _interopRequireDefault(require("json5"));
var _nodePath = _interopRequireDefault(require("node:path"));function _interopRequireDefault(e) {return e && e.__esModule ? e : { default: e };}
//#region src/plugins/bundle-manifest.ts
const CODEX_BUNDLE_MANIFEST_RELATIVE_PATH = exports.n = ".codex-plugin/plugin.json";
const CLAUDE_BUNDLE_MANIFEST_RELATIVE_PATH = exports.t = ".claude-plugin/plugin.json";
const CURSOR_BUNDLE_MANIFEST_RELATIVE_PATH = exports.r = ".cursor-plugin/plugin.json";
function normalizePathList(value) {
  if (typeof value === "string") {
    const trimmed = value.trim();
    return trimmed ? [trimmed] : [];
  }
  if (!Array.isArray(value)) return [];
  return value.map((entry) => (0, _stringCoerceDyL154ka.c)(entry)).filter((entry) => Boolean(entry));
}
function normalizeBundlePathList(value) {
  return Array.from(new Set(normalizePathList(value)));
}
function mergeBundlePathLists(...groups) {
  const merged = [];
  const seen = /* @__PURE__ */new Set();
  for (const group of groups) for (const entry of group) {
    if (seen.has(entry)) continue;
    seen.add(entry);
    merged.push(entry);
  }
  return merged;
}
function hasInlineCapabilityValue(value) {
  if (typeof value === "string") return value.trim().length > 0;
  if (Array.isArray(value)) return value.length > 0;
  if ((0, _utilsSBTEdeml.c)(value)) return Object.keys(value).length > 0;
  return value === true;
}
function slugifyPluginId(raw, rootDir) {
  const fallback = _nodePath.default.basename(rootDir);
  return ((0, _stringCoerceDyL154ka.a)(raw) || (0, _stringCoerceDyL154ka.a)(fallback)).replace(/[^a-z0-9]+/g, "-").replace(/-+/g, "-").replace(/^-+|-+$/g, "") || "bundle-plugin";
}
function loadBundleManifestFile(params) {
  const manifestPath = _nodePath.default.join(params.rootDir, params.manifestRelativePath);
  const result = (0, _jsonFilesC2hqjU.f)({
    rootDir: params.rootDir,
    ...(params.rootRealPath !== void 0 ? { rootRealPath: params.rootRealPath } : {}),
    relativePath: params.manifestRelativePath,
    boundaryLabel: "plugin root",
    rejectHardlinks: params.rejectHardlinks,
    parse: (raw) => _json.default.parse(raw),
    validate: _utilsSBTEdeml.c
  });
  if (!result.ok && result.reason === "open") return (0, _rootFileJRMCpJW.n)(result.failure, {
    path: () => {
      if (params.allowMissing) return {
        ok: true,
        raw: {},
        manifestPath
      };
      return {
        ok: false,
        error: `plugin manifest not found: ${manifestPath}`,
        manifestPath
      };
    },
    fallback: (failure) => ({
      ok: false,
      error: `unsafe plugin manifest path: ${manifestPath} (${failure.reason})`,
      manifestPath
    })
  });
  if (!result.ok) return {
    ok: false,
    error: result.reason === "invalid" ? "plugin manifest must be an object" : `failed to parse plugin manifest: ${result.error}`,
    manifestPath
  };
  return {
    ok: true,
    raw: result.value,
    manifestPath
  };
}
function resolveCodexSkillDirs(raw, rootDir) {
  const declared = normalizeBundlePathList(raw.skills);
  if (declared.length > 0) return declared;
  return _nodeFs.default.existsSync(_nodePath.default.join(rootDir, "skills")) ? ["skills"] : [];
}
function resolveCodexHookDirs(raw, rootDir) {
  const declared = normalizeBundlePathList(raw.hooks);
  if (declared.length > 0) return declared;
  return _nodeFs.default.existsSync(_nodePath.default.join(rootDir, "hooks")) ? ["hooks"] : [];
}
function resolveCursorSkillsRootDirs(raw, rootDir) {
  const declared = normalizeBundlePathList(raw.skills);
  return mergeBundlePathLists(_nodeFs.default.existsSync(_nodePath.default.join(rootDir, "skills")) ? ["skills"] : [], declared);
}
function resolveCursorCommandRootDirs(raw, rootDir) {
  const declared = normalizeBundlePathList(raw.commands);
  return mergeBundlePathLists(_nodeFs.default.existsSync(_nodePath.default.join(rootDir, ".cursor", "commands")) ? [".cursor/commands"] : [], declared);
}
function resolveCursorSkillDirs(raw, rootDir) {
  return mergeBundlePathLists(resolveCursorSkillsRootDirs(raw, rootDir), resolveCursorCommandRootDirs(raw, rootDir));
}
function resolveCursorAgentDirs(raw, rootDir) {
  const declared = normalizeBundlePathList(raw.subagents ?? raw.agents);
  return mergeBundlePathLists(_nodeFs.default.existsSync(_nodePath.default.join(rootDir, ".cursor", "agents")) ? [".cursor/agents"] : [], declared);
}
function hasCursorHookCapability(raw, rootDir) {
  return hasInlineCapabilityValue(raw.hooks) || _nodeFs.default.existsSync(_nodePath.default.join(rootDir, ".cursor", "hooks.json"));
}
function hasCursorRulesCapability(raw, rootDir) {
  return hasInlineCapabilityValue(raw.rules) || _nodeFs.default.existsSync(_nodePath.default.join(rootDir, ".cursor", "rules"));
}
function hasCursorMcpCapability(raw, rootDir) {
  return hasInlineCapabilityValue(raw.mcpServers) || _nodeFs.default.existsSync(_nodePath.default.join(rootDir, ".mcp.json"));
}
function resolveClaudeComponentPaths(raw, key, rootDir, defaults) {
  const declared = normalizeBundlePathList(raw[key]);
  return mergeBundlePathLists(defaults.filter((candidate) => _nodeFs.default.existsSync(_nodePath.default.join(rootDir, candidate))), declared);
}
function resolveClaudeSkillsRootDirs(raw, rootDir) {
  return resolveClaudeComponentPaths(raw, "skills", rootDir, ["skills"]);
}
function resolveClaudeCommandRootDirs(raw, rootDir) {
  return resolveClaudeComponentPaths(raw, "commands", rootDir, ["commands"]);
}
function resolveClaudeSkillDirs(raw, rootDir) {
  return mergeBundlePathLists(resolveClaudeSkillsRootDirs(raw, rootDir), resolveClaudeCommandRootDirs(raw, rootDir), resolveClaudeAgentDirs(raw, rootDir), resolveClaudeOutputStylePaths(raw, rootDir));
}
function resolveClaudeAgentDirs(raw, rootDir) {
  return resolveClaudeComponentPaths(raw, "agents", rootDir, ["agents"]);
}
function resolveClaudeHookPaths(raw, rootDir) {
  return resolveClaudeComponentPaths(raw, "hooks", rootDir, ["hooks/hooks.json"]);
}
function resolveClaudeMcpPaths(raw, rootDir) {
  return resolveClaudeComponentPaths(raw, "mcpServers", rootDir, [".mcp.json"]);
}
function resolveClaudeLspPaths(raw, rootDir) {
  return resolveClaudeComponentPaths(raw, "lspServers", rootDir, [".lsp.json"]);
}
function resolveClaudeOutputStylePaths(raw, rootDir) {
  return resolveClaudeComponentPaths(raw, "outputStyles", rootDir, ["output-styles"]);
}
function resolveClaudeSettingsFiles(_raw, rootDir) {
  return _nodeFs.default.existsSync(_nodePath.default.join(rootDir, "settings.json")) ? ["settings.json"] : [];
}
function hasClaudeHookCapability(raw, rootDir) {
  return hasInlineCapabilityValue(raw.hooks) || resolveClaudeHookPaths(raw, rootDir).length > 0;
}
function buildCodexCapabilities(raw, rootDir) {
  const capabilities = [];
  if (resolveCodexSkillDirs(raw, rootDir).length > 0) capabilities.push("skills");
  if (resolveCodexHookDirs(raw, rootDir).length > 0) capabilities.push("hooks");
  if (hasInlineCapabilityValue(raw.mcpServers) || _nodeFs.default.existsSync(_nodePath.default.join(rootDir, ".mcp.json"))) capabilities.push("mcpServers");
  if (hasInlineCapabilityValue(raw.apps) || _nodeFs.default.existsSync(_nodePath.default.join(rootDir, ".app.json"))) capabilities.push("apps");
  return capabilities;
}
function buildClaudeCapabilities(raw, rootDir) {
  const capabilities = [];
  if (resolveClaudeSkillDirs(raw, rootDir).length > 0) capabilities.push("skills");
  if (resolveClaudeCommandRootDirs(raw, rootDir).length > 0) capabilities.push("commands");
  if (resolveClaudeAgentDirs(raw, rootDir).length > 0) capabilities.push("agents");
  if (hasClaudeHookCapability(raw, rootDir)) capabilities.push("hooks");
  if (hasInlineCapabilityValue(raw.mcpServers) || resolveClaudeMcpPaths(raw, rootDir).length > 0) capabilities.push("mcpServers");
  if (hasInlineCapabilityValue(raw.lspServers) || resolveClaudeLspPaths(raw, rootDir).length > 0) capabilities.push("lspServers");
  if (hasInlineCapabilityValue(raw.outputStyles) || resolveClaudeOutputStylePaths(raw, rootDir).length > 0) capabilities.push("outputStyles");
  if (resolveClaudeSettingsFiles(raw, rootDir).length > 0) capabilities.push("settings");
  return capabilities;
}
function buildCursorCapabilities(raw, rootDir) {
  const capabilities = [];
  if (resolveCursorSkillDirs(raw, rootDir).length > 0) capabilities.push("skills");
  if (resolveCursorCommandRootDirs(raw, rootDir).length > 0) capabilities.push("commands");
  if (resolveCursorAgentDirs(raw, rootDir).length > 0) capabilities.push("agents");
  if (hasCursorHookCapability(raw, rootDir)) capabilities.push("hooks");
  if (hasCursorRulesCapability(raw, rootDir)) capabilities.push("rules");
  if (hasCursorMcpCapability(raw, rootDir)) capabilities.push("mcpServers");
  return capabilities;
}
function loadBundleManifest(params) {
  const rejectHardlinks = params.rejectHardlinks ?? true;
  const manifestRelativePath = params.bundleFormat === "codex" ? CODEX_BUNDLE_MANIFEST_RELATIVE_PATH : params.bundleFormat === "cursor" ? CURSOR_BUNDLE_MANIFEST_RELATIVE_PATH : CLAUDE_BUNDLE_MANIFEST_RELATIVE_PATH;
  const loaded = loadBundleManifestFile({
    rootDir: params.rootDir,
    ...(params.rootRealPath !== void 0 ? { rootRealPath: params.rootRealPath } : {}),
    manifestRelativePath,
    rejectHardlinks,
    allowMissing: params.bundleFormat === "claude"
  });
  if (!loaded.ok) return loaded;
  const raw = loaded.raw;
  const interfaceRecord = (0, _utilsSBTEdeml.c)(raw.interface) ? raw.interface : void 0;
  const name = (0, _stringCoerceDyL154ka.c)(raw.name);
  const description = (0, _stringCoerceDyL154ka.c)(raw.description) ?? (0, _stringCoerceDyL154ka.c)(raw.shortDescription) ?? (0, _stringCoerceDyL154ka.c)(interfaceRecord?.shortDescription);
  const version = (0, _stringCoerceDyL154ka.c)(raw.version);
  if (params.bundleFormat === "codex") {
    const skills = resolveCodexSkillDirs(raw, params.rootDir);
    const hooks = resolveCodexHookDirs(raw, params.rootDir);
    return {
      ok: true,
      manifest: {
        id: slugifyPluginId(name, params.rootDir),
        name,
        description,
        version,
        skills,
        settingsFiles: [],
        hooks,
        bundleFormat: "codex",
        activation: (0, _manifestCyo7Vmnr.a)(raw.activation),
        capabilities: buildCodexCapabilities(raw, params.rootDir)
      },
      manifestPath: loaded.manifestPath
    };
  }
  if (params.bundleFormat === "cursor") return {
    ok: true,
    manifest: {
      id: slugifyPluginId(name, params.rootDir),
      name,
      description,
      version,
      skills: resolveCursorSkillDirs(raw, params.rootDir),
      settingsFiles: [],
      hooks: [],
      bundleFormat: "cursor",
      activation: (0, _manifestCyo7Vmnr.a)(raw.activation),
      capabilities: buildCursorCapabilities(raw, params.rootDir)
    },
    manifestPath: loaded.manifestPath
  };
  return {
    ok: true,
    manifest: {
      id: slugifyPluginId(name, params.rootDir),
      name,
      description,
      version,
      skills: resolveClaudeSkillDirs(raw, params.rootDir),
      settingsFiles: resolveClaudeSettingsFiles(raw, params.rootDir),
      hooks: resolveClaudeHookPaths(raw, params.rootDir),
      bundleFormat: "claude",
      activation: (0, _manifestCyo7Vmnr.a)(raw.activation),
      capabilities: buildClaudeCapabilities(raw, params.rootDir)
    },
    manifestPath: loaded.manifestPath
  };
}
function detectBundleManifestFormat(rootDir) {
  if (_nodeFs.default.existsSync(_nodePath.default.join(rootDir, ".codex-plugin/plugin.json"))) return "codex";
  if (_nodeFs.default.existsSync(_nodePath.default.join(rootDir, ".cursor-plugin/plugin.json"))) return "cursor";
  if (_nodeFs.default.existsSync(_nodePath.default.join(rootDir, ".claude-plugin/plugin.json"))) return "claude";
  if (_nodeFs.default.existsSync(_nodePath.default.join(rootDir, "openclaw.plugin.json"))) return null;
  if (_manifestCyo7Vmnr.t.some((candidate) => _nodeFs.default.existsSync(_nodePath.default.join(rootDir, candidate)))) return null;
  if ([
  _nodePath.default.join(rootDir, "skills"),
  _nodePath.default.join(rootDir, "commands"),
  _nodePath.default.join(rootDir, "agents"),
  _nodePath.default.join(rootDir, "hooks", "hooks.json"),
  _nodePath.default.join(rootDir, ".mcp.json"),
  _nodePath.default.join(rootDir, ".lsp.json"),
  _nodePath.default.join(rootDir, "settings.json")].
  some((candidate) => _nodeFs.default.existsSync(candidate))) return "claude";
  return null;
}
//#endregion /* v9-080c57395ace1394 */
