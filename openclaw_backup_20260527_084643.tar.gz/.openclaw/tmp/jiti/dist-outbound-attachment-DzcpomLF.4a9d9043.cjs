"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.t = resolveOutboundAttachmentFromUrl;var _storeRQFzzX5P = require("./store-rQFzzX5P.js");
var _webMediaGlH39bZn = require("./web-media-GlH39bZn.js");
var _loadOptionsLnfEFXDj = require("./load-options-LnfEFXDj.js");
//#region src/media/outbound-attachment.ts
async function resolveOutboundAttachmentFromUrl(mediaUrl, maxBytes, options) {
  const media = await (0, _webMediaGlH39bZn.t)(mediaUrl, (0, _loadOptionsLnfEFXDj.t)({
    maxBytes,
    mediaAccess: options?.mediaAccess,
    mediaLocalRoots: options?.localRoots,
    mediaReadFile: options?.readFile
  }));
  const saved = await (0, _storeRQFzzX5P.u)(media.buffer, media.contentType ?? void 0, "outbound", maxBytes, media.fileName);
  return {
    path: saved.path,
    contentType: saved.contentType
  };
}
//#endregion /* v9-4f4d78180a2d8eac */
