"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.t = runPluginCommandWithTimeout;var _errorsB3ZrCRlt = require("./errors-b3ZrCRlt.js");
var _execD4bhAbbv = require("./exec-D4bhAbbv.js");
//#region src/plugin-sdk/run-command.ts
/** Run a plugin-managed command with timeout handling and normalized stdout/stderr results. */
async function runPluginCommandWithTimeout(options) {
  const [command] = options.argv;
  if (!command) return {
    code: 1,
    stdout: "",
    stderr: "command is required"
  };
  try {
    const result = await (0, _execD4bhAbbv.r)(options.argv, {
      timeoutMs: options.timeoutMs,
      cwd: options.cwd,
      env: options.env
    });
    const timedOut = result.termination === "timeout" || result.termination === "no-output-timeout";
    return {
      code: result.code ?? 1,
      stdout: result.stdout,
      stderr: timedOut ? result.stderr || `command timed out after ${options.timeoutMs}ms` : result.stderr
    };
  } catch (error) {
    return {
      code: 1,
      stdout: "",
      stderr: (0, _errorsB3ZrCRlt.i)(error)
    };
  }
}
//#endregion /* v9-c3f4baa94993f22b */
