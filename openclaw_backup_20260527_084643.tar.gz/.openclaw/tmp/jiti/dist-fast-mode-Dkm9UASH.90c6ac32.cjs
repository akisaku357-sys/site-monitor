"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.t = resolveFastModeState;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
require("./agent-scope-CtLXGcWm.js");
var _agentScopeConfigCMp71_ = require("./agent-scope-config-CMp71_27.js");
var _modelRefSharedBkjJfDrJ = require("./model-ref-shared-BkjJfDrJ.js");
//#region src/agents/fast-mode.ts
function resolveConfiguredFastModeRaw(params) {
  const modelConfig = params.cfg?.agents?.defaults?.models?.[(0, _modelRefSharedBkjJfDrJ.n)(params.provider, params.model)];
  return modelConfig?.params?.fastMode ?? modelConfig?.params?.fast_mode;
}
function resolveFastModeState(params) {
  const sessionOverride = (0, _stringCoerceDyL154ka.i)(params.sessionEntry?.fastMode);
  if (sessionOverride !== void 0) return {
    enabled: sessionOverride,
    source: "session"
  };
  const agentDefault = params.agentId && params.cfg ? (0, _agentScopeConfigCMp71_.r)(params.cfg, params.agentId)?.fastModeDefault : void 0;
  if (typeof agentDefault === "boolean") return {
    enabled: agentDefault,
    source: "agent"
  };
  const configured = (0, _stringCoerceDyL154ka.i)(resolveConfiguredFastModeRaw(params));
  if (configured !== void 0) return {
    enabled: configured,
    source: "config"
  };
  return {
    enabled: false,
    source: "default"
  };
}
//#endregion /* v9-a8af5ab69ba771b6 */
