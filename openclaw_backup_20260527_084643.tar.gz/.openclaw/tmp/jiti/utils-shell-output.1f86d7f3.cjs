"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.executeShellWithCapture = executeShellWithCapture;exports.sanitizeBinaryOutput = sanitizeBinaryOutput;var _types = require("../types.js");
var _truncate = require("./truncate.js");
function toExecutionError(error) {
  if (error instanceof _types.ExecutionError)
  return error;
  const cause = (0, _types.toError)(error);
  return new _types.ExecutionError("unknown", cause.message, cause);
}
function sanitizeBinaryOutput(str) {
  return Array.from(str).
  filter((char) => {
    const code = char.codePointAt(0);
    if (code === undefined)
    return false;
    if (code === 0x09 || code === 0x0a || code === 0x0d)
    return true;
    if (code <= 0x1f)
    return false;
    if (code >= 0xfff9 && code <= 0xfffb)
    return false;
    return true;
  }).
  join("");
}
async function executeShellWithCapture(env, command, options) {
  const outputChunks = [];
  let outputBytes = 0;
  const maxOutputBytes = _truncate.DEFAULT_MAX_BYTES * 2;
  const encoder = new TextEncoder();
  let totalBytes = 0;
  let fullOutputPath;
  let writeChain = Promise.resolve((0, _types.ok)(undefined));
  let captureError;
  const appendFullOutput = (text) => {
    if (!fullOutputPath || captureError)
    return;
    const path = fullOutputPath;
    writeChain = writeChain.then(async (previous) => {
      if (!previous.ok)
      return previous;
      const appendResult = await env.appendFile(path, text, options?.abortSignal);
      return appendResult.ok ? (0, _types.ok)(undefined) : (0, _types.err)(toExecutionError(appendResult.error));
    });
  };
  const ensureFullOutputFile = (initialContent) => {
    if (fullOutputPath || captureError)
    return;
    writeChain = writeChain.then(async (previous) => {
      if (!previous.ok)
      return previous;
      const tempFile = await env.createTempFile({
        prefix: "bash-",
        suffix: ".log",
        abortSignal: options?.abortSignal
      });
      if (!tempFile.ok)
      return (0, _types.err)(toExecutionError(tempFile.error));
      fullOutputPath = tempFile.value;
      const appendResult = await env.appendFile(tempFile.value, initialContent, options?.abortSignal);
      return appendResult.ok ? (0, _types.ok)(undefined) : (0, _types.err)(toExecutionError(appendResult.error));
    });
  };
  const onChunk = (chunk) => {
    try {
      totalBytes += encoder.encode(chunk).byteLength;
      const text = sanitizeBinaryOutput(chunk).replace(/\r/g, "");
      if (totalBytes > _truncate.DEFAULT_MAX_BYTES && !fullOutputPath) {
        ensureFullOutputFile(outputChunks.join("") + text);
      } else
      {
        appendFullOutput(text);
      }
      outputChunks.push(text);
      outputBytes += text.length;
      while (outputBytes > maxOutputBytes && outputChunks.length > 1) {
        const removed = outputChunks.shift();
        outputBytes -= removed.length;
      }
      options?.onChunk?.(text);
    }
    catch (error) {
      captureError = toExecutionError(error);
    }
  };
  try {
    const result = await env.exec(command, {
      ...(options ?? {}),
      onStdout: onChunk,
      onStderr: onChunk
    });
    const tailOutput = outputChunks.join("");
    const truncationResult = (0, _truncate.truncateTail)(tailOutput);
    if (truncationResult.truncated && !fullOutputPath) {
      ensureFullOutputFile(tailOutput);
    }
    const writeResult = await writeChain;
    if (!writeResult.ok)
    return (0, _types.err)(writeResult.error);
    if (captureError)
    return (0, _types.err)(captureError);
    if (!result.ok) {
      if (result.error.code === "aborted" || options?.abortSignal?.aborted) {
        return (0, _types.ok)({
          output: truncationResult.truncated ? truncationResult.content : tailOutput,
          exitCode: undefined,
          cancelled: true,
          truncated: truncationResult.truncated,
          fullOutputPath
        });
      }
      return (0, _types.err)(result.error);
    }
    const cancelled = options?.abortSignal?.aborted ?? false;
    return (0, _types.ok)({
      output: truncationResult.truncated ? truncationResult.content : tailOutput,
      exitCode: cancelled ? undefined : result.value.exitCode,
      cancelled,
      truncated: truncationResult.truncated,
      fullOutputPath
    });
  }
  catch (error) {
    return (0, _types.err)(toExecutionError(error));
  }
} /* v9-e42dbe4b822401fb */
