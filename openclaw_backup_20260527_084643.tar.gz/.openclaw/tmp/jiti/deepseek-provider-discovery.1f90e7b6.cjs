"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = void 0;var _providerCatalogGNsEYitN = require("../../provider-catalog-gNsEYitN.js");
//#region extensions/deepseek/provider-discovery.ts
const deepSeekProviderDiscovery = exports.default = {
  id: "deepseek",
  label: "DeepSeek",
  docsPath: "/providers/deepseek",
  auth: [],
  staticCatalog: {
    order: "simple",
    run: async () => ({ provider: (0, _providerCatalogGNsEYitN.t)() })
  }
};
//#endregion /* v9-439b7c15ea85f95f */
