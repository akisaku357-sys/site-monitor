"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.a = suspendSession;exports.c = shouldAllowCooldownProbeForReason;exports.d = shouldSuppressRawErrorConsoleSuffix;exports.i = resolveSessionSuspensionReason;exports.l = buildApiErrorObservationFields;exports.n = runWithImageModelFallback;exports.o = void 0;exports.r = runWithModelFallback;exports.s = void 0;exports.t = isFallbackSummaryError;exports.u = buildTextObservationFields;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _redactOk5Q8nmw = require("./redact-ok5Q8nmw.js");
var _ansi4r6vVvJt = require("./ansi-4r6vVvJt.js");
var _errorsB3ZrCRlt = require("./errors-b3ZrCRlt.js");
var _lazyPromiseDjskx0qC = require("./lazy-promise-Djskx0qC.js");
var _modelInputChW9XXsQ = require("./model-input-ChW9XXsQ.js");
var _diagnosticEventsBLgzARSp = require("./diagnostic-events-BLgzARSp.js");
var _subsystemDSPWLoK = require("./subsystem-DSPWLoK5.js");
var _defaultsMDjiWzE = require("./defaults-mDjiWzE5.js");
var _agentLimitsY6_vNNMs = require("./agent-limits-Y6_vNNMs.js");
var _policyBwWhR0D = require("./policy-BwWh-R0D.js");
var _registryBiKIFOzv = require("./registry-BiKIFOzv.js");
var _storeBmtchQvp = require("./store-BmtchQvp.js");
require("./sessions-CQHHcgC_.js");
var _sourceCheckBMw3fGLx = require("./source-check-BMw3fGLx.js");
var _modelSelectionSharedClxdEp4X = require("./model-selection-shared-ClxdEp4X.js");
var _modelSelectionNormalizeCBfQoFd = require("./model-selection-normalize-CBfQo-Fd.js");
var _modelSelectionCliDSHhXIv = require("./model-selection-cli-DS-HhXIv.js");
var _stableStringifyTfJ9A6yH = require("./stable-stringify-TfJ9A6yH.js");
var _assistantErrorFormatCuUvHfKt = require("./assistant-error-format-CuUvHfKt.js");
var _sanitizeUserFacingTextDf1DHzs = require("./sanitize-user-facing-text-Df1D-hzs.js");
var _commandQueueDa2Lh3Ua = require("./command-queue-Da2Lh3Ua.js");
require("./pi-embedded-helpers-bmljPI1n.js");
var _errorsDYNDQcd = require("./errors-DYND-qcd.js");
var _failoverErrorCZCIurQK = require("./failover-error-CZCIurQK.js");
var _externalCliDiscoveryD0JQl8du = require("./external-cli-discovery-D0JQl8du.js");
var _redactIdentifierDBO6OkZP = require("./redact-identifier-DBO6OkZP.js");
var _modelRuntimeAliasesD35Lx2no = require("./model-runtime-aliases-D35Lx2no.js");
var _sessionDUinUmLM = require("./session-DUinUmLM.js");
var _nodePath = _interopRequireDefault(require("node:path"));function _interopRequireDefault(e) {return e && e.__esModule ? e : { default: e };}function _interopRequireWildcard(e, t) {if ("function" == typeof WeakMap) var r = new WeakMap(),n = new WeakMap();return (_interopRequireWildcard = function (e, t) {if (!t && e && e.__esModule) return e;var o,i,f = { __proto__: null, default: e };if (null === e || "object" != typeof e && "function" != typeof e) return f;if (o = t ? n : r) {if (o.has(e)) return o.get(e);o.set(e, f);}for (const t in e) "default" !== t && {}.hasOwnProperty.call(e, t) && ((i = (o = Object.defineProperty) && Object.getOwnPropertyDescriptor(e, t)) && (i.get || i.set) ? o(f, t, i) : f[t] = e[t]);return f;})(e, t);}
//#region src/agents/pi-embedded-error-observation.ts
const MAX_OBSERVATION_INPUT_CHARS = 64e3;
const MAX_FINGERPRINT_MESSAGE_CHARS = 8e3;
const RAW_ERROR_PREVIEW_MAX_CHARS = 400;
const PROVIDER_ERROR_PREVIEW_MAX_CHARS = 200;
const REQUEST_ID_RE = /\brequest[_ ]?id\b\s*[:=]\s*["'()]*([A-Za-z0-9._:-]+)/i;
const OBSERVATION_EXTRA_REDACT_PATTERNS = [
String.raw`\b(?:x-)?api[-_]?key\b\s*[:=]\s*(["']?)([^\s"'\\;]+)\1`,
String.raw`"(?:api[-_]?key|api_key)"\s*:\s*"([^"]+)"`,
String.raw`(?:\bCookie\b\s*[:=]\s*[^;=\s]+=|;\s*[^;=\s]+=)([^;\s\r\n]+)`];

const RAW_ERROR_CONSOLE_SUPPRESSED_FAILURE_KINDS = new Set([
"auth_html",
"auth_refresh",
"auth_scope"]
);
function resolveConfiguredRedactPatterns() {
  const configured = (0, _redactOk5Q8nmw.f)()?.redactPatterns;
  if (!Array.isArray(configured)) return [];
  return configured.filter((pattern) => typeof pattern === "string");
}
function truncateForObservation(text, maxChars) {
  const trimmed = text?.trim();
  if (!trimmed) return;
  return trimmed.length > maxChars ? `${trimmed.slice(0, maxChars)}…` : trimmed;
}
function boundObservationInput(text) {
  const trimmed = text?.trim();
  if (!trimmed) return;
  return trimmed.length > MAX_OBSERVATION_INPUT_CHARS ? trimmed.slice(0, MAX_OBSERVATION_INPUT_CHARS) : trimmed;
}
function replaceRequestIdPreview(text, requestId) {
  if (!text || !requestId) return text;
  return text.split(requestId).join((0, _redactIdentifierDBO6OkZP.t)(requestId, { len: 12 }));
}
function redactObservationText(text) {
  if (!text) return text;
  const configuredPatterns = resolveConfiguredRedactPatterns();
  return (0, _redactOk5Q8nmw.s)(text, {
    mode: "tools",
    patterns: [
    ...(0, _redactOk5Q8nmw.t)(),
    ...configuredPatterns,
    ...OBSERVATION_EXTRA_REDACT_PATTERNS]

  });
}
function shouldSuppressRawErrorConsoleSuffix(providerRuntimeFailureKind) {
  return providerRuntimeFailureKind ? RAW_ERROR_CONSOLE_SUPPRESSED_FAILURE_KINDS.has(providerRuntimeFailureKind) : false;
}
function buildObservationFingerprint(params) {
  const boundedMessage = params.message && params.message.length > MAX_FINGERPRINT_MESSAGE_CHARS ? params.message.slice(0, MAX_FINGERPRINT_MESSAGE_CHARS) : params.message;
  const structured = params.httpCode || params.type || boundedMessage ? (0, _stableStringifyTfJ9A6yH.t)({
    httpCode: params.httpCode,
    type: params.type,
    message: boundedMessage
  }) : null;
  if (structured) return structured;
  if (params.requestId) return params.raw.split(params.requestId).join("<request_id>");
  return (0, _sanitizeUserFacingTextDf1DHzs.o)(params.raw);
}
function buildApiErrorObservationFields(rawError, opts) {
  const trimmed = boundObservationInput(rawError);
  if (!trimmed) return {};
  try {
    const parsed = (0, _assistantErrorFormatCuUvHfKt.o)(trimmed);
    const requestId = parsed?.requestId ?? (0, _stringCoerceDyL154ka.c)(trimmed.match(REQUEST_ID_RE)?.[1]);
    const requestIdHash = requestId ? (0, _redactIdentifierDBO6OkZP.t)(requestId, { len: 12 }) : void 0;
    const rawFingerprint = buildObservationFingerprint({
      raw: trimmed,
      requestId,
      httpCode: parsed?.httpCode,
      type: parsed?.type,
      message: parsed?.message
    });
    const redactedRawPreview = replaceRequestIdPreview(redactObservationText(trimmed), requestId);
    const redactedProviderMessage = replaceRequestIdPreview(redactObservationText(parsed?.message), requestId);
    return {
      rawErrorPreview: truncateForObservation(redactedRawPreview, RAW_ERROR_PREVIEW_MAX_CHARS),
      rawErrorHash: (0, _redactIdentifierDBO6OkZP.t)(trimmed, { len: 12 }),
      rawErrorFingerprint: rawFingerprint ? (0, _redactIdentifierDBO6OkZP.t)(rawFingerprint, { len: 12 }) : void 0,
      httpCode: parsed?.httpCode,
      providerRuntimeFailureKind: (0, _errorsDYNDQcd.r)({
        status: parsed?.httpCode ? Number(parsed.httpCode) : void 0,
        message: trimmed,
        provider: opts?.provider
      }),
      providerErrorType: parsed?.type,
      providerErrorMessagePreview: truncateForObservation(redactedProviderMessage, PROVIDER_ERROR_PREVIEW_MAX_CHARS),
      requestIdHash
    };
  } catch {
    return {};
  }
}
function buildTextObservationFields(text, opts) {
  const observed = buildApiErrorObservationFields(text, opts);
  return {
    textPreview: observed.rawErrorPreview,
    textHash: observed.rawErrorHash,
    textFingerprint: observed.rawErrorFingerprint,
    httpCode: observed.httpCode,
    providerRuntimeFailureKind: observed.providerRuntimeFailureKind,
    providerErrorType: observed.providerErrorType,
    providerErrorMessagePreview: observed.providerErrorMessagePreview,
    requestIdHash: observed.requestIdHash
  };
}
//#endregion
//#region src/agents/failover-policy.ts
function shouldAllowCooldownProbeForReason(reason) {
  return reason === "rate_limit" || reason === "overloaded" || reason === "billing" || reason === "unknown" || reason === "empty_response" || reason === "no_error_details" || reason === "unclassified" || reason === "timeout";
}
function shouldUseTransientCooldownProbeSlot(reason) {
  return reason === "rate_limit" || reason === "overloaded" || reason === "unknown" || reason === "empty_response" || reason === "no_error_details" || reason === "unclassified" || reason === "timeout";
}
function shouldPreserveTransientCooldownProbeSlot(reason) {
  return reason === "model_not_found" || reason === "format" || reason === "auth" || reason === "auth_permanent" || reason === "session_expired";
}
//#endregion
//#region src/agents/harness/errors.ts
var MissingAgentHarnessError = class extends Error {
  constructor(harnessId) {
    super(`Requested agent harness "${harnessId}" is not registered.`);
    this.name = "MissingAgentHarnessError";
    this.harnessId = harnessId;
  }
};exports.s = MissingAgentHarnessError;
function isMissingAgentHarnessError(err) {
  return err instanceof MissingAgentHarnessError;
}
//#endregion
//#region src/agents/live-model-switch-error.ts
var LiveSessionModelSwitchError = class extends Error {
  constructor(selection) {
    super(`Live session model switch requested: ${selection.provider}/${selection.model}`);
    this.name = "LiveSessionModelSwitchError";
    this.provider = selection.provider;
    this.model = selection.model;
    this.authProfileId = selection.authProfileId;
    this.authProfileIdSource = selection.authProfileIdSource;
  }
};
//#endregion
//#region src/agents/model-fallback-observation.ts
exports.o = LiveSessionModelSwitchError;const decisionLog = (0, _subsystemDSPWLoK.t)("model-fallback").child("decision");
function isModelFallbackDecisionLogEnabled() {
  return decisionLog.isEnabled("warn");
}
function buildErrorObservationFields(error) {
  const observed = buildTextObservationFields(error);
  return {
    errorPreview: observed.textPreview,
    errorHash: observed.textHash,
    errorFingerprint: observed.textFingerprint,
    httpCode: observed.httpCode,
    providerErrorType: observed.providerErrorType,
    providerErrorMessagePreview: observed.providerErrorMessagePreview,
    requestIdHash: observed.requestIdHash
  };
}
function formatModelRef(candidate) {
  return `${candidate.provider}/${candidate.model}`;
}
function buildFallbackStepFields(params) {
  const lastPreviousAttempt = params.previousAttempts?.at(-1);
  if (params.decision === "candidate_succeeded") {
    if (!lastPreviousAttempt) return;
    return {
      fallbackStepType: "fallback_step",
      fallbackStepFromModel: `${lastPreviousAttempt.provider}/${lastPreviousAttempt.model}`,
      fallbackStepToModel: formatModelRef(params.candidate),
      ...(lastPreviousAttempt.reason ? { fallbackStepFromFailureReason: lastPreviousAttempt.reason } : {}),
      ...(lastPreviousAttempt.error ? { fallbackStepFromFailureDetail: lastPreviousAttempt.error } : {}),
      ...(typeof params.attempt === "number" ? { fallbackStepChainPosition: params.attempt } : {}),
      fallbackStepFinalOutcome: "succeeded"
    };
  }
  const observed = buildErrorObservationFields(params.error);
  return {
    fallbackStepType: "fallback_step",
    fallbackStepFromModel: formatModelRef(params.candidate),
    ...(params.nextCandidate ? { fallbackStepToModel: formatModelRef(params.nextCandidate) } : {}),
    ...(params.reason ? { fallbackStepFromFailureReason: params.reason } : {}),
    ...(observed.providerErrorMessagePreview ?? observed.errorPreview ? { fallbackStepFromFailureDetail: observed.providerErrorMessagePreview ?? observed.errorPreview } : {}),
    ...(typeof params.attempt === "number" ? { fallbackStepChainPosition: params.attempt } : {}),
    fallbackStepFinalOutcome: params.nextCandidate ? "next_fallback" : "chain_exhausted"
  };
}
function logModelFallbackDecision(params) {
  const nextText = params.nextCandidate ? `${(0, _ansi4r6vVvJt.t)(params.nextCandidate.provider)}/${(0, _ansi4r6vVvJt.t)(params.nextCandidate.model)}` : "none";
  const reasonText = params.reason ?? "unknown";
  const observedError = buildErrorObservationFields(params.error);
  const detailText = observedError.providerErrorMessagePreview ?? observedError.errorPreview;
  const fallbackStepFields = params.decision === "skip_candidate" || params.decision === "candidate_failed" || params.decision === "candidate_succeeded" ? buildFallbackStepFields({
    decision: params.decision,
    candidate: params.candidate,
    reason: params.reason,
    error: params.error,
    nextCandidate: params.nextCandidate,
    attempt: params.attempt,
    previousAttempts: params.previousAttempts
  }) : void 0;
  const providerErrorTypeSuffix = observedError.providerErrorType ? ` providerErrorType=${(0, _ansi4r6vVvJt.t)(observedError.providerErrorType)}` : "";
  const detailSuffix = detailText ? ` detail=${(0, _ansi4r6vVvJt.t)(detailText)}` : "";
  decisionLog.warn("model fallback decision", {
    event: "model_fallback_decision",
    tags: [
    "error_handling",
    "model_fallback",
    params.decision],

    runId: params.runId,
    sessionId: params.sessionId,
    lane: params.lane,
    decision: params.decision,
    requestedProvider: params.requestedProvider,
    requestedModel: params.requestedModel,
    candidateProvider: params.candidate.provider,
    candidateModel: params.candidate.model,
    attempt: params.attempt,
    total: params.total,
    reason: params.reason,
    status: params.status,
    code: params.code,
    ...observedError,
    ...fallbackStepFields,
    nextCandidateProvider: params.nextCandidate?.provider,
    nextCandidateModel: params.nextCandidate?.model,
    isPrimary: params.isPrimary,
    requestedModelMatched: params.requestedModelMatched,
    fallbackConfigured: params.fallbackConfigured,
    allowTransientCooldownProbe: params.allowTransientCooldownProbe,
    profileCount: params.profileCount,
    previousAttempts: params.previousAttempts?.map((attempt) => ({
      provider: attempt.provider,
      model: attempt.model,
      reason: attempt.reason,
      status: attempt.status,
      code: attempt.code,
      ...buildErrorObservationFields(attempt.error)
    })),
    consoleMessage: `model fallback decision: decision=${params.decision} requested=${(0, _ansi4r6vVvJt.t)(params.requestedProvider)}/${(0, _ansi4r6vVvJt.t)(params.requestedModel)} candidate=${(0, _ansi4r6vVvJt.t)(params.candidate.provider)}/${(0, _ansi4r6vVvJt.t)(params.candidate.model)} reason=${reasonText}${providerErrorTypeSuffix} next=${nextText}${detailSuffix}`
  });
  return fallbackStepFields;
}
//#endregion
//#region src/agents/session-suspension.ts
const log$1 = (0, _subsystemDSPWLoK.t)("session-suspension");
const DEFAULT_CUSTOM_LANE_RESUME_CONCURRENCY = 1;
const laneResumeTimers = /* @__PURE__ */new Map();
function resolveLaneResumeConcurrency(cfg, laneId) {
  switch (laneId) {
    case "main":return (0, _agentLimitsY6_vNNMs.t)(cfg);
    case "subagent":return (0, _agentLimitsY6_vNNMs.n)(cfg);
    case "cron":
    case "cron-nested":{
        const raw = cfg?.cron?.maxConcurrentRuns;
        return typeof raw === "number" && Number.isFinite(raw) ? Math.max(1, Math.floor(raw)) : 1;
      }
    default:return DEFAULT_CUSTOM_LANE_RESUME_CONCURRENCY;
  }
}
function resolveSessionSuspensionReason(reason) {
  if (reason === "billing") return "manual";
  if (reason === "rate_limit") return "quota_exhausted";
  return "circuit_open";
}
function scheduleLaneAutoResume(laneId, delayMs, resumeConcurrency) {
  const existing = laneResumeTimers.get(laneId);
  if (existing) clearTimeout(existing);
  const timer = setTimeout(() => {
    laneResumeTimers.delete(laneId);
    (0, _commandQueueDa2Lh3Ua.m)(laneId, resumeConcurrency);
    log$1.info("auto-resumed lane after suspension TTL", {
      laneId,
      delayMs,
      resumeConcurrency
    });
  }, delayMs);
  if (typeof timer.unref === "function") timer.unref();
  laneResumeTimers.set(laneId, timer);
}
async function suspendSession(params) {
  if (!params.cfg) return;
  const { sessionKey, storePath } = (0, _sessionDUinUmLM.i)({
    cfg: params.cfg,
    sessionId: params.sessionId,
    agentId: params.agentDir ? _nodePath.default.basename(params.agentDir) : void 0
  });
  if (!sessionKey) return;
  const ttlMs = params.ttlMs ?? 18e5;
  const now = Date.now();
  try {
    await (0, _storeBmtchQvp.d)({
      storePath,
      sessionKey,
      update: async () => ({ quotaSuspension: {
          schemaVersion: 1,
          suspendedAt: now,
          reason: params.reason,
          failedProvider: params.failedProvider,
          failedModel: params.failedModel,
          summary: params.summary,
          laneId: params.laneId,
          expectedResumeBy: now + ttlMs,
          state: "suspended"
        } })
    });
  } catch (err) {
    log$1.warn("failed to persist quota suspension; not throttling lane", {
      sessionId: params.sessionId,
      laneId: params.laneId,
      error: err instanceof Error ? err.message : String(err)
    });
    return;
  }
  if (params.laneId) {
    (0, _commandQueueDa2Lh3Ua.m)(params.laneId, 0);
    scheduleLaneAutoResume(params.laneId, ttlMs, resolveLaneResumeConcurrency(params.cfg, params.laneId));
  }
}
//#endregion
//#region src/agents/model-fallback.ts
const log = (0, _subsystemDSPWLoK.t)("model-fallback");
/**
* Structured error thrown when all model fallback candidates have been
* exhausted. Carries per-attempt details so callers can build informative
* user-facing messages (e.g. "rate-limited, retry in 30 s").
*/
var FallbackSummaryError = class extends Error {
  constructor(message, attempts, soonestCooldownExpiry, cause, attribution) {
    super(message, { cause });
    this.name = "FallbackSummaryError";
    this.attempts = attempts;
    this.soonestCooldownExpiry = soonestCooldownExpiry;
    this.sessionId = attribution?.sessionId;
    this.lane = attribution?.lane;
  }
};
function isFallbackSummaryError(err) {
  return err instanceof FallbackSummaryError;
}
/**
* Fallback abort check. Only treats explicit AbortError names as user aborts.
* Message-based checks (e.g., "aborted") can mask timeouts and skip fallback.
*/
function isFallbackAbortError(err) {
  if (!err || typeof err !== "object") return false;
  if ((0, _failoverErrorCZCIurQK.i)(err)) return false;
  return ("name" in err ? String(err.name) : "") === "AbortError";
}
function shouldRethrowAbort(err) {
  return isFallbackAbortError(err) && !(0, _failoverErrorCZCIurQK.o)(err);
}
function createModelCandidateCollector(allowlist) {
  const seen = /* @__PURE__ */new Set();
  const candidates = [];
  const addCandidate = (candidate, enforceAllowlist) => {
    if (!candidate.provider || !candidate.model) return;
    const key = (0, _modelSelectionNormalizeCBfQoFd.n)(candidate.provider, candidate.model);
    if (seen.has(key)) return;
    if (enforceAllowlist && allowlist && !allowlist.has(key)) return;
    seen.add(key);
    candidates.push(candidate);
  };
  const addExplicitCandidate = (candidate) => {
    addCandidate(candidate, false);
  };
  const addAllowlistedCandidate = (candidate) => {
    addCandidate(candidate, true);
  };
  return {
    candidates,
    addExplicitCandidate,
    addAllowlistedCandidate
  };
}
const modelFallbackAuthRuntimeLoader = (0, _lazyPromiseDjskx0qC.t)(() => Promise.resolve().then(() => jitiImport("./model-fallback-auth.runtime.js").then((m) => _interopRequireWildcard(m))));
async function loadModelFallbackAuthRuntime() {
  return await modelFallbackAuthRuntimeLoader.load();
}
function buildFallbackSuccess(params) {
  return {
    result: params.result,
    provider: params.provider,
    model: params.model,
    attempts: params.attempts
  };
}
async function runFallbackCandidate(params) {
  try {
    return {
      ok: true,
      result: params.options ? await params.run(params.provider, params.model, params.options) : await params.run(params.provider, params.model)
    };
  } catch (err) {
    if ((0, _commandQueueDa2Lh3Ua.u)(err)) throw err;
    const normalizedFailover = (0, _failoverErrorCZCIurQK.n)(err, {
      provider: params.provider,
      model: params.model,
      sessionId: params.attribution?.sessionId,
      lane: params.attribution?.lane
    });
    if (shouldRethrowAbort(err) && !normalizedFailover) throw err;
    return {
      ok: false,
      error: normalizedFailover ?? err
    };
  }
}
async function runFallbackAttempt(params) {
  const runResult = await runFallbackCandidate({
    run: params.run,
    provider: params.provider,
    model: params.model,
    options: params.options,
    attribution: params.attribution
  });
  if (runResult.ok) {
    const classifiedError = resolveResultClassificationError(await params.classifyResult?.({
      result: runResult.result,
      provider: params.provider,
      model: params.model,
      attempt: params.attempt,
      total: params.total
    }), {
      provider: params.provider,
      model: params.model,
      attribution: params.attribution
    });
    if (classifiedError) return { error: classifiedError };
    return { success: buildFallbackSuccess({
        result: runResult.result,
        provider: params.provider,
        model: params.model,
        attempts: params.attempts
      }) };
  }
  return { error: runResult.error };
}
function resolveResultClassificationError(classification, params) {
  if (!classification) return null;
  if ("error" in classification) return classification.error;
  const message = (0, _stringCoerceDyL154ka.c)(classification.message);
  if (!message) return null;
  return new _failoverErrorCZCIurQK.t(message, {
    reason: classification.reason ?? "unknown",
    provider: params.provider,
    model: params.model,
    sessionId: params.attribution?.sessionId,
    lane: params.attribution?.lane,
    status: classification.status,
    code: classification.code,
    rawError: classification.rawError
  });
}
function sameModelCandidate(a, b) {
  return a.provider === b.provider && a.model === b.model;
}
function isCliAgentRuntime(runtime, cfg) {
  const normalized = (0, _stringCoerceDyL154ka.c)(runtime);
  if (!normalized) return false;
  return (0, _modelRuntimeAliasesD35Lx2no.n)(normalized) || (0, _modelSelectionCliDSHhXIv.t)(normalized, cfg);
}
async function assertModelFallbackCandidateHarnessAvailable(params) {
  if (!params.cfg) return;
  const agentHarnessRuntimeOverride = params.resolveAgentHarnessRuntimeOverride?.(params.provider, params.model);
  if ((0, _modelSelectionCliDSHhXIv.t)(params.provider, params.cfg)) return;
  const agentRuntimeOverride = (0, _stringCoerceDyL154ka.c)(agentHarnessRuntimeOverride);
  const harnessPolicy = (0, _policyBwWhR0D.t)({
    provider: params.provider,
    modelId: params.model,
    config: params.cfg,
    agentId: params.agentId,
    sessionKey: params.sessionKey
  });
  const agentRuntime = agentRuntimeOverride ?? harnessPolicy.runtime;
  const agentRuntimeSource = agentRuntimeOverride ? "model" : harnessPolicy.runtimeSource;
  if (isCliAgentRuntime(agentRuntime, params.cfg)) return;
  await params.prepareAgentHarnessRuntime?.({
    provider: params.provider,
    model: params.model,
    agentHarnessRuntimeOverride
  });
  if (agentRuntime !== "auto" && agentRuntime !== "pi" && !(agentRuntime === "codex" && agentRuntimeSource === "implicit") && !(0, _registryBiKIFOzv.r)(agentRuntime)) throw new MissingAgentHarnessError(agentRuntime);
}
function recordFailedCandidateAttempt(params) {
  const described = (0, _failoverErrorCZCIurQK.r)(params.error);
  params.attempts.push({
    provider: params.candidate.provider,
    model: params.candidate.model,
    error: described.rawError ?? described.message,
    reason: described.reason ?? "unknown",
    status: described.status,
    code: described.code
  });
  return logModelFallbackDecision({
    decision: "candidate_failed",
    runId: params.runId,
    sessionId: params.sessionId,
    lane: params.lane,
    requestedProvider: params.requestedProvider ?? params.candidate.provider,
    requestedModel: params.requestedModel ?? params.candidate.model,
    candidate: params.candidate,
    attempt: params.attempt,
    total: params.total,
    reason: described.reason,
    status: described.status,
    code: described.code,
    error: described.rawError ?? described.message,
    nextCandidate: params.nextCandidate,
    isPrimary: params.isPrimary,
    requestedModelMatched: params.requestedModelMatched,
    fallbackConfigured: params.fallbackConfigured
  });
}
function appendFailedCandidateAttempt(params) {
  const described = (0, _failoverErrorCZCIurQK.r)(params.error);
  params.attempts.push({
    provider: params.candidate.provider,
    model: params.candidate.model,
    error: described.rawError ?? described.message,
    reason: described.reason ?? "unknown",
    status: described.status,
    code: described.code
  });
}
function findLiveSessionModelSwitchRedirectIndex(params) {
  const targetKey = (0, _modelSelectionNormalizeCBfQoFd.n)(params.error.provider, params.error.model);
  for (let i = params.currentIndex + 1; i < params.candidates.length; i += 1) {
    const candidate = params.candidates[i];
    if ((0, _modelSelectionNormalizeCBfQoFd.n)(candidate.provider, candidate.model) === targetKey) return i;
  }
  return null;
}
function throwFallbackFailureSummary(params) {
  if (params.attempts.length <= 1 && params.lastError) throw params.lastError;
  if (params.attribution?.sessionId) suspendSession({
    cfg: params.cfg,
    agentDir: params.agentDir,
    sessionId: params.attribution.sessionId,
    laneId: params.attribution.lane,
    reason: "circuit_open",
    failedProvider: params.attempts[params.attempts.length - 1]?.provider ?? "unknown",
    failedModel: params.attempts[params.attempts.length - 1]?.model ?? "unknown"
  });
  const summary = params.attempts.length > 0 ? params.attempts.map(params.formatAttempt).join(" | ") : "unknown";
  throw new FallbackSummaryError(`All ${params.label} failed (${params.attempts.length || params.candidates.length}): ${summary}`, params.attempts, params.soonestCooldownExpiry ?? null, params.lastError instanceof Error ? params.lastError : void 0, params.attribution);
}
function resolveFallbackSoonestCooldownExpiry(params) {
  if (!params.authRuntime || !params.authStore) return null;
  const refreshedStore = params.authRuntime.loadAuthProfileStoreForRuntime(params.agentDir, {
    readOnly: true,
    externalCli: (0, _externalCliDiscoveryD0JQl8du.i)({
      cfg: params.cfg,
      providers: params.candidates.map((candidate) => candidate.provider)
    })
  });
  let soonest = null;
  for (const candidate of params.candidates) {
    const ids = params.authRuntime.resolveAuthProfileOrder({
      cfg: params.cfg,
      store: refreshedStore,
      provider: candidate.provider
    });
    const candidateSoonest = params.authRuntime.getSoonestCooldownExpiry(refreshedStore, ids, { forModel: candidate.model });
    if (typeof candidateSoonest === "number" && Number.isFinite(candidateSoonest) && (soonest === null || candidateSoonest < soonest)) soonest = candidateSoonest;
  }
  return soonest;
}
function resolveImageFallbackCandidates(params) {
  const aliasIndex = (0, _modelSelectionSharedClxdEp4X.i)({
    cfg: params.cfg ?? {},
    defaultProvider: params.defaultProvider,
    manifestPlugins: params.manifestPlugins
  });
  const { candidates, addExplicitCandidate, addAllowlistedCandidate } = createModelCandidateCollector((0, _modelSelectionSharedClxdEp4X.n)({
    cfg: params.cfg,
    defaultProvider: params.defaultProvider,
    manifestPlugins: params.manifestPlugins
  }));
  const addRaw = (raw, opts) => {
    const resolved = (0, _modelSelectionSharedClxdEp4X.x)({
      raw,
      defaultProvider: params.defaultProvider,
      aliasIndex,
      manifestPlugins: params.manifestPlugins
    });
    if (!resolved) return;
    if (opts?.allowlist) {
      addAllowlistedCandidate(resolved.ref);
      return;
    }
    addExplicitCandidate(resolved.ref);
  };
  if (params.modelOverride?.trim()) addRaw(params.modelOverride);else
  {
    const primary = (0, _modelInputChW9XXsQ.i)(params.cfg?.agents?.defaults?.imageModel);
    if (primary?.trim()) addRaw(primary);
  }
  const imageFallbacks = (0, _modelInputChW9XXsQ.r)(params.cfg?.agents?.defaults?.imageModel);
  for (const raw of imageFallbacks) addRaw(raw);
  return candidates;
}
function resolveImageFallbackDefaultProvider(cfg) {
  const configuredPrimary = (0, _modelInputChW9XXsQ.i)(cfg?.agents?.defaults?.imageModel);
  if (configuredPrimary?.trim()) {
    const resolved = (0, _modelSelectionSharedClxdEp4X.x)({
      raw: configuredPrimary,
      defaultProvider: _defaultsMDjiWzE.r,
      aliasIndex: (0, _modelSelectionSharedClxdEp4X.i)({
        cfg: cfg ?? {},
        defaultProvider: _defaultsMDjiWzE.r
      })
    });
    if (resolved?.ref.provider) return resolved.ref.provider;
  }
  return _defaultsMDjiWzE.r;
}
function resolveFallbackCandidates(params) {
  const primary = params.cfg ? (0, _modelSelectionSharedClxdEp4X.v)({
    cfg: params.cfg,
    defaultProvider: _defaultsMDjiWzE.r,
    defaultModel: _defaultsMDjiWzE.n,
    manifestPlugins: params.manifestPlugins
  }) : null;
  const defaultProvider = primary?.provider ?? "openai";
  const defaultModel = primary?.model ?? "gpt-5.5";
  const providerRaw = (0, _stringCoerceDyL154ka.c)(params.provider) || defaultProvider;
  const modelRaw = (0, _stringCoerceDyL154ka.c)(params.model) || defaultModel;
  const normalizedPrimary = (0, _modelSelectionNormalizeCBfQoFd.r)(providerRaw, modelRaw, { manifestPlugins: params.manifestPlugins });
  const aliasIndex = (0, _modelSelectionSharedClxdEp4X.i)({
    cfg: params.cfg ?? {},
    defaultProvider,
    manifestPlugins: params.manifestPlugins
  });
  const { candidates, addExplicitCandidate } = createModelCandidateCollector((0, _modelSelectionSharedClxdEp4X.n)({
    cfg: params.cfg,
    defaultProvider,
    manifestPlugins: params.manifestPlugins
  }));
  const resolvedModelAlias = (0, _modelSelectionSharedClxdEp4X.x)({
    raw: modelRaw,
    defaultProvider: providerRaw,
    aliasIndex,
    manifestPlugins: params.manifestPlugins
  });
  const resolvedProviderModelAlias = (0, _modelSelectionSharedClxdEp4X.x)({
    raw: `${providerRaw}/${modelRaw}`,
    defaultProvider,
    aliasIndex,
    manifestPlugins: params.manifestPlugins
  });
  const resolvedBareModelAlias = resolvedModelAlias?.alias && (resolvedModelAlias.ref.provider === normalizedPrimary.provider || normalizedPrimary.provider === defaultProvider) ? resolvedModelAlias.ref : null;
  const resolvedPrimary = (resolvedProviderModelAlias?.alias ? resolvedProviderModelAlias.ref : null) ?? resolvedBareModelAlias ?? normalizedPrimary;
  addExplicitCandidate((0, _modelSelectionNormalizeCBfQoFd.r)(resolvedPrimary.provider, resolvedPrimary.model, { manifestPlugins: params.manifestPlugins }));
  const modelFallbacks = params.fallbacksOverride !== void 0 ? params.fallbacksOverride : (0, _modelInputChW9XXsQ.r)(params.cfg?.agents?.defaults?.model);
  for (const raw of modelFallbacks) {
    const resolved = (0, _modelSelectionSharedClxdEp4X.x)({
      raw,
      defaultProvider,
      aliasIndex,
      manifestPlugins: params.manifestPlugins
    });
    if (!resolved) continue;
    addExplicitCandidate(resolved.ref);
  }
  if (params.fallbacksOverride === void 0 && primary?.provider && primary.model) addExplicitCandidate({
    provider: primary.provider,
    model: primary.model
  });
  return candidates;
}
const lastProbeAttempt = /* @__PURE__ */new Map();
const MIN_PROBE_INTERVAL_MS = 3e4;
const PROBE_MARGIN_MS = 120 * 1e3;
const PROBE_SCOPE_DELIMITER = "::";
const PROBE_STATE_TTL_MS = 1440 * 60 * 1e3;
const MAX_PROBE_KEYS = 256;
function resolveProbeThrottleKey(provider, agentDir) {
  const scope = (0, _stringCoerceDyL154ka.c)(agentDir) ?? "";
  return scope ? `${scope}${PROBE_SCOPE_DELIMITER}${provider}` : provider;
}
function pruneProbeState(now) {
  for (const [key, ts] of lastProbeAttempt) if (!Number.isFinite(ts) || ts <= 0 || now - ts > PROBE_STATE_TTL_MS) lastProbeAttempt.delete(key);
}
function enforceProbeStateCap() {
  while (lastProbeAttempt.size > MAX_PROBE_KEYS) {
    let oldestKey = null;
    let oldestTs = Number.POSITIVE_INFINITY;
    for (const [key, ts] of lastProbeAttempt) if (ts < oldestTs) {
      oldestKey = key;
      oldestTs = ts;
    }
    if (!oldestKey) break;
    lastProbeAttempt.delete(oldestKey);
  }
}
function isProbeThrottleOpen(now, throttleKey) {
  pruneProbeState(now);
  return now - (lastProbeAttempt.get(throttleKey) ?? 0) >= MIN_PROBE_INTERVAL_MS;
}
function markProbeAttempt(now, throttleKey) {
  pruneProbeState(now);
  lastProbeAttempt.set(throttleKey, now);
  enforceProbeStateCap();
}
function shouldProbePrimaryDuringCooldown(params) {
  if (!params.isPrimary || !params.hasFallbackCandidates) return false;
  if (!isProbeThrottleOpen(params.now, params.throttleKey)) return false;
  const soonest = params.authRuntime.getSoonestCooldownExpiry(params.authStore, params.profileIds, {
    now: params.now,
    forModel: params.model
  });
  if (soonest === null || !Number.isFinite(soonest)) return true;
  return params.now >= soonest - PROBE_MARGIN_MS;
}
function resolveCooldownDecision(params) {
  const shouldProbe = shouldProbePrimaryDuringCooldown({
    isPrimary: params.isPrimary,
    hasFallbackCandidates: params.hasFallbackCandidates,
    now: params.now,
    throttleKey: params.probeThrottleKey,
    authRuntime: params.authRuntime,
    authStore: params.authStore,
    profileIds: params.profileIds,
    model: params.candidate.model
  });
  const inferredReason = params.authRuntime.resolveProfilesUnavailableReason({
    store: params.authStore,
    profileIds: params.profileIds,
    now: params.now
  }) ?? "unknown";
  if (inferredReason === "auth" || inferredReason === "auth_permanent") return {
    type: "skip",
    reason: inferredReason,
    error: `Provider ${params.candidate.provider} has ${inferredReason} issue (skipping all models)`
  };
  if (inferredReason === "billing") {
    const shouldProbeSingleProviderBilling = params.isPrimary && !params.hasFallbackCandidates && isProbeThrottleOpen(params.now, params.probeThrottleKey);
    if (params.isPrimary && (shouldProbe || shouldProbeSingleProviderBilling)) return {
      type: "attempt",
      reason: inferredReason,
      markProbe: true
    };
    return {
      type: "suspend_lanes",
      reason: inferredReason,
      leaderCandidate: params.candidate
    };
  }
  if (!(params.isPrimary && (!params.requestedModel || shouldProbe) || !params.isPrimary && shouldUseTransientCooldownProbeSlot(inferredReason))) return {
    type: "suspend_lanes",
    reason: inferredReason,
    leaderCandidate: params.candidate
  };
  return {
    type: "attempt",
    reason: inferredReason,
    markProbe: params.isPrimary && shouldProbe
  };
}
async function runWithModelFallback(params) {
  const candidates = resolveFallbackCandidates({
    cfg: params.cfg,
    provider: params.provider,
    model: params.model,
    fallbacksOverride: params.fallbacksOverride,
    manifestPlugins: params.manifestPlugins
  });
  const authRuntime = !params.skipAuthProfileRuntime && params.cfg && (0, _sourceCheckBMw3fGLx.t)(params.agentDir) ? await loadModelFallbackAuthRuntime() : null;
  const authStore = authRuntime ? authRuntime.ensureAuthProfileStore(params.agentDir, { externalCli: (0, _externalCliDiscoveryD0JQl8du.i)({
      cfg: params.cfg,
      providers: candidates.map((candidate) => candidate.provider)
    }) }) : null;
  const attempts = [];
  let lastError;
  const cooldownProbeUsedProviders = /* @__PURE__ */new Set();
  const observeDecision = async (decision) => {
    if (!params.onFallbackStep && !isModelFallbackDecisionLogEnabled()) return;
    const fallbackStep = logModelFallbackDecision(decision);
    if (fallbackStep) await params.onFallbackStep?.(fallbackStep);
  };
  const observeFailedCandidate = async (failedAttempt) => {
    if (!params.onFallbackStep && !isModelFallbackDecisionLogEnabled()) {
      appendFailedCandidateAttempt(failedAttempt);
      return;
    }
    const fallbackStep = recordFailedCandidateAttempt(failedAttempt);
    if (fallbackStep) await params.onFallbackStep?.(fallbackStep);
  };
  const hasFallbackCandidates = candidates.length > 1;
  const requestedCandidate = candidates[0];
  for (let i = 0; i < candidates.length; i += 1) {
    const candidate = candidates[i];
    await assertModelFallbackCandidateHarnessAvailable({
      cfg: params.cfg,
      agentId: params.agentId,
      sessionKey: params.sessionKey,
      resolveAgentHarnessRuntimeOverride: params.resolveAgentHarnessRuntimeOverride,
      prepareAgentHarnessRuntime: params.prepareAgentHarnessRuntime,
      ...candidate
    });
    const isPrimary = i === 0;
    const requestedModel = requestedCandidate ? sameModelCandidate(candidate, requestedCandidate) : false;
    let runOptions;
    let attemptedDuringCooldown = false;
    let transientProbeProviderForAttempt = null;
    if (authRuntime && authStore) {
      const profileIds = authRuntime.resolveAuthProfileOrder({
        cfg: params.cfg,
        store: authStore,
        provider: candidate.provider
      });
      const isAnyProfileAvailable = profileIds.some((id) => !authRuntime.isProfileInCooldown(authStore, id, void 0, candidate.model));
      if (profileIds.length > 0 && !isAnyProfileAvailable) {
        const now = Date.now();
        const probeThrottleKey = resolveProbeThrottleKey(candidate.provider, params.agentDir);
        const decision = resolveCooldownDecision({
          candidate,
          isPrimary,
          requestedModel,
          hasFallbackCandidates,
          now,
          probeThrottleKey,
          authRuntime,
          authStore,
          profileIds
        });
        if (decision.type === "suspend_lanes") {
          const error = `Provider ${candidate.provider} is in cooldown (suspending lanes)`;
          attempts.push({
            provider: candidate.provider,
            model: candidate.model,
            error,
            reason: decision.reason
          });
          if (params.sessionId) {
            (0, _diagnosticEventsBLgzARSp.r)({
              sessionId: params.sessionId,
              lane: params.lane,
              fromProvider: candidate.provider,
              fromModel: candidate.model,
              reason: decision.reason,
              suspended: true
            });
            suspendSession({
              cfg: params.cfg,
              agentDir: params.agentDir,
              sessionId: params.sessionId,
              laneId: params.lane,
              reason: resolveSessionSuspensionReason(decision.reason),
              failedProvider: candidate.provider,
              failedModel: candidate.model
            });
          }
          await observeDecision({
            decision: "skip_candidate",
            runId: params.runId,
            sessionId: params.sessionId,
            lane: params.lane,
            requestedProvider: params.provider,
            requestedModel: params.model,
            candidate,
            attempt: i + 1,
            total: candidates.length,
            reason: decision.reason,
            error,
            nextCandidate: candidates[i + 1],
            isPrimary,
            requestedModelMatched: requestedModel,
            fallbackConfigured: hasFallbackCandidates,
            profileCount: profileIds.length
          });
          continue;
        }
        if (decision.type === "skip") {
          attempts.push({
            provider: candidate.provider,
            model: candidate.model,
            error: decision.error,
            reason: decision.reason
          });
          await observeDecision({
            decision: "skip_candidate",
            runId: params.runId,
            sessionId: params.sessionId,
            lane: params.lane,
            requestedProvider: params.provider,
            requestedModel: params.model,
            candidate,
            attempt: i + 1,
            total: candidates.length,
            reason: decision.reason,
            error: decision.error,
            nextCandidate: candidates[i + 1],
            isPrimary,
            requestedModelMatched: requestedModel,
            fallbackConfigured: hasFallbackCandidates,
            profileCount: profileIds.length
          });
          continue;
        }
        if (decision.markProbe) markProbeAttempt(now, probeThrottleKey);
        if (shouldAllowCooldownProbeForReason(decision.reason)) {
          const isTransientCooldownReason = shouldUseTransientCooldownProbeSlot(decision.reason);
          if (isTransientCooldownReason && cooldownProbeUsedProviders.has(candidate.provider)) {
            const error = `Provider ${candidate.provider} is in cooldown (probe already attempted this run)`;
            attempts.push({
              provider: candidate.provider,
              model: candidate.model,
              error,
              reason: decision.reason
            });
            await observeDecision({
              decision: "skip_candidate",
              runId: params.runId,
              sessionId: params.sessionId,
              lane: params.lane,
              requestedProvider: params.provider,
              requestedModel: params.model,
              candidate,
              attempt: i + 1,
              total: candidates.length,
              reason: decision.reason,
              error,
              nextCandidate: candidates[i + 1],
              isPrimary,
              requestedModelMatched: requestedModel,
              fallbackConfigured: hasFallbackCandidates,
              profileCount: profileIds.length
            });
            continue;
          }
          runOptions = { allowTransientCooldownProbe: true };
          if (isTransientCooldownReason) transientProbeProviderForAttempt = candidate.provider;
        }
        attemptedDuringCooldown = true;
        await observeDecision({
          decision: "probe_cooldown_candidate",
          runId: params.runId,
          sessionId: params.sessionId,
          lane: params.lane,
          requestedProvider: params.provider,
          requestedModel: params.model,
          candidate,
          attempt: i + 1,
          total: candidates.length,
          reason: decision.reason,
          nextCandidate: candidates[i + 1],
          isPrimary,
          requestedModelMatched: requestedModel,
          fallbackConfigured: hasFallbackCandidates,
          allowTransientCooldownProbe: runOptions?.allowTransientCooldownProbe,
          profileCount: profileIds.length
        });
      }
    }
    const attemptRun = await runFallbackAttempt({
      run: params.run,
      ...candidate,
      attempts,
      options: runOptions,
      classifyResult: params.classifyResult,
      attempt: i + 1,
      total: candidates.length,
      attribution: {
        sessionId: params.sessionId,
        lane: params.lane
      }
    });
    if ("success" in attemptRun) {
      if (i > 0 || attempts.length > 0 || attemptedDuringCooldown) await observeDecision({
        decision: "candidate_succeeded",
        runId: params.runId,
        sessionId: params.sessionId,
        lane: params.lane,
        requestedProvider: params.provider,
        requestedModel: params.model,
        candidate,
        attempt: i + 1,
        total: candidates.length,
        previousAttempts: attempts,
        isPrimary,
        requestedModelMatched: requestedModel,
        fallbackConfigured: hasFallbackCandidates
      });
      const notFoundAttempt = i > 0 ? attempts.find((a) => a.reason === "model_not_found") : void 0;
      if (notFoundAttempt) log.warn(`Model "${(0, _ansi4r6vVvJt.t)(notFoundAttempt.provider)}/${(0, _ansi4r6vVvJt.t)(notFoundAttempt.model)}" not found. Fell back to "${(0, _ansi4r6vVvJt.t)(candidate.provider)}/${(0, _ansi4r6vVvJt.t)(candidate.model)}".`);
      return attemptRun.success;
    }
    const err = attemptRun.error;
    {
      if ((0, _failoverErrorCZCIurQK.a)(err)) throw err;
      if (transientProbeProviderForAttempt) {
        const probeFailureReason = (0, _failoverErrorCZCIurQK.r)(err).reason;
        if (!shouldPreserveTransientCooldownProbeSlot(probeFailureReason)) cooldownProbeUsedProviders.add(transientProbeProviderForAttempt);
      }
      if ((0, _errorsDYNDQcd.g)((0, _errorsB3ZrCRlt.i)(err))) throw err;
      if (isMissingAgentHarnessError(err)) throw err;
      const normalized = (0, _failoverErrorCZCIurQK.n)(err, {
        provider: candidate.provider,
        model: candidate.model,
        sessionId: params.sessionId,
        lane: params.lane
      }) ?? err;
      if (err instanceof LiveSessionModelSwitchError) {
        const liveSwitchTargetIndex = findLiveSessionModelSwitchRedirectIndex({
          error: err,
          candidates,
          currentIndex: i
        });
        if (liveSwitchTargetIndex !== null) {
          i = liveSwitchTargetIndex - 1;
          continue;
        }
        const switchMsg = err.message;
        const switchNormalized = new _failoverErrorCZCIurQK.t(switchMsg, {
          reason: "unknown",
          provider: candidate.provider,
          model: candidate.model,
          sessionId: params.sessionId,
          lane: params.lane
        });
        lastError = switchNormalized;
        await observeFailedCandidate({
          attempts,
          candidate,
          error: switchNormalized,
          runId: params.runId,
          sessionId: params.sessionId,
          lane: params.lane,
          requestedProvider: params.provider,
          requestedModel: params.model,
          attempt: i + 1,
          total: candidates.length,
          nextCandidate: candidates[i + 1],
          isPrimary,
          requestedModelMatched: requestedModel,
          fallbackConfigured: hasFallbackCandidates
        });
        continue;
      }
      const isKnownFailover = (0, _failoverErrorCZCIurQK.i)(normalized);
      if (!isKnownFailover && i === candidates.length - 1) throw err;
      lastError = isKnownFailover ? normalized : err;
      await observeFailedCandidate({
        attempts,
        candidate,
        error: normalized,
        runId: params.runId,
        sessionId: params.sessionId,
        lane: params.lane,
        requestedProvider: params.provider,
        requestedModel: params.model,
        attempt: i + 1,
        total: candidates.length,
        nextCandidate: candidates[i + 1],
        isPrimary,
        requestedModelMatched: requestedModel,
        fallbackConfigured: hasFallbackCandidates
      });
      await params.onError?.({
        provider: candidate.provider,
        model: candidate.model,
        error: isKnownFailover ? normalized : err,
        attempt: i + 1,
        total: candidates.length
      });
    }
  }
  return throwFallbackFailureSummary({
    attempts,
    candidates,
    lastError,
    label: "models",
    formatAttempt: (attempt) => `${attempt.provider}/${attempt.model}: ${attempt.error}${attempt.reason ? ` (${attempt.reason})` : ""}`,
    soonestCooldownExpiry: resolveFallbackSoonestCooldownExpiry({
      authRuntime,
      authStore,
      agentDir: params.agentDir,
      cfg: params.cfg,
      candidates
    }),
    attribution: {
      sessionId: params.sessionId,
      lane: params.lane
    },
    cfg: params.cfg,
    agentDir: params.agentDir
  });
}
async function runWithImageModelFallback(params) {
  const candidates = resolveImageFallbackCandidates({
    cfg: params.cfg,
    defaultProvider: resolveImageFallbackDefaultProvider(params.cfg),
    modelOverride: params.modelOverride
  });
  if (candidates.length === 0) throw new Error("No image model configured. Set agents.defaults.imageModel.primary or agents.defaults.imageModel.fallbacks.");
  const attempts = [];
  let lastError;
  for (let i = 0; i < candidates.length; i += 1) {
    const candidate = candidates[i];
    const attemptRun = await runFallbackAttempt({
      run: params.run,
      ...candidate,
      attempts,
      attempt: i + 1,
      total: candidates.length
    });
    if ("success" in attemptRun) return attemptRun.success;
    {
      const err = attemptRun.error;
      lastError = err;
      attempts.push({
        provider: candidate.provider,
        model: candidate.model,
        error: (0, _errorsB3ZrCRlt.i)(err)
      });
      await params.onError?.({
        provider: candidate.provider,
        model: candidate.model,
        error: err,
        attempt: i + 1,
        total: candidates.length
      });
    }
  }
  return throwFallbackFailureSummary({
    attempts,
    candidates,
    lastError,
    label: "image models",
    formatAttempt: (attempt) => `${attempt.provider}/${attempt.model}: ${attempt.error}`,
    cfg: params.cfg
  });
}
//#endregion /* v9-37a58f480a0e48b7 */
