"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = isSingleUseReplyToMode;exports.t = createReplyReferencePlanner;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
//#region src/auto-reply/reply/reply-reference.ts
function isSingleUseReplyToMode(mode) {
  return mode === "first" || mode === "batched";
}
function createReplyReferencePlanner(options) {
  let hasReplied = options.hasReplied ?? false;
  const allowReference = options.allowReference !== false;
  const existingId = (0, _stringCoerceDyL154ka.c)(options.existingId);
  const startId = (0, _stringCoerceDyL154ka.c)(options.startId);
  const resolve = () => {
    if (!allowReference) return;
    if (options.replyToMode === "off") return;
    const id = existingId ?? startId;
    if (!id) return;
    if (options.replyToMode === "all") return id;
    if (isSingleUseReplyToMode(options.replyToMode) && hasReplied) return;
    return id;
  };
  const use = () => {
    const id = resolve();
    if (!id) return;
    hasReplied = true;
    return id;
  };
  const markSent = () => {
    hasReplied = true;
  };
  return {
    peek: resolve,
    use,
    markSent,
    hasReplied: () => hasReplied
  };
}
//#endregion /* v9-232d33a51a2451af */
