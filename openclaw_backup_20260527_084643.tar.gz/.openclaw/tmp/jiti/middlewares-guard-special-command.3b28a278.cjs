"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.guardSpecialCommand = void 0;


var _send = require("../../actions/text/send.js");
var _index = require("../../commands/upgrade/index.js");
var _upgrade = require("../../commands/upgrade/upgrade.js"); /**
 * Middleware: owner guard for /upgrade, /issue-log and other special commands.
 */ /**
 * Check whether the message is from the bot owner.
 */function isOwnerMessage(raw) {
  return Boolean(raw.bot_owner_id && raw.from_account === raw.bot_owner_id);
}
/**
 * Send a reply message via sendText action + deliver layer.
 */
async function sendReplyMessage(ctx, text) {
  const { account, isGroup, fromAccount, groupCode, wsClient } = ctx;
  const dt = {
    isGroup,
    target: isGroup ? groupCode : fromAccount,
    account,
    fromAccount: account.botId,
    wsClient,
    groupCode
  };
  await (0, _send.sendText)({ text, dt });
}
const guardSpecialCommand = exports.guardSpecialCommand = {
  name: "guard-special-command",
  handler: async (ctx, next) => {
    const { raw, rawBody, fromAccount, isGroup, groupCode } = ctx;
    const trimmedBody = rawBody.trim();
    // Upgrade command owner guard (supports /yuanbao-upgrade and /yuanbao-upgrade 1.2.3)
    const upgradeCmd = (0, _index.parseUpgradeCommand)(trimmedBody);
    if (upgradeCmd.matched) {
      ctx.log.info(`[guard-special-command] received ${trimmedBody} command`);
      if (!isOwnerMessage(raw)) {
        ctx.log.warn(`[guard-special-command] non-owner attempted ${trimmedBody}, rejected`, {
          fromAccount
        });
        const rejectText = isGroup ?
        `派中暂不支持该命令，请 Bot 创建人在私聊发送 ${trimmedBody} 进行升级` :
        "⚠️ 您无权执行此操作，仅 Bot 创建人可以执行此操作。";
        await sendReplyMessage(ctx, rejectText);
        return; // Abort pipeline
      }
      // Owner check passed; send "upgrading" prompt
      ctx.log.info(`[guard-special-command] owner triggered upgrade command ${trimmedBody}`, {
        fromAccount
      });
      // Execute upgrade here (middleware owns more context than the plugin command handler);
      // progress messages are streamed back via sendReplyMessage.
      const onProgress = async (text) => {
        try {
          await sendReplyMessage(ctx, text);
        }
        catch (err) {
          ctx.log.error("[guard-special-command] onProgress sendReplyMessage failed", {
            error: String(err)
          });
        }
      };
      try {
        const resultText = await (0, _upgrade.performUpgrade)(ctx.config, ctx.account.accountId, onProgress, upgradeCmd.version);
        if (resultText) {
          await sendReplyMessage(ctx, resultText);
        }
      }
      catch (err) {
        ctx.log.error("[guard-special-command] performUpgrade threw", { error: String(err) });
        await sendReplyMessage(ctx, "❌ 升级过程发生异常，请稍后重试。");
      }
      return;
    }
    // /issue-log owner guard
    if (trimmedBody.startsWith("/issue-log")) {
      ctx.log.info("[guard-special-command] received /issue-log command");
      if (!isOwnerMessage(raw)) {
        ctx.log.warn("[guard-special-command] non-owner attempted /issue-log, rejected", {
          fromAccount
        });
        const rejectText = isGroup ?
        "群聊暂不支持该命令，请 bot owner 私聊发送 /issue-log 导出日志" :
        "⚠️ 您无权导出日志，请联系 Bot 创建人操作。";
        await sendReplyMessage(ctx, rejectText);
        return; // Abort pipeline
      }
      // Group chat: redirect to direct message
      if (isGroup) {
        ctx.log.info("[guard-special-command] owner triggered /issue-log in group, redirecting to direct message", { fromAccount, groupCode });
        await sendReplyMessage(ctx, "群聊暂不支持该命令，请 bot owner 私聊发送 /issue-log 导出日志");
        return; // Abort pipeline
      }
      // C2C owner passed
      ctx.log.info("[guard-special-command] owner triggered log export command", { fromAccount });
      await sendReplyMessage(ctx, "📦 正在导出问题日志并压缩打包发送，请稍后...");
    }
    await next();
  }
}; /* v9-45d351de9227abe2 */
