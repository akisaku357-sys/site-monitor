"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.makeEnv = makeEnv;exports.nodeExecPath = nodeExecPath;exports.resolveNpmBin = resolveNpmBin;exports.resolveOpenClawBin = resolveOpenClawBin;var _nodePath = require("node:path");
var _runCommand = require("openclaw/plugin-sdk/run-command");
/**
 * Build child process env: prepend Node.js bin directory to PATH.
 *
 * Reads PATH / execPath only to make sure spawned `npm` / `openclaw` CLIs
 * can find Node-adjacent binaries. The result is passed to
 * `runPluginCommandWithTimeout`, never sent over the network.
 */
function makeEnv() {
  const nodeBinDir = (0, _nodePath.dirname)(process.execPath);
  const currentPath = process.env.PATH ?? "";
  return {
    ...process.env,
    PATH: currentPath.includes(nodeBinDir) ? currentPath : `${nodeBinDir}:${currentPath}`
  };
}
/**
 * Resolve npm executable path co-located with the current Node.js process.
 */
async function resolveNpmBin() {
  try {
    const result = await (0, _runCommand.runPluginCommandWithTimeout)({
      argv: ["which", "npm"],
      timeoutMs: 5000,
      env: makeEnv()
    });
    const resolved = result.stdout.trim();
    if (result.code === 0 && resolved) {
      return resolved;
    }
  }
  catch {

    // Fallback when which fails
  }return "npm";
}
/**
 * Resolve openclaw executable absolute path via `which openclaw`.
 * Falls back to 'openclaw' (relies on PATH) if which fails.
 */
async function resolveOpenClawBin() {
  try {
    const result = await (0, _runCommand.runPluginCommandWithTimeout)({
      argv: ["which", "openclaw"],
      timeoutMs: 5000,
      env: makeEnv()
    });
    const resolved = result.stdout.trim();
    if (result.code === 0 && resolved) {
      return resolved;
    }
  }
  catch {

    // Fallback when which fails
  }return "openclaw";
}
/** Node.js binary path, exposed so callers can log it without reading process.execPath themselves. */
function nodeExecPath() {
  return process.execPath;
} /* v9-3f4c3e6128aa32e2 */
