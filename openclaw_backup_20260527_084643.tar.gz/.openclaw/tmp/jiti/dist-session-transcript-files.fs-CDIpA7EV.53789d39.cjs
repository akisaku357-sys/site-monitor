"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.a = resolveSessionTranscriptCandidates;exports.i = cleanupArchivedSessionTranscripts;exports.n = archiveSessionTranscripts;exports.o = resolveStableSessionEndTranscript;exports.r = archiveSessionTranscriptsDetailed;exports.t = archiveFileOnDisk;var _homeDirBOPFpGo = require("./home-dir-BOPFpGo8.js");
var _artifactsBZhcmsUl = require("./artifacts-BZhcmsUl.js");
var _pathsBg3PO6Gj = require("./paths-Bg3PO6Gj.js");
var _transcriptEventsClYG_P1o = require("./transcript-events-ClYG_P1o.js");
var _nodeFs = _interopRequireDefault(require("node:fs"));
var _nodePath = _interopRequireDefault(require("node:path"));
var _nodeOs = _interopRequireDefault(require("node:os"));function _interopRequireDefault(e) {return e && e.__esModule ? e : { default: e };}
//#region src/gateway/session-transcript-files.fs.ts
function classifySessionTranscriptCandidate(sessionId, sessionFile) {
  const transcriptSessionId = extractGeneratedTranscriptSessionId(sessionFile);
  if (!transcriptSessionId) return "custom";
  return transcriptSessionId === sessionId ? "current" : "stale";
}
function extractGeneratedTranscriptSessionId(sessionFile) {
  const trimmed = sessionFile?.trim();
  if (!trimmed) return;
  const base = _nodePath.default.basename(trimmed);
  if (!base.endsWith(".jsonl")) return;
  const withoutExt = base.slice(0, -6);
  const topicIndex = withoutExt.indexOf("-topic-");
  if (topicIndex > 0) {
    const topicSessionId = withoutExt.slice(0, topicIndex);
    return looksLikeGeneratedSessionId(topicSessionId) ? topicSessionId : void 0;
  }
  const forkMatch = withoutExt.match(/^(\d{4}-\d{2}-\d{2}T[\w-]+(?:Z|[+-]\d{2}(?:-\d{2})?)?)_(.+)$/);
  if (forkMatch?.[2]) return looksLikeGeneratedSessionId(forkMatch[2]) ? forkMatch[2] : void 0;
  return looksLikeGeneratedSessionId(withoutExt) ? withoutExt : void 0;
}
function looksLikeGeneratedSessionId(value) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}
function canonicalizePathForComparison(filePath) {
  const resolved = _nodePath.default.resolve(filePath);
  try {
    return _nodeFs.default.realpathSync(resolved);
  } catch {
    return resolved;
  }
}
function resolveSessionTranscriptCandidates(sessionId, storePath, sessionFile, agentId) {
  const candidates = [];
  const sessionFileState = classifySessionTranscriptCandidate(sessionId, sessionFile);
  const pushCandidate = (resolve) => {
    try {
      candidates.push(resolve());
    } catch {}
  };
  if (storePath) {
    const sessionsDir = _nodePath.default.dirname(storePath);
    if (sessionFile && sessionFileState !== "stale") pushCandidate(() => (0, _pathsBg3PO6Gj.i)(sessionId, { sessionFile }, {
      sessionsDir,
      agentId
    }));
    pushCandidate(() => (0, _pathsBg3PO6Gj.s)(sessionId, sessionsDir));
    if (sessionFile && sessionFileState === "stale") pushCandidate(() => (0, _pathsBg3PO6Gj.i)(sessionId, { sessionFile }, {
      sessionsDir,
      agentId
    }));
  } else if (sessionFile) if (agentId) {
    if (sessionFileState !== "stale") pushCandidate(() => (0, _pathsBg3PO6Gj.i)(sessionId, { sessionFile }, { agentId }));
  } else {
    const trimmed = sessionFile.trim();
    if (trimmed) candidates.push(_nodePath.default.resolve(trimmed));
  }
  if (agentId) {
    pushCandidate(() => (0, _pathsBg3PO6Gj.o)(sessionId, agentId));
    if (sessionFile && sessionFileState === "stale") pushCandidate(() => (0, _pathsBg3PO6Gj.i)(sessionId, { sessionFile }, { agentId }));
  }
  const home = (0, _homeDirBOPFpGo.o)(process.env, _nodeOs.default.homedir);
  const legacyDir = _nodePath.default.join(home, ".openclaw", "sessions");
  pushCandidate(() => (0, _pathsBg3PO6Gj.s)(sessionId, legacyDir));
  return Array.from(new Set(candidates));
}
function archiveFileOnDisk(filePath, reason) {
  const archived = `${filePath}.${reason}.${(0, _artifactsBZhcmsUl.t)()}`;
  _nodeFs.default.renameSync(filePath, archived);
  (0, _transcriptEventsClYG_P1o.t)({ sessionFile: archived });
  return archived;
}
function archiveSessionTranscripts(opts) {
  return archiveSessionTranscriptsDetailed(opts).map((entry) => entry.archivedPath);
}
function archiveSessionTranscriptsDetailed(opts) {
  const archived = [];
  const storeDir = opts.restrictToStoreDir && opts.storePath ? canonicalizePathForComparison(_nodePath.default.dirname(opts.storePath)) : null;
  for (const candidate of resolveSessionTranscriptCandidates(opts.sessionId, opts.storePath, opts.sessionFile, opts.agentId)) {
    const candidatePath = canonicalizePathForComparison(candidate);
    if (storeDir) {
      const relative = _nodePath.default.relative(storeDir, candidatePath);
      if (!relative || relative.startsWith("..") || _nodePath.default.isAbsolute(relative)) continue;
    }
    if (!_nodeFs.default.existsSync(candidatePath)) continue;
    try {
      archived.push({
        sourcePath: candidatePath,
        archivedPath: archiveFileOnDisk(candidatePath, opts.reason)
      });
    } catch (err) {
      opts.onArchiveError?.(err, candidatePath);
    }
  }
  return archived;
}
function resolveStableSessionEndTranscript(params) {
  const archivedTranscripts = params.archivedTranscripts ?? [];
  if (archivedTranscripts.length > 0) {
    const preferredPath = params.sessionFile?.trim() ? canonicalizePathForComparison(params.sessionFile) : void 0;
    const archivedPath = (preferredPath == null ? void 0 : archivedTranscripts.find((entry) => canonicalizePathForComparison(entry.sourcePath) === preferredPath))?.archivedPath ?? archivedTranscripts[0]?.archivedPath;
    if (archivedPath) return {
      sessionFile: archivedPath,
      transcriptArchived: true
    };
  }
  for (const candidate of resolveSessionTranscriptCandidates(params.sessionId, params.storePath, params.sessionFile, params.agentId)) {
    const candidatePath = canonicalizePathForComparison(candidate);
    if (_nodeFs.default.existsSync(candidatePath)) return {
      sessionFile: candidatePath,
      transcriptArchived: false
    };
  }
  return {};
}
async function cleanupArchivedSessionTranscripts(opts) {
  if (!Number.isFinite(opts.olderThanMs) || opts.olderThanMs < 0) return {
    removed: 0,
    scanned: 0
  };
  const now = opts.nowMs ?? Date.now();
  const reason = opts.reason ?? "deleted";
  const directories = Array.from(new Set(opts.directories.map((dir) => _nodePath.default.resolve(dir))));
  let removed = 0;
  let scanned = 0;
  for (const dir of directories) {
    const entries = await _nodeFs.default.promises.readdir(dir).catch(() => []);
    for (const entry of entries) {
      const timestamp = (0, _artifactsBZhcmsUl.u)(entry, reason);
      if (timestamp == null) continue;
      scanned += 1;
      if (now - timestamp <= opts.olderThanMs) continue;
      const fullPath = _nodePath.default.join(dir, entry);
      if (!(await _nodeFs.default.promises.stat(fullPath).catch(() => null))?.isFile()) continue;
      await _nodeFs.default.promises.rm(fullPath).catch(() => void 0);
      removed += 1;
    }
  }
  return {
    removed,
    scanned
  };
}
//#endregion /* v9-1a3291c5cfb3a867 */
