"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.generateImages = generateImages;require("./providers/images/register-builtins.js");
var _imagesApiRegistry = require("./images-api-registry.js");
function resolveImagesApiProvider(api) {
  const provider = (0, _imagesApiRegistry.getImagesApiProvider)(api);
  if (!provider) {
    throw new Error(`No API provider registered for api: ${api}`);
  }
  return provider;
}
async function generateImages(model, context, options) {
  const provider = resolveImagesApiProvider(model.api);
  return provider.generateImages(model, context, options);
} /* v9-5fbf2aa08970f14b */
