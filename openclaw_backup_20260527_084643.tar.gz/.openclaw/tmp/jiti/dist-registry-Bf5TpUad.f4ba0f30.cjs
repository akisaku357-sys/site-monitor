"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.a = normalizeChannelId;exports.i = listChannelPlugins;exports.n = getLoadedChannelPlugin;exports.r = getLoadedChannelPluginOrigin;exports.t = getChannelPlugin;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _registryCtWyD2pE = require("./registry-CtWyD2pE.js");
var _bundled0oTAwz0N = require("./bundled-0oTAwz0N.js");
var _registryLoadedBERpJc = require("./registry-loaded-BE-rpJc1.js");
//#region src/channels/plugins/registry.ts
function listChannelPlugins() {
  return (0, _registryLoadedBERpJc.r)();
}
function getLoadedChannelPlugin(id) {
  const resolvedId = (0, _stringCoerceDyL154ka.c)(id) ?? "";
  if (!resolvedId) return;
  return (0, _registryLoadedBERpJc.t)(resolvedId);
}
function getLoadedChannelPluginOrigin(id) {
  const resolvedId = (0, _stringCoerceDyL154ka.c)(id) ?? "";
  if (!resolvedId) return;
  return (0, _stringCoerceDyL154ka.c)((0, _registryLoadedBERpJc.n)(resolvedId)?.origin) ?? void 0;
}
function getChannelPlugin(id) {
  const resolvedId = (0, _stringCoerceDyL154ka.c)(id) ?? "";
  if (!resolvedId) return;
  return getLoadedChannelPlugin(resolvedId) ?? (0, _bundled0oTAwz0N.r)(resolvedId);
}
function normalizeChannelId(raw) {
  return (0, _registryCtWyD2pE.a)(raw);
}
//#endregion /* v9-268e1a1e9822126c */
