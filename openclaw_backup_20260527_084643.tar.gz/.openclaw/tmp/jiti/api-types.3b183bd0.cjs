"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.UploadMediaType = exports.TypingStatus = exports.MessageType = exports.MessageState = exports.MessageItemType = void 0; /**
 * Weixin protocol types (mirrors proto: GetUpdatesReq/Resp, WeixinMessage, SendMessageReq).
 * API uses JSON over HTTP; bytes fields are base64 strings in JSON.
 */
/** proto: UploadMediaType */
const UploadMediaType = exports.UploadMediaType = {
  IMAGE: 1,
  VIDEO: 2,
  FILE: 3,
  VOICE: 4
};
const MessageType = exports.MessageType = {
  NONE: 0,
  USER: 1,
  BOT: 2
};
const MessageItemType = exports.MessageItemType = {
  NONE: 0,
  TEXT: 1,
  IMAGE: 2,
  VOICE: 3,
  FILE: 4,
  VIDEO: 5
};
const MessageState = exports.MessageState = {
  NEW: 0,
  GENERATING: 1,
  FINISH: 2
};
/** Typing status: 1 = typing (default), 2 = cancel typing. */
const TypingStatus = exports.TypingStatus = {
  TYPING: 1,
  CANCEL: 2
}; /* v9-c4a144d225b281b2 */
