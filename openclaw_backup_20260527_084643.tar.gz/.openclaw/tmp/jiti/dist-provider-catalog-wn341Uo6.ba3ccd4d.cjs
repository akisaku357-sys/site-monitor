"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = buildDoubaoProvider;exports.t = buildDoubaoCodingProvider;var _providerCatalogSharedBLp5nwNN = require("./provider-catalog-shared-BLp5nwNN.js");
var _openclawPluginC5D28Bj = require("./openclaw.plugin-C5D28Bj3.js");
//#region extensions/volcengine/provider-catalog.ts
function buildDoubaoProvider() {
  return (0, _providerCatalogSharedBLp5nwNN.n)({
    providerId: "volcengine",
    catalog: _openclawPluginC5D28Bj.t.providers.volcengine
  });
}
function buildDoubaoCodingProvider() {
  return (0, _providerCatalogSharedBLp5nwNN.n)({
    providerId: "volcengine-plan",
    catalog: _openclawPluginC5D28Bj.t.providers["volcengine-plan"]
  });
}
//#endregion /* v9-b61e461688f71341 */
