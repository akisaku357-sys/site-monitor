"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.yuanbaoSetupWizard = void 0;var _setup = require("openclaw/plugin-sdk/setup");
var _accounts = require("./accounts.js");
const CHANNEL = "yuanbao";
/**
 * Declarative setup wizard for the Yuanbao channel.
 *
 * Guides users through configuring appKey and appSecret (Gateway credentials)
 * during `openclaw setup` / onboard flows.
 */
const yuanbaoSetupWizard = exports.yuanbaoSetupWizard = {
  channel: CHANNEL,
  status: (0, _setup.createStandardChannelSetupStatus)({
    channelLabel: "YuanBao Bot",
    configuredLabel: "configured",
    unconfiguredLabel: "needs AppID + AppSecret",
    configuredHint: "configured",
    unconfiguredHint: "needs credentials",
    configuredScore: 2,
    unconfiguredScore: 0,
    includeStatusLine: true,
    resolveConfigured: ({ cfg }) => {
      const account = (0, _accounts.resolveYuanbaoAccount)({ cfg });
      return account.configured;
    },
    resolveExtraStatusLines: async ({ cfg, configured }) => {
      if (!configured)
      return [];
      const account = (0, _accounts.resolveYuanbaoAccount)({ cfg });
      return [`  AppID: ${account.appKey ?? "?"}`];
    }
  }),
  introNote: {
    title: "YuanBao Bot credentials",
    lines: [
    "You'll need values from YuanBao APP:",
    "",
    "• AppID & AppSecret → Create a robot from your YuanBao APP to obtain."],

    shouldShow: async ({ cfg }) => {
      const account = (0, _accounts.resolveYuanbaoAccount)({ cfg });
      return !account.configured;
    }
  },
  credentials: [
  {
    inputKey: "token",
    providerHint: "YuanBao APP",
    credentialLabel: "AppID",
    helpTitle: "YuanBao AppID",
    helpLines: [
    "The AppID is obtained from your YuanBao robot application settings.",
    "It is used together with App Secret for WebSocket ticket-signing authentication."],

    envPrompt: "Use YUANBAO_APP_KEY from environment?",
    keepPrompt: "AppID already configured. Keep it?",
    inputPrompt: "Enter AppID (from bot application settings)",
    preferredEnvVar: "YUANBAO_APP_KEY",
    inspect: ({ cfg }) => {
      const yuanbaoCfg = cfg.channels?.yuanbao;
      const currentValue = yuanbaoCfg?.appKey?.trim() || undefined;
      const envValue = process.env.YUANBAO_APP_KEY?.trim() || undefined;
      return {
        accountConfigured: Boolean(currentValue),
        hasConfiguredValue: Boolean(currentValue),
        resolvedValue: currentValue,
        envValue
      };
    },
    applySet: ({ cfg, value }) => (0, _setup.patchTopLevelChannelConfigSection)({
      cfg,
      channel: CHANNEL,
      patch: { appKey: value }
    })
  },
  {
    inputKey: "privateKey",
    providerHint: "YuanBao APP",
    credentialLabel: "App Secret",
    helpTitle: "YuanBao App Secret",
    helpLines: [
    "The App Secret is obtained from your YuanBao robot application settings.",
    "It is used together with App Key for WebSocket ticket-signing authentication."],

    envPrompt: "Use YUANBAO_APP_SECRET from environment?",
    keepPrompt: "App Secret already configured. Keep it?",
    inputPrompt: "Enter App Secret (from bot application settings)",
    preferredEnvVar: "YUANBAO_APP_SECRET",
    inspect: ({ cfg }) => {
      const yuanbaoCfg = cfg.channels?.yuanbao;
      const currentValue = yuanbaoCfg?.appSecret?.trim() || undefined;
      const envValue = process.env.YUANBAO_APP_SECRET?.trim() || undefined;
      return {
        accountConfigured: Boolean(currentValue),
        hasConfiguredValue: Boolean(currentValue),
        resolvedValue: currentValue,
        envValue
      };
    },
    applySet: ({ cfg, value }) => (0, _setup.patchTopLevelChannelConfigSection)({
      cfg,
      channel: CHANNEL,
      patch: { appSecret: value }
    })
  }],

  textInputs: [
  {
    inputKey: "name",
    message: "Bot display name (optional, press Enter to skip)",
    required: false,
    currentValue: ({ cfg }) => {
      const yuanbaoCfg = cfg.channels?.yuanbao;
      return yuanbaoCfg?.name?.trim() || undefined;
    },
    applySet: ({ cfg, value }) => (0, _setup.patchTopLevelChannelConfigSection)({
      cfg,
      channel: CHANNEL,
      patch: { name: value }
    })
  }],

  finalize: ({ cfg }) => {
    // Ensure the channel is enabled after wizard completes
    const next = (0, _setup.setSetupChannelEnabled)(cfg, CHANNEL, true);
    return { cfg: next };
  },
  completionNote: {
    title: "YuanBao Bot setup complete",
    lines: [
    "Your YuanBao Bot credentials have been saved.",
    "Run `openclaw start` to connect your bot."]

  },
  disable: (cfg) => (0, _setup.setSetupChannelEnabled)(cfg, CHANNEL, false)
}; /* v9-0d5dc5e28d73ca23 */
