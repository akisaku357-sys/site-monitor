"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = resolveSandboxRuntimeStatus;exports.t = formatSandboxToolPolicyBlockedMessage;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _commandFormatBPjMauol = require("./command-format-BPjMauol.js");
var _agentScopeCtLXGcWm = require("./agent-scope-CtLXGcWm.js");
var _mainSessionD3q_5w0B = require("./main-session-D3q_5w0B.js");
var _toolPolicyBY51AUO = require("./tool-policy-BY51AUO-.js");
var _configCcQ2HijN = require("./config-CcQ2HijN.js");
//#region src/agents/sandbox/runtime-status.ts
function shouldSandboxSession(cfg, sessionKey, mainSessionKey) {
  if (cfg.mode === "off") return false;
  if (cfg.mode === "all") return true;
  return sessionKey.trim() !== mainSessionKey.trim();
}
function resolveMainSessionKeyForSandbox(params) {
  if (params.cfg?.session?.scope === "global") return "global";
  return (0, _mainSessionD3q_5w0B.n)({
    cfg: params.cfg,
    agentId: params.agentId
  });
}
function resolveComparableSessionKeyForSandbox(params) {
  return (0, _mainSessionD3q_5w0B.t)({
    cfg: params.cfg,
    agentId: params.agentId,
    sessionKey: params.sessionKey
  });
}
function resolveSandboxRuntimeStatus(params) {
  const sessionKey = params.sessionKey?.trim() ?? "";
  const agentId = (0, _agentScopeCtLXGcWm._)({
    sessionKey,
    config: params.cfg
  });
  const cfg = params.cfg;
  const sandboxCfg = (0, _configCcQ2HijN.i)(cfg, agentId);
  const mainSessionKey = resolveMainSessionKeyForSandbox({
    cfg,
    agentId
  });
  const sandboxed = sessionKey ? shouldSandboxSession(sandboxCfg, resolveComparableSessionKeyForSandbox({
    cfg,
    agentId,
    sessionKey
  }), mainSessionKey) : false;
  return {
    agentId,
    sessionKey,
    mainSessionKey,
    mode: sandboxCfg.mode,
    sandboxed,
    toolPolicy: (0, _toolPolicyBY51AUO.r)(cfg, agentId)
  };
}
function sanitizeForSingleLineDisplay(value) {
  return Array.from(value, (char) => {
    if (char === "\n") return "\\n";
    if (char === "\r") return "\\r";
    if (char === "	") return "\\t";
    const codePoint = char.codePointAt(0) ?? 0;
    if (codePoint < 32 || codePoint === 127) return `\\x${codePoint.toString(16).padStart(2, "0")}`;
    return char;
  }).join("");
}
function hasUnsafeControlChars(value) {
  return Array.from(value).some((char) => {
    const codePoint = char.codePointAt(0) ?? 0;
    return codePoint < 32 || codePoint === 127;
  });
}
function redactSessionKey(value) {
  const trimmed = value.trim();
  if (!trimmed) return "(unknown)";
  if (trimmed.length <= 12) return "(redacted)";
  return `${sanitizeForSingleLineDisplay(trimmed.slice(0, 6))}…${sanitizeForSingleLineDisplay(trimmed.slice(-6))}`;
}
function shellEscapeSingleArg(value) {
  return `'${value.replaceAll("'", `'\\''`)}'`;
}
function formatSandboxToolPolicyBlockedMessage(params) {
  const tool = (0, _stringCoerceDyL154ka.s)(params.toolName);
  if (!tool) return;
  const runtime = resolveSandboxRuntimeStatus({
    cfg: params.cfg,
    sessionKey: params.sessionKey
  });
  if (!runtime.sandboxed) return;
  const { blockedByDeny, blockedByAllow } = (0, _toolPolicyBY51AUO.t)(tool, runtime.toolPolicy);
  if (!blockedByDeny && !blockedByAllow) return;
  const reasons = [];
  const fixes = [];
  if (blockedByDeny) {
    reasons.push("deny list");
    fixes.push(`Remove "${tool}" from ${runtime.toolPolicy.sources.deny.key}.`);
  }
  if (blockedByAllow) {
    reasons.push("allow list");
    fixes.push(`Add "${tool}" to ${runtime.toolPolicy.sources.allow.key} (or set it to [] to allow all).`);
  }
  const lines = [];
  lines.push(`Tool "${tool}" blocked by sandbox tool policy (mode=${runtime.mode}).`);
  lines.push(`Session: ${redactSessionKey(runtime.sessionKey)}`);
  lines.push(`Reason: ${reasons.join(" + ")}`);
  lines.push("Fix:");
  lines.push(`- agents.defaults.sandbox.mode=off (disable sandbox)`);
  for (const fix of fixes) lines.push(`- ${fix}`);
  if (runtime.mode === "non-main") lines.push("- Use the agent main session instead of a non-main session.");
  const explainCommand = runtime.sessionKey ? hasUnsafeControlChars(runtime.sessionKey) ? `openclaw sandbox explain --agent ${runtime.agentId}` : `openclaw sandbox explain --session ${shellEscapeSingleArg(runtime.sessionKey)}` : "openclaw sandbox explain";
  lines.push(`- See: ${(0, _commandFormatBPjMauol.t)(explainCommand)}`);
  return lines.join("\n");
}
//#endregion /* v9-6687954ad41306aa */
