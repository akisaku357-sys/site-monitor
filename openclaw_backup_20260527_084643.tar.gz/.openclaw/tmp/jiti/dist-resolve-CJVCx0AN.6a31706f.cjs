"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.a = resolvePrompt;exports.c = normalizeMediaUnderstandingChatType;exports.i = resolveModelEntries;exports.l = resolveMediaUnderstandingScope;exports.n = resolveMaxBytes;exports.o = resolveScopeDecision;exports.r = resolveMaxChars;exports.s = resolveTimeoutMs;exports.t = resolveConcurrency;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _globalsYU5FjfZK = require("./globals-YU5FjfZK.js");
var _chatTypeD_QPUzR = require("./chat-type-D_QPUzR1.js");
var _defaultsConstantsDeIx7Gbv = require("./defaults.constants-DeIx7Gbv.js");
var _entryCapabilitiesDGvNSGdr = require("./entry-capabilities-DGvNSGdr.js");
//#region src/media-understanding/scope.ts
function normalizeDecision(value) {
  const normalized = (0, _stringCoerceDyL154ka.s)(value);
  if (normalized === "allow") return "allow";
  if (normalized === "deny") return "deny";
}
function normalizeMediaUnderstandingChatType(raw) {
  return (0, _chatTypeD_QPUzR.t)(raw ?? void 0);
}
function resolveMediaUnderstandingScope(params) {
  const scope = params.scope;
  if (!scope) return "allow";
  const channel = (0, _stringCoerceDyL154ka.s)(params.channel);
  const chatType = normalizeMediaUnderstandingChatType(params.chatType);
  const sessionKey = (0, _stringCoerceDyL154ka.s)(params.sessionKey) ?? "";
  for (const rule of scope.rules ?? []) {
    if (!rule) continue;
    const action = normalizeDecision(rule.action) ?? "allow";
    const match = rule.match ?? {};
    const matchChannel = (0, _stringCoerceDyL154ka.s)(match.channel);
    const matchChatType = normalizeMediaUnderstandingChatType(match.chatType);
    const matchPrefix = (0, _stringCoerceDyL154ka.s)(match.keyPrefix);
    if (matchChannel && matchChannel !== channel) continue;
    if (matchChatType && matchChatType !== chatType) continue;
    if (matchPrefix && !sessionKey.startsWith(matchPrefix)) continue;
    return action;
  }
  return normalizeDecision(scope.default) ?? "allow";
}
//#endregion
//#region src/media-understanding/resolve.ts
function resolveTimeoutMs(seconds, fallbackSeconds) {
  return Math.max(1e3, Math.floor((typeof seconds === "number" && Number.isFinite(seconds) ? seconds : fallbackSeconds) * 1e3));
}
function resolvePrompt(capability, prompt, maxChars) {
  const base = prompt?.trim() || _defaultsConstantsDeIx7Gbv.o[capability];
  if (!maxChars || capability === "audio") return base;
  return `${base} Respond in at most ${maxChars} characters.`;
}
function resolveMaxChars(params) {
  const { capability, entry, cfg } = params;
  const configured = entry.maxChars ?? params.config?.maxChars ?? cfg.tools?.media?.[capability]?.maxChars;
  if (typeof configured === "number") return configured;
  return _defaultsConstantsDeIx7Gbv.i[capability];
}
function resolveMaxBytes(params) {
  const configured = params.entry.maxBytes ?? params.config?.maxBytes ?? params.cfg.tools?.media?.[params.capability]?.maxBytes;
  if (typeof configured === "number") return configured;
  return _defaultsConstantsDeIx7Gbv.n[params.capability];
}
function resolveScopeDecision(params) {
  return resolveMediaUnderstandingScope({
    scope: params.scope,
    sessionKey: params.ctx.SessionKey,
    channel: params.ctx.Surface ?? params.ctx.Provider,
    chatType: normalizeMediaUnderstandingChatType(params.ctx.ChatType)
  });
}
function resolveModelEntries(params) {
  const { cfg, capability, config } = params;
  const sharedModels = cfg.tools?.media?.models ?? [];
  const entries = [...(config?.models ?? []).map((entry) => ({
    entry,
    source: "capability"
  })), ...sharedModels.map((entry) => ({
    entry,
    source: "shared"
  }))];
  if (entries.length === 0) return [];
  return entries.filter(({ entry, source }) => {
    const caps = (0, _entryCapabilitiesDGvNSGdr.r)({
      entry,
      source,
      providerRegistry: params.providerRegistry
    });
    if (!caps || caps.length === 0) {
      if (source === "shared") {
        if ((0, _globalsYU5FjfZK.a)()) (0, _globalsYU5FjfZK.r)(`Skipping shared media model without capabilities: ${entry.provider ?? entry.command ?? "unknown"}`);
        return false;
      }
      return true;
    }
    return caps.includes(capability);
  }).map(({ entry }) => entry);
}
function resolveConcurrency(cfg) {
  const configured = cfg.tools?.media?.concurrency;
  if (typeof configured === "number" && Number.isFinite(configured) && configured > 0) return Math.floor(configured);
  return 2;
}
//#endregion /* v9-9e7fc4283fe59622 */
