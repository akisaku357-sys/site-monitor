"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.t = exports.n = void 0;var _schemasDel5uzR = require("./schemas-Del5uzR8.js");
//#region src/config/zod-schema.installs.ts
const InstallSourceSchema = (0, _schemasDel5uzR.Xn)([
(0, _schemasDel5uzR.dn)("npm"),
(0, _schemasDel5uzR.dn)("archive"),
(0, _schemasDel5uzR.dn)("path"),
(0, _schemasDel5uzR.dn)("clawhub"),
(0, _schemasDel5uzR.dn)("git")]
);
const PluginInstallSourceSchema = (0, _schemasDel5uzR.Xn)([InstallSourceSchema, (0, _schemasDel5uzR.dn)("marketplace")]);
const InstallRecordShape = exports.t = {
  source: InstallSourceSchema,
  spec: (0, _schemasDel5uzR.Rn)().optional(),
  sourcePath: (0, _schemasDel5uzR.Rn)().optional(),
  installPath: (0, _schemasDel5uzR.Rn)().optional(),
  version: (0, _schemasDel5uzR.Rn)().optional(),
  resolvedName: (0, _schemasDel5uzR.Rn)().optional(),
  resolvedVersion: (0, _schemasDel5uzR.Rn)().optional(),
  resolvedSpec: (0, _schemasDel5uzR.Rn)().optional(),
  integrity: (0, _schemasDel5uzR.Rn)().optional(),
  shasum: (0, _schemasDel5uzR.Rn)().optional(),
  resolvedAt: (0, _schemasDel5uzR.Rn)().optional(),
  installedAt: (0, _schemasDel5uzR.Rn)().optional(),
  clawhubUrl: (0, _schemasDel5uzR.Rn)().optional(),
  clawhubPackage: (0, _schemasDel5uzR.Rn)().optional(),
  clawhubFamily: (0, _schemasDel5uzR.Xn)([(0, _schemasDel5uzR.dn)("code-plugin"), (0, _schemasDel5uzR.dn)("bundle-plugin")]).optional(),
  clawhubChannel: (0, _schemasDel5uzR.Xn)([
  (0, _schemasDel5uzR.dn)("official"),
  (0, _schemasDel5uzR.dn)("community"),
  (0, _schemasDel5uzR.dn)("private")]
  ).optional(),
  artifactKind: (0, _schemasDel5uzR.Xn)([(0, _schemasDel5uzR.dn)("legacy-zip"), (0, _schemasDel5uzR.dn)("npm-pack")]).optional(),
  artifactFormat: (0, _schemasDel5uzR.Xn)([(0, _schemasDel5uzR.dn)("zip"), (0, _schemasDel5uzR.dn)("tgz")]).optional(),
  npmIntegrity: (0, _schemasDel5uzR.Rn)().optional(),
  npmShasum: (0, _schemasDel5uzR.Rn)().optional(),
  npmTarballName: (0, _schemasDel5uzR.Rn)().optional(),
  clawpackSha256: (0, _schemasDel5uzR.Rn)().optional(),
  clawpackSpecVersion: (0, _schemasDel5uzR.wn)().int().nonnegative().optional(),
  clawpackManifestSha256: (0, _schemasDel5uzR.Rn)().optional(),
  clawpackSize: (0, _schemasDel5uzR.wn)().int().nonnegative().optional(),
  gitUrl: (0, _schemasDel5uzR.Rn)().optional(),
  gitRef: (0, _schemasDel5uzR.Rn)().optional(),
  gitCommit: (0, _schemasDel5uzR.Rn)().optional()
};
const PluginInstallRecordShape = exports.n = {
  ...InstallRecordShape,
  source: PluginInstallSourceSchema,
  marketplaceName: (0, _schemasDel5uzR.Rn)().optional(),
  marketplaceSource: (0, _schemasDel5uzR.Rn)().optional(),
  marketplacePlugin: (0, _schemasDel5uzR.Rn)().optional()
};
//#endregion /* v9-d5f520a4e6b9183c */
