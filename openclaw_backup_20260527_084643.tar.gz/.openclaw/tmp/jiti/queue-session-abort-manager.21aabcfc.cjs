"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.SessionAbortManager = void 0;





var _logger = require("../../logger.js"); /**
 * Session-level AbortController manager.
 *
 * Maintains one AbortController per sessionKey.
 * Call rotate() to abort the old inference and create a new controller.
 */const log = (0, _logger.createLog)("session-abort");class SessionAbortManager {/** sessionKey → currently active AbortController */controllers = new Map(); /**
   * Rotate the AbortController for a session:
   * 1. Abort the old controller (terminate in-progress inference)
   * 2. Create a new controller and return its signal
   */
  rotate(sessionKey) {
    const existing = this.controllers.get(sessionKey);
    if (existing) {
      log.info(`[${sessionKey}] aborting previous inference`);
      existing.abort();
    }
    const controller = new AbortController();
    this.controllers.set(sessionKey, controller);
    return controller.signal;
  }
  /**
   * Clean up controller after task completion (prevent memory leaks).
   * Only deletes if the stored controller still matches, to avoid
   * accidentally removing a newer controller created by a subsequent rotate().
   */
  cleanup(sessionKey, signal) {
    const current = this.controllers.get(sessionKey);
    if (current && current.signal === signal) {
      this.controllers.delete(sessionKey);
    }
  }
  /** Number of currently active sessions (for debugging/monitoring) */
  get activeCount() {
    return this.controllers.size;
  }
}exports.SessionAbortManager = SessionAbortManager; /* v9-6850fa49015baad5 */
