"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.a = buildSessionStartHookPayload;exports.i = buildSessionEndHookPayload;exports.n = listActiveSessionsForShutdown;exports.r = noteActiveSessionForShutdown;exports.t = forgetActiveSessionForShutdown;var _agentScopeCtLXGcWm = require("./agent-scope-CtLXGcWm.js");
//#region src/auto-reply/reply/session-hooks.ts
function buildSessionHookContext(params) {
  return {
    sessionId: params.sessionId,
    sessionKey: params.sessionKey,
    agentId: (0, _agentScopeCtLXGcWm._)({
      sessionKey: params.sessionKey,
      config: params.cfg
    })
  };
}
function buildSessionStartHookPayload(params) {
  return {
    event: {
      sessionId: params.sessionId,
      sessionKey: params.sessionKey,
      resumedFrom: params.resumedFrom
    },
    context: buildSessionHookContext({
      sessionId: params.sessionId,
      sessionKey: params.sessionKey,
      cfg: params.cfg
    })
  };
}
function buildSessionEndHookPayload(params) {
  return {
    event: {
      sessionId: params.sessionId,
      sessionKey: params.sessionKey,
      messageCount: params.messageCount ?? 0,
      durationMs: params.durationMs,
      reason: params.reason,
      sessionFile: params.sessionFile,
      transcriptArchived: params.transcriptArchived,
      nextSessionId: params.nextSessionId,
      nextSessionKey: params.nextSessionKey
    },
    context: buildSessionHookContext({
      sessionId: params.sessionId,
      sessionKey: params.sessionKey,
      cfg: params.cfg
    })
  };
}
//#endregion
//#region src/gateway/active-sessions-shutdown-tracker.ts
const trackedSessions = /* @__PURE__ */new Map();
function noteActiveSessionForShutdown(entry) {
  if (!entry.sessionId) return;
  trackedSessions.set(entry.sessionId, entry);
}
function forgetActiveSessionForShutdown(sessionId) {
  if (!sessionId) return;
  trackedSessions.delete(sessionId);
}
function listActiveSessionsForShutdown() {
  return Array.from(trackedSessions.values());
}
//#endregion /* v9-32cb31c125ea336d */
