"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.t = resolveChannelModelOverride;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _sessionKeyUtilsCe_xWkNq = require("./session-key-utils-Ce_xWkNq.js");
var _messageChannelCYCKkVrh = require("./message-channel-CYCKkVrh.js");
var _registryBf5TpUad = require("./registry-Bf5TpUad.js");
var _sessionConversationXHNnUnBT = require("./session-conversation-XHNnUnBT.js");
var _chatTypeD_QPUzR = require("./chat-type-D_QPUzR1.js");
var _channelConfigBI04LRnO = require("./channel-config-BI04LRnO.js");
//#region src/channels/model-overrides.ts
function resolveProviderEntry(modelByChannel, channel) {
  const normalized = (0, _messageChannelCYCKkVrh.u)(channel) ?? (0, _stringCoerceDyL154ka.s)(channel) ?? "";
  return modelByChannel?.[normalized] ?? modelByChannel?.[Object.keys(modelByChannel ?? {}).find((key) => {
    return ((0, _messageChannelCYCKkVrh.u)(key) ?? (0, _stringCoerceDyL154ka.s)(key) ?? "") === normalized;
  }) ?? ""];
}
function buildChannelCandidates(params) {
  const normalizedChannel = (0, _messageChannelCYCKkVrh.u)(params.channel ?? "") ?? (0, _stringCoerceDyL154ka.s)(params.channel);
  const groupId = (0, _stringCoerceDyL154ka.c)(params.groupId);
  const rawParentConversation = (0, _sessionKeyUtilsCe_xWkNq.l)(params.parentSessionKey);
  const parentOverrideFallbacks = (normalizedChannel ? (0, _registryBf5TpUad.t)(normalizedChannel) : void 0)?.conversationBindings?.buildModelOverrideParentCandidates?.({ parentConversationId: rawParentConversation?.rawId }) ?? [];
  const sessionConversation = (0, _sessionConversationXHNnUnBT.n)(params.parentSessionKey, { bundledFallback: parentOverrideFallbacks.length === 0 });
  const groupConversationKind = (0, _chatTypeD_QPUzR.t)(params.groupChatType ?? void 0) === "channel" ? "channel" : sessionConversation?.kind === "channel" ? "channel" : "group";
  const groupConversation = (0, _sessionConversationXHNnUnBT.t)({
    channel: normalizedChannel ?? "",
    kind: groupConversationKind,
    rawId: groupId ?? ""
  });
  const groupChannel = (0, _stringCoerceDyL154ka.c)(params.groupChannel);
  const groupSubject = (0, _stringCoerceDyL154ka.c)(params.groupSubject);
  const channelBare = groupChannel ? groupChannel.replace(/^#/, "") : void 0;
  const subjectBare = groupSubject ? groupSubject.replace(/^#/, "") : void 0;
  const channelSlug = channelBare ? (0, _channelConfigBI04LRnO.r)(channelBare) : void 0;
  const subjectSlug = subjectBare ? (0, _channelConfigBI04LRnO.r)(subjectBare) : void 0;
  return {
    keys: (0, _channelConfigBI04LRnO.n)(groupId, sessionConversation?.rawId, ...(groupConversation?.parentConversationCandidates ?? []), ...(sessionConversation?.parentConversationCandidates ?? []), ...parentOverrideFallbacks),
    parentKeys: (0, _channelConfigBI04LRnO.n)(groupChannel, channelBare, channelSlug, groupSubject, subjectBare, subjectSlug)
  };
}
function buildGenericParentOverrideCandidates(sessionKey) {
  const raw = (0, _sessionKeyUtilsCe_xWkNq.l)(sessionKey);
  if (!raw) return [];
  const { baseSessionKey, threadId } = (0, _sessionKeyUtilsCe_xWkNq.u)(raw.rawId);
  return (0, _channelConfigBI04LRnO.n)(threadId ? baseSessionKey : raw.rawId);
}
function resolveDirectChannelModelMatch(params) {
  const directKeys = (0, _channelConfigBI04LRnO.n)(params.groupId, ...buildGenericParentOverrideCandidates(params.parentSessionKey));
  if (directKeys.length === 0) return null;
  const match = (0, _channelConfigBI04LRnO.a)({
    entries: params.providerEntries,
    keys: directKeys,
    parentKeys: [],
    wildcardKey: "*",
    normalizeKey: (value) => (0, _stringCoerceDyL154ka.s)(value) ?? ""
  });
  const raw = match.entry ?? match.wildcardEntry;
  if (typeof raw !== "string") return null;
  const model = (0, _stringCoerceDyL154ka.c)(raw);
  if (!model) return null;
  return {
    model,
    matchKey: match.matchKey,
    matchSource: match.matchSource
  };
}
function resolveChannelModelOverride(params) {
  const channel = (0, _stringCoerceDyL154ka.c)(params.channel);
  if (!channel) return null;
  const modelByChannel = params.cfg.channels?.modelByChannel;
  if (!modelByChannel) return null;
  const providerEntries = resolveProviderEntry(modelByChannel, channel);
  if (!providerEntries) return null;
  const directMatch = resolveDirectChannelModelMatch({
    channel,
    providerEntries,
    groupId: params.groupId,
    parentSessionKey: params.parentSessionKey
  });
  if (directMatch) return {
    channel: (0, _messageChannelCYCKkVrh.u)(channel) ?? (0, _stringCoerceDyL154ka.s)(channel) ?? "",
    model: directMatch.model,
    matchKey: directMatch.matchKey,
    matchSource: directMatch.matchSource
  };
  const { keys, parentKeys } = buildChannelCandidates(params);
  if (keys.length === 0 && parentKeys.length === 0) {
    const wildcardModel = (0, _stringCoerceDyL154ka.c)(providerEntries["*"]);
    if (wildcardModel) return {
      channel: (0, _messageChannelCYCKkVrh.u)(channel) ?? (0, _stringCoerceDyL154ka.s)(channel) ?? "",
      model: wildcardModel,
      matchKey: "*",
      matchSource: "wildcard"
    };
    return null;
  }
  const match = (0, _channelConfigBI04LRnO.a)({
    entries: providerEntries,
    keys,
    parentKeys,
    wildcardKey: "*",
    normalizeKey: (value) => (0, _stringCoerceDyL154ka.s)(value) ?? ""
  });
  const raw = match.entry ?? match.wildcardEntry;
  if (typeof raw !== "string") return null;
  const model = (0, _stringCoerceDyL154ka.c)(raw);
  if (!model) return null;
  return {
    channel: (0, _messageChannelCYCKkVrh.u)(channel) ?? (0, _stringCoerceDyL154ka.s)(channel) ?? "",
    model,
    matchKey: match.matchKey,
    matchSource: match.matchSource
  };
}
//#endregion /* v9-fd6fe237284e7657 */
