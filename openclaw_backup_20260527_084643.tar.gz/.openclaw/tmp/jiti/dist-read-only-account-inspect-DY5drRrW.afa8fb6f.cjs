"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.t = inspectReadOnlyChannelAccount;var _bundled0oTAwz0N = require("./bundled-0oTAwz0N.js");
var _registryBf5TpUad = require("./registry-Bf5TpUad.js");
//#region src/channels/read-only-account-inspect.ts
async function inspectReadOnlyChannelAccount(params) {
  const inspectAccount = (0, _registryBf5TpUad.n)(params.channelId)?.config.inspectAccount ?? (0, _bundled0oTAwz0N.n)(params.channelId);
  if (!inspectAccount) return null;
  return await Promise.resolve(inspectAccount(params.cfg, params.accountId));
}
//#endregion /* v9-0877e1ba6c92b4ef */
