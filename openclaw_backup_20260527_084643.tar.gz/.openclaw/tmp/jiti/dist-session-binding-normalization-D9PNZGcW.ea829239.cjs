"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.i = normalizeConversationText;exports.n = normalizeConversationRef;exports.r = normalizeConversationTargetRef;exports.t = buildChannelAccountKey;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _accountIdB32JINN = require("./account-id-B32J-iNN.js");
//#region src/acp/conversation-id.ts
function normalizeConversationText(value) {
  if (typeof value === "string") return value.trim();
  if (typeof value === "number" || typeof value === "bigint" || typeof value === "boolean") return `${value}`.trim();
  return "";
}
//#endregion
//#region src/infra/outbound/session-binding-normalization.ts
function normalizeConversationTargetRef(ref) {
  const conversationId = (0, _stringCoerceDyL154ka.c)(ref.conversationId) ?? "";
  const parentConversationId = (0, _stringCoerceDyL154ka.c)(ref.parentConversationId);
  const { parentConversationId: _ignoredParentConversationId, ...rest } = ref;
  return {
    ...rest,
    conversationId,
    ...(parentConversationId && parentConversationId !== conversationId ? { parentConversationId } : {})
  };
}
function normalizeConversationRef(ref) {
  return {
    ...normalizeConversationTargetRef(ref),
    channel: (0, _stringCoerceDyL154ka.a)(ref.channel),
    accountId: (0, _accountIdB32JINN.n)(ref.accountId)
  };
}
function buildChannelAccountKey(params) {
  return `${(0, _stringCoerceDyL154ka.a)(params.channel)}:${(0, _accountIdB32JINN.n)(params.accountId)}`;
}
//#endregion /* v9-5487a2ab282bba6f */
