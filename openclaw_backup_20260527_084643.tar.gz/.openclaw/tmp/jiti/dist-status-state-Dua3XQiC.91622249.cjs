"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.t = formatChannelStatusState; //#region src/channels/plugins/status-state.ts
function formatChannelStatusState(statusState) {
  switch (statusState) {
    case "linked":return "linked";
    case "not-linked":return "not linked";
    case "unstable":return "auth stabilizing";
    default:return statusState;
  }
}
//#endregion /* v9-ecd9bac735b6797b */
