"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.a = sortSubagentRuns;exports.i = resolveSubagentTargetFromRuns;exports.n = formatRunStatus;exports.r = resolveSubagentLabel;exports.t = formatRunLabel;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _utilsSBTEdeml = require("./utils-sBTEdeml.js");
var _taskStatusBvwcU8qI = require("./task-status-BvwcU8qI.js");
//#region src/auto-reply/reply/subagents-utils.ts
function resolveSubagentLabel(entry, fallback = "subagent") {
  return (0, _stringCoerceDyL154ka.c)(entry.label) || (0, _stringCoerceDyL154ka.c)(entry.task) || fallback;
}
function formatRunLabel(entry, options) {
  const raw = (0, _taskStatusBvwcU8qI.a)(resolveSubagentLabel(entry)) || "subagent";
  const maxLength = options?.maxLength ?? 72;
  if (!Number.isFinite(maxLength) || maxLength <= 0) return raw;
  return raw.length > maxLength ? `${(0, _utilsSBTEdeml.y)(raw, maxLength).trimEnd()}…` : raw;
}
function formatRunStatus(entry) {
  if (!entry.endedAt) return "running";
  const status = entry.outcome?.status ?? "done";
  return status === "ok" ? "done" : status;
}
function sortSubagentRuns(runs) {
  return [...runs].toSorted((a, b) => {
    const aTime = a.startedAt ?? a.createdAt ?? 0;
    return (b.startedAt ?? b.createdAt ?? 0) - aTime;
  });
}
function resolveSubagentTargetFromRuns(params) {
  const trimmed = (0, _stringCoerceDyL154ka.c)(params.token);
  if (!trimmed) return { error: params.errors.missingTarget };
  const sorted = sortSubagentRuns(params.runs);
  const deduped = [];
  const seenChildSessionKeys = /* @__PURE__ */new Set();
  for (const entry of sorted) {
    if (seenChildSessionKeys.has(entry.childSessionKey)) continue;
    seenChildSessionKeys.add(entry.childSessionKey);
    deduped.push(entry);
  }
  if (trimmed === "last") return { entry: deduped[0] };
  const isActive = params.isActive ?? ((entry) => !entry.endedAt);
  const recentCutoff = Date.now() - params.recentWindowMinutes * 6e4;
  const numericOrder = [...deduped.filter((entry) => isActive(entry)), ...deduped.filter((entry) => !isActive(entry) && !!entry.endedAt && (entry.endedAt ?? 0) >= recentCutoff)];
  if (/^\d+$/.test(trimmed)) {
    const idx = Number.parseInt(trimmed, 10);
    if (!Number.isFinite(idx) || idx <= 0 || idx > numericOrder.length) return { error: params.errors.invalidIndex(trimmed) };
    return { entry: numericOrder[idx - 1] };
  }
  if (trimmed.includes(":")) {
    const bySessionKey = deduped.find((entry) => entry.childSessionKey === trimmed);
    return bySessionKey ? { entry: bySessionKey } : { error: params.errors.unknownSession(trimmed) };
  }
  const lowered = (0, _stringCoerceDyL154ka.a)(trimmed);
  const aliases = params.aliases ?? (() => []);
  const byExactAlias = numericOrder.filter((entry) => aliases(entry).some((alias) => (0, _stringCoerceDyL154ka.a)(alias) === lowered));
  if (byExactAlias.length === 1) return { entry: byExactAlias[0] };
  if (byExactAlias.length > 1) return { error: params.errors.ambiguousLabel(trimmed) };
  const byExactLabel = deduped.filter((entry) => (0, _stringCoerceDyL154ka.a)(params.label(entry)) === lowered);
  if (byExactLabel.length === 1) return { entry: byExactLabel[0] };
  if (byExactLabel.length > 1) return { error: params.errors.ambiguousLabel(trimmed) };
  const byAliasPrefix = numericOrder.filter((entry) => aliases(entry).some((alias) => (0, _stringCoerceDyL154ka.a)(alias).startsWith(lowered)));
  if (byAliasPrefix.length === 1) return { entry: byAliasPrefix[0] };
  if (byAliasPrefix.length > 1) return { error: params.errors.ambiguousLabelPrefix(trimmed) };
  const byLabelPrefix = deduped.filter((entry) => (0, _stringCoerceDyL154ka.a)(params.label(entry)).startsWith(lowered));
  if (byLabelPrefix.length === 1) return { entry: byLabelPrefix[0] };
  if (byLabelPrefix.length > 1) return { error: params.errors.ambiguousLabelPrefix(trimmed) };
  const byRunIdPrefix = deduped.filter((entry) => entry.runId.startsWith(trimmed));
  if (byRunIdPrefix.length === 1) return { entry: byRunIdPrefix[0] };
  if (byRunIdPrefix.length > 1) return { error: params.errors.ambiguousRunIdPrefix(trimmed) };
  return { error: params.errors.unknownTarget(trimmed) };
}
//#endregion /* v9-82efe683f73201ed */
