"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.WeixinConfigSchema = void 0;var _zod = require("zod");
var _accounts = require("../auth/accounts.js");
// ---------------------------------------------------------------------------
// Zod config schema
// ---------------------------------------------------------------------------
const weixinAccountSchema = _zod.z.object({
  name: _zod.z.string().optional(),
  enabled: _zod.z.boolean().optional(),
  baseUrl: _zod.z.string().default(_accounts.DEFAULT_BASE_URL),
  cdnBaseUrl: _zod.z.string().default(_accounts.CDN_BASE_URL),
  routeTag: _zod.z.number().optional()
});
/** Top-level weixin config schema (token is stored in credentials file, not config). */
const WeixinConfigSchema = exports.WeixinConfigSchema = weixinAccountSchema.extend({
  accounts: _zod.z.record(_zod.z.string(), weixinAccountSchema).optional(),
  /** ISO 8601; bumped on each successful login to refresh gateway config from disk. */
  channelConfigUpdatedAt: _zod.z.string().optional()
}); /* v9-453db6732dc47947 */
