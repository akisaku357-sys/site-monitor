"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.t = resolveSenderToolPolicy;require("./agent-scope-CtLXGcWm.js");
var _agentScopeConfigCMp71_ = require("./agent-scope-config-CMp71_27.js");
var _groupPolicySKF5rlUN = require("./group-policy-sKF5rlUN.js");
var _sandboxToolPolicyA1J2EpRM = require("./sandbox-tool-policy-A1J2EpRM.js");
//#region src/agents/sender-tool-policy.ts
function resolveSenderToolPolicy(params) {
  const cfg = params.config;
  if (!cfg) return;
  const sender = {
    messageProvider: params.messageProvider,
    senderId: params.senderId,
    senderName: params.senderName,
    senderUsername: params.senderUsername,
    senderE164: params.senderE164
  };
  const agentPolicy = (0, _groupPolicySKF5rlUN.i)({
    toolsBySender: (params.agentId && params.agentId.trim() ? (0, _agentScopeConfigCMp71_.r)(cfg, params.agentId)?.tools : void 0)?.toolsBySender,
    ...sender
  });
  if (agentPolicy) return (0, _sandboxToolPolicyA1J2EpRM.n)(agentPolicy);
  return (0, _sandboxToolPolicyA1J2EpRM.n)((0, _groupPolicySKF5rlUN.i)({
    toolsBySender: cfg.tools?.toolsBySender,
    ...sender
  }));
}
//#endregion /* v9-b68ea76be52f4987 */
