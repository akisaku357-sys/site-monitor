"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.i = resetInboundDedupe;exports.n = commitInboundDedupe;exports.r = releaseInboundDedupe;exports.t = claimInboundDedupe;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _globalSingletonDE6St75u = require("./global-singleton-DE6St75u.js");
var _sessionKeyUtilsCe_xWkNq = require("./session-key-utils-Ce_xWkNq.js");
require("./globals-YU5FjfZK.js");
var _dedupeBD30U36x = require("./dedupe-BD30U36x.js");
var _channelRouteL2PJXNE = require("./channel-route-L2PJ-xNE.js");
var _commandTurnContextBiMylvBj = require("./command-turn-context-BiMylvBj.js");
//#region src/auto-reply/reply/inbound-dedupe.ts
const DEFAULT_INBOUND_DEDUPE_TTL_MS = 20 * 6e4;
const DEFAULT_INBOUND_DEDUPE_MAX = 5e3;
/**
* Keep inbound dedupe shared across bundled chunks so the same provider
* message cannot bypass dedupe by entering through a different chunk copy.
*/
const INBOUND_DEDUPE_CACHE_KEY = Symbol.for("openclaw.inboundDedupeCache");
const INBOUND_DEDUPE_INFLIGHT_KEY = Symbol.for("openclaw.inboundDedupeInflight");
const inboundDedupeCache = (0, _dedupeBD30U36x.n)(INBOUND_DEDUPE_CACHE_KEY, {
  ttlMs: DEFAULT_INBOUND_DEDUPE_TTL_MS,
  maxSize: DEFAULT_INBOUND_DEDUPE_MAX
});
const inboundDedupeInFlight = (0, _globalSingletonDE6St75u.n)(INBOUND_DEDUPE_INFLIGHT_KEY, () => /* @__PURE__ */new Set());
const resolveInboundPeerId = (ctx) => ctx.OriginatingTo ?? ctx.To ?? ctx.From ?? ctx.SessionKey;
function resolveInboundDedupeSessionScope(ctx) {
  const sessionKey = (0, _commandTurnContextBiMylvBj.c)(ctx) || (0, _stringCoerceDyL154ka.c)(ctx.SessionKey) || "";
  if (!sessionKey) return "";
  const parsed = (0, _sessionKeyUtilsCe_xWkNq.c)(sessionKey);
  if (!parsed) return sessionKey;
  return `agent:${parsed.agentId}`;
}
function buildInboundDedupeKey(ctx) {
  const provider = (0, _stringCoerceDyL154ka.s)(ctx.OriginatingChannel ?? ctx.Provider ?? ctx.Surface) || "";
  const messageId = (0, _stringCoerceDyL154ka.c)(ctx.MessageSid);
  if (!provider || !messageId) return null;
  const peerId = resolveInboundPeerId(ctx);
  if (!peerId) return null;
  const sessionScope = resolveInboundDedupeSessionScope(ctx);
  const routeKey = (0, _channelRouteL2PJXNE.n)({
    channel: provider,
    to: peerId,
    accountId: (0, _stringCoerceDyL154ka.c)(ctx.AccountId) ?? "",
    threadId: ctx.MessageThreadId
  });
  return JSON.stringify([
  sessionScope,
  routeKey,
  messageId]
  );
}
function claimInboundDedupe(ctx, opts) {
  const key = buildInboundDedupeKey(ctx);
  if (!key) return { status: "invalid" };
  if ((opts?.cache ?? inboundDedupeCache).peek(key, opts?.now)) return {
    status: "duplicate",
    key
  };
  const inFlight = opts?.inFlight ?? inboundDedupeInFlight;
  if (inFlight.has(key)) return {
    status: "inflight",
    key
  };
  inFlight.add(key);
  return {
    status: "claimed",
    key
  };
}
function commitInboundDedupe(key, opts) {
  (opts?.cache ?? inboundDedupeCache).check(key, opts?.now);
  (opts?.inFlight ?? inboundDedupeInFlight).delete(key);
}
function releaseInboundDedupe(key, opts) {
  (opts?.inFlight ?? inboundDedupeInFlight).delete(key);
}
function resetInboundDedupe() {
  inboundDedupeCache.clear();
  inboundDedupeInFlight.clear();
}
//#endregion /* v9-e8a3c8ef0b805682 */
