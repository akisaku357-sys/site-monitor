"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.a = resolveProviderToolPolicy;exports.i = resolveInheritedToolPolicyForSession;exports.n = resolveEffectiveToolPolicy;exports.o = resolveSubagentToolPolicyForSession;exports.r = resolveGroupToolPolicy;exports.s = resolveTrustedGroupId;exports.t = filterToolsByPolicy;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _providerIdZTW9Rdln = require("./provider-id-zTW9Rdln.js");
require("./agent-scope-CtLXGcWm.js");
var _sessionKeyUtilsCe_xWkNq = require("./session-key-utils-Ce_xWkNq.js");
var _sessionKeyBte0mmcq = require("./session-key-Bte0mmcq.js");
var _agentScopeConfigCMp71_ = require("./agent-scope-config-CMp71_27.js");
var _logger0o2znY2U = require("./logger-0o2znY2U.js");
var _messageChannelCYCKkVrh = require("./message-channel-CYCKkVrh.js");
var _registryBf5TpUad = require("./registry-Bf5TpUad.js");
var _sessionConversationXHNnUnBT = require("./session-conversation-XHNnUnBT.js");
require("./plugins-DYTHbmt7.js");
var _groupPolicySKF5rlUN = require("./group-policy-sKF5rlUN.js");
var _sandboxToolPolicyA1J2EpRM = require("./sandbox-tool-policy-A1J2EpRM.js");
var _toolPolicyCOX5DaEj = require("./tool-policy-COX5DaEj.js");
var _toolPolicyMatchC9WqMgmG = require("./tool-policy-match-C9WqMgmG.js");
var _subagentCapabilitiesMB73wM9t = require("./subagent-capabilities-mB73wM9t.js");
//#region src/agents/pi-tools.policy.ts
/**
* Tools always denied for sub-agents regardless of depth.
* These are system-level or interactive tools that sub-agents should never use.
*/
const SUBAGENT_TOOL_DENY_ALWAYS = [
"gateway",
"agents_list",
"session_status",
"cron",
"sessions_send"];

/**
* Additional tools denied for leaf sub-agents (depth >= maxSpawnDepth).
* These are tools that only make sense for orchestrator sub-agents that can spawn children.
*/
const SUBAGENT_TOOL_DENY_LEAF = [
"subagents",
"sessions_list",
"sessions_history",
"sessions_spawn"];

function resolveSubagentDenyListForRole(role) {
  if (role === "leaf") return [...SUBAGENT_TOOL_DENY_ALWAYS, ...SUBAGENT_TOOL_DENY_LEAF];
  return [...SUBAGENT_TOOL_DENY_ALWAYS];
}
function mergeConfiguredSubagentAllow(allow, alsoAllow) {
  return allow && alsoAllow ? Array.from(new Set([...allow, ...alsoAllow])) : allow;
}
function resolveSubagentToolPolicyForSession(cfg, sessionKey, opts) {
  const configured = cfg?.tools?.subagents?.tools;
  const capabilities = (0, _subagentCapabilitiesMB73wM9t.n)(sessionKey, {
    cfg,
    store: (0, _subagentCapabilitiesMB73wM9t.o)(sessionKey, {
      cfg,
      store: opts?.store
    })
  });
  const allow = Array.isArray(configured?.allow) ? configured.allow : void 0;
  const alsoAllow = Array.isArray(configured?.alsoAllow) ? configured.alsoAllow : void 0;
  const explicitAllow = new Set([...(allow ?? []), ...(alsoAllow ?? [])].map((toolName) => (0, _toolPolicyCOX5DaEj.m)(toolName)));
  const deny = [...resolveSubagentDenyListForRole(capabilities.role).filter((toolName) => !explicitAllow.has((0, _toolPolicyCOX5DaEj.m)(toolName))), ...(Array.isArray(configured?.deny) ? configured.deny : [])];
  return {
    allow: mergeConfiguredSubagentAllow(allow, alsoAllow),
    deny
  };
}
function resolveInheritedToolPolicyForSession(cfg, sessionKey, opts) {
  const inheritedToolAllow = (0, _subagentCapabilitiesMB73wM9t.r)(sessionKey, {
    cfg,
    store: opts?.store
  });
  const inheritedToolDeny = (0, _subagentCapabilitiesMB73wM9t.i)(sessionKey, {
    cfg,
    store: opts?.store
  });
  if (inheritedToolAllow.length === 0 && inheritedToolDeny.length === 0) return;
  return {
    ...(inheritedToolAllow.length > 0 ? { allow: inheritedToolAllow } : {}),
    ...(inheritedToolDeny.length > 0 ? { deny: inheritedToolDeny } : {})
  };
}
function filterToolsByPolicy(tools, policy) {
  if (!policy) return tools;
  return tools.filter((tool) => (0, _toolPolicyMatchC9WqMgmG.n)(tool.name, policy));
}
function normalizeProviderKey(value) {
  const normalized = (0, _stringCoerceDyL154ka.a)(value);
  const slashIndex = normalized.indexOf("/");
  if (slashIndex <= 0) return (0, _providerIdZTW9Rdln.r)(normalized);
  const provider = (0, _providerIdZTW9Rdln.r)(normalized.slice(0, slashIndex));
  const modelId = normalized.slice(slashIndex + 1);
  return modelId ? `${provider}/${modelId}` : provider;
}
function isCanonicalProviderKey(value) {
  return (0, _stringCoerceDyL154ka.a)(value) === normalizeProviderKey(value);
}
function buildProviderToolPolicyLookup(entries) {
  const lookup = /* @__PURE__ */new Map();
  for (const [key, value] of entries) {
    const normalized = normalizeProviderKey(key);
    if (!normalized) continue;
    const canonical = isCanonicalProviderKey(key);
    const existing = lookup.get(normalized);
    if (!existing || canonical && !existing.canonical) lookup.set(normalized, {
      canonical,
      value
    });
  }
  const resolved = /* @__PURE__ */new Map();
  for (const [key, entry] of lookup) resolved.set(key, entry.value);
  return resolved;
}
function collectUniqueStrings(values) {
  const seen = /* @__PURE__ */new Set();
  const resolved = [];
  for (const value of values) {
    const trimmed = value?.trim();
    if (!trimmed || seen.has(trimmed)) continue;
    seen.add(trimmed);
    resolved.push(trimmed);
  }
  return resolved;
}
function buildScopedGroupIdCandidates(groupId) {
  const raw = groupId?.trim();
  if (!raw) return [];
  const topicSenderMatch = raw.match(/^(.+):topic:([^:]+):sender:([^:]+)$/i);
  if (topicSenderMatch) {
    const [, chatId, topicId] = topicSenderMatch;
    return collectUniqueStrings([
    raw,
    `${chatId}:topic:${topicId}`,
    chatId]
    );
  }
  const topicMatch = raw.match(/^(.+):topic:([^:]+)$/i);
  if (topicMatch) {
    const [, chatId, topicId] = topicMatch;
    return collectUniqueStrings([`${chatId}:topic:${topicId}`, chatId]);
  }
  const senderMatch = raw.match(/^(.+):sender:([^:]+)$/i);
  if (senderMatch) {
    const [, chatId] = senderMatch;
    return collectUniqueStrings([raw, chatId]);
  }
  return [raw];
}
function resolveGroupContextFromSessionKey(sessionKey) {
  const raw = (sessionKey ?? "").trim();
  if (!raw) return {};
  const { baseSessionKey, threadId } = (0, _sessionKeyUtilsCe_xWkNq.u)(raw);
  const conversationKey = threadId ? baseSessionKey : raw;
  const conversation = (0, _sessionKeyUtilsCe_xWkNq.l)(conversationKey);
  if (conversation) {
    const resolvedConversation = (0, _sessionConversationXHNnUnBT.t)({
      channel: conversation.channel,
      kind: conversation.kind,
      rawId: conversation.rawId
    });
    return {
      channel: conversation.channel,
      groupIds: collectUniqueStrings([
      ...buildScopedGroupIdCandidates(conversation.rawId),
      resolvedConversation?.id,
      resolvedConversation?.baseConversationId,
      ...(resolvedConversation?.parentConversationCandidates ?? [])]
      )
    };
  }
  const parts = (conversationKey ?? raw).split(":").filter(Boolean);
  let body = parts[0] === "agent" ? parts.slice(2) : parts;
  if (body[0] === "subagent") body = body.slice(1);
  if (body.length < 3) return {};
  const [channel, kind, ...rest] = body;
  if (kind !== "group" && kind !== "channel") return {};
  const groupId = rest.join(":").trim();
  if (!groupId) return {};
  return {
    channel: (0, _stringCoerceDyL154ka.a)(channel),
    groupIds: buildScopedGroupIdCandidates(groupId)
  };
}
function resolveTrustedGroupIdFromContexts(params) {
  const callerGroupId = (params.groupId ?? "").trim();
  if (!callerGroupId) return {
    groupId: params.groupId,
    dropped: false
  };
  const trustedGroupIds = collectUniqueStrings([...(params.sessionContext.groupIds ?? []), ...(params.spawnedContext.groupIds ?? [])]);
  if (trustedGroupIds.length === 0) return {
    groupId: null,
    dropped: true
  };
  if (trustedGroupIds.includes(callerGroupId)) return {
    groupId: params.groupId,
    dropped: false
  };
  return {
    groupId: null,
    dropped: true
  };
}
function resolveTrustedGroupId(params) {
  return resolveTrustedGroupIdFromContexts({
    groupId: params.groupId,
    sessionContext: resolveGroupContextFromSessionKey(params.sessionKey),
    spawnedContext: resolveGroupContextFromSessionKey(params.spawnedBy)
  });
}
function resolveProviderToolPolicy(params) {
  const provider = params.modelProvider?.trim();
  if (!provider || !params.byProvider) return;
  const entries = Object.entries(params.byProvider);
  if (entries.length === 0) return;
  const lookup = buildProviderToolPolicyLookup(entries);
  const normalizedProvider = normalizeProviderKey(provider);
  const rawModelId = (0, _stringCoerceDyL154ka.s)(params.modelId);
  const fullModelId = rawModelId ? `${normalizedProvider}/${rawModelId}` : void 0;
  const candidates = [...(fullModelId ? [fullModelId] : []), normalizedProvider];
  for (const key of candidates) {
    const match = lookup.get(key);
    if (match) return match;
  }
}
function resolveExplicitProfileAlsoAllow(tools) {
  return Array.isArray(tools?.alsoAllow) ? tools.alsoAllow : void 0;
}
function hasExplicitToolSection(section) {
  return section !== void 0 && section !== null;
}
function detectImplicitProfileGrants(params) {
  const entries = [];
  if (hasExplicitToolSection(params.agentTools?.exec) || params.includeGlobalSections && hasExplicitToolSection(params.globalTools?.exec)) entries.push({
    section: "tools.exec",
    grants: ["exec", "process"]
  });
  if (hasExplicitToolSection(params.agentTools?.fs) || params.includeGlobalSections && hasExplicitToolSection(params.globalTools?.fs)) entries.push({
    section: "tools.fs",
    grants: [
    "read",
    "write",
    "edit"]

  });
  if (entries.length === 0) return;
  return { entries };
}
function formatImplicitToolSections(sections) {
  return sections.join(" / ");
}
function formatToolListForWarning(toolNames) {
  return toolNames.map((toolName) => `"${toolName}"`).join(", ");
}
function resolveEffectiveToolPolicy(params) {
  const agentId = (typeof params.agentId === "string" && params.agentId.trim() ? (0, _sessionKeyBte0mmcq.l)(params.agentId) : void 0) ?? (params.sessionKey ? (0, _sessionKeyBte0mmcq.d)(params.sessionKey) : void 0);
  const agentTools = (params.config && agentId ? (0, _agentScopeConfigCMp71_.r)(params.config, agentId) : void 0)?.tools;
  const globalTools = params.config?.tools;
  const profile = agentTools?.profile ?? globalTools?.profile;
  const profileSource = agentTools?.profile ? "agent" : globalTools?.profile ? "global" : void 0;
  const providerPolicy = resolveProviderToolPolicy({
    byProvider: globalTools?.byProvider,
    modelProvider: params.modelProvider,
    modelId: params.modelId
  });
  const agentProviderPolicy = resolveProviderToolPolicy({
    byProvider: agentTools?.byProvider,
    modelProvider: params.modelProvider,
    modelId: params.modelId
  });
  const explicitProfileAlsoAllow = resolveExplicitProfileAlsoAllow(agentTools) ?? resolveExplicitProfileAlsoAllow(globalTools);
  if (profile) {
    const implicitGrants = detectImplicitProfileGrants({
      globalTools,
      agentTools,
      includeGlobalSections: profileSource === "global"
    });
    if (implicitGrants) {
      const profilePolicy = (0, _toolPolicyCOX5DaEj.l)((0, _toolPolicyCOX5DaEj.h)(profile), explicitProfileAlsoAllow);
      const uncoveredEntries = implicitGrants.entries.map((entry) => ({
        section: entry.section,
        grants: entry.grants.filter((toolName) => !(0, _toolPolicyMatchC9WqMgmG.n)(toolName, profilePolicy))
      })).filter((entry) => entry.grants.length > 0);
      const uncovered = uncoveredEntries.flatMap((entry) => entry.grants);
      if (uncovered.length > 0) (0, _logger0o2znY2U.a)(`tools policy: profile "${profile}"${agentId ? ` (agent "${agentId}")` : ""} has configured tool sections (${formatImplicitToolSections(uncoveredEntries.map((entry) => entry.section))}) that no longer implicitly widen the profile. Add alsoAllow: [${formatToolListForWarning(uncovered)}] explicitly if these tools should be available. See #47487.`);
    }
  }
  const profileAlsoAllow = explicitProfileAlsoAllow ? Array.from(new Set(explicitProfileAlsoAllow)) : void 0;
  return {
    agentId,
    globalPolicy: (0, _sandboxToolPolicyA1J2EpRM.n)(globalTools),
    globalProviderPolicy: (0, _sandboxToolPolicyA1J2EpRM.n)(providerPolicy),
    agentPolicy: (0, _sandboxToolPolicyA1J2EpRM.n)(agentTools),
    agentProviderPolicy: (0, _sandboxToolPolicyA1J2EpRM.n)(agentProviderPolicy),
    profile,
    providerProfile: agentProviderPolicy?.profile ?? providerPolicy?.profile,
    profileAlsoAllow,
    providerProfileAlsoAllow: Array.isArray(agentProviderPolicy?.alsoAllow) ? agentProviderPolicy?.alsoAllow : Array.isArray(providerPolicy?.alsoAllow) ? providerPolicy?.alsoAllow : void 0
  };
}
function resolveGroupToolPolicy(params) {
  if (!params.config) return;
  const sessionContext = resolveGroupContextFromSessionKey(params.sessionKey);
  const spawnedContext = resolveGroupContextFromSessionKey(params.spawnedBy);
  const trustedGroup = resolveTrustedGroupIdFromContexts({
    groupId: params.groupId,
    sessionContext,
    spawnedContext
  });
  const groupIds = collectUniqueStrings([
  ...(sessionContext.groupIds ?? []),
  ...(spawnedContext.groupIds ?? []),
  ...buildScopedGroupIdCandidates(trustedGroup.groupId)]
  );
  if (groupIds.length === 0) return;
  const channel = (0, _messageChannelCYCKkVrh.u)(sessionContext.channel ?? spawnedContext.channel ?? params.messageProvider);
  if (!channel) return;
  let plugin;
  try {
    plugin = (0, _registryBf5TpUad.n)(channel);
  } catch {
    plugin = void 0;
  }
  for (const groupId of groupIds) {
    const toolsConfig = plugin?.groups?.resolveToolPolicy?.({
      cfg: params.config,
      groupId,
      groupChannel: trustedGroup.dropped ? null : params.groupChannel,
      groupSpace: trustedGroup.dropped ? null : params.groupSpace,
      accountId: params.accountId,
      senderId: params.senderId,
      senderName: params.senderName,
      senderUsername: params.senderUsername,
      senderE164: params.senderE164
    });
    const policy = (0, _sandboxToolPolicyA1J2EpRM.n)(toolsConfig);
    if (policy) return policy;
  }
  return (0, _sandboxToolPolicyA1J2EpRM.n)((0, _groupPolicySKF5rlUN.r)({
    cfg: params.config,
    channel,
    messageProvider: channel,
    groupId: groupIds[0],
    groupIdCandidates: groupIds.slice(1),
    accountId: params.accountId,
    senderId: params.senderId,
    senderName: params.senderName,
    senderUsername: params.senderUsername,
    senderE164: params.senderE164
  }));
}
//#endregion /* v9-9ed16612e75003e6 */
