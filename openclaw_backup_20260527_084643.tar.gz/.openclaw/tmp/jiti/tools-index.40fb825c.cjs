"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.registerTools = registerTools;





var _group = require("./group.js");
var _member = require("./member.js");
var _remind = require("./remind.js"); /**
 * Tools registration factory.
 *
 * Centralized tool registration logic, grouped by category.
 * Plugin entry only needs to call registerTools(api) to register all tools.
 */ /**
 * Register all tools.
 *
 * Call each registration function by category in order; to add a new category, simply append here.
 *
 * @param api - OpenClaw plugin API
 */function registerTools(api) {// -- Member --
  (0, _member.registerMemberTools)(api); // -- Group info --
  (0, _group.registerGroupTools)(api); // -- Scheduled reminder --
  (0, _remind.registerRemindTools)(api);
  // -- Append new categories here --
  // registerXxxTools(api);
} /* v9-226cc0c045072e72 */
