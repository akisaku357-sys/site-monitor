"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.t = getMachineDisplayName;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _nodeOs = _interopRequireDefault(require("node:os"));
var _nodeChild_process = require("node:child_process");
var _nodeUtil = require("node:util");function _interopRequireDefault(e) {return e && e.__esModule ? e : { default: e };}
//#region src/infra/machine-name.ts
const execFileAsync = (0, _nodeUtil.promisify)(_nodeChild_process.execFile);
let cachedPromise = null;
async function tryScutil(key) {
  try {
    const { stdout } = await execFileAsync("/usr/sbin/scutil", ["--get", key], {
      timeout: 1e3,
      windowsHide: true
    });
    const value = (0, _stringCoerceDyL154ka.c)(stdout ?? "") ?? "";
    return value.length > 0 ? value : null;
  } catch {
    return null;
  }
}
function fallbackHostName() {
  return ((0, _stringCoerceDyL154ka.c)(_nodeOs.default.hostname()) ?? "").replace(/\.local$/i, "") || "openclaw";
}
async function getMachineDisplayName() {
  if (cachedPromise) return cachedPromise;
  cachedPromise = (async () => {
    if (process.env.VITEST || false) return fallbackHostName();
    if (process.platform === "darwin") {
      const computerName = await tryScutil("ComputerName");
      if (computerName) return computerName;
      const localHostName = await tryScutil("LocalHostName");
      if (localHostName) return localHostName;
    }
    return fallbackHostName();
  })();
  return cachedPromise;
}
//#endregion /* v9-9b7f7b1028a06d0b */
