"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = listSkillCommandsForWorkspace;exports.t = listSkillCommandsForAgents;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _agentScopeCtLXGcWm = require("./agent-scope-CtLXGcWm.js");
var _agentScopeConfigCMp71_ = require("./agent-scope-config-CMp71_27.js");
var _globalsYU5FjfZK = require("./globals-YU5FjfZK.js");
var _skillsJUNRkaHl = require("./skills-JUNRkaHl.js");
var _skillCommandsBaseDSCgaXEW = require("./skill-commands-base-DSCgaXEW.js");
var _execDefaults60zNtKRO = require("./exec-defaults-60zNtKRO.js");
var _skillsRemoteBCbpja7h = require("./skills-remote-BCbpja7h.js");
var _nodeFs = _interopRequireDefault(require("node:fs"));function _interopRequireDefault(e) {return e && e.__esModule ? e : { default: e };}
//#region src/auto-reply/skill-commands.ts
function listSkillCommandsForWorkspace(params) {
  return (0, _skillsJUNRkaHl.n)(params.workspaceDir, {
    config: params.cfg,
    agentId: params.agentId,
    skillFilter: params.skillFilter,
    eligibility: { remote: (0, _skillsRemoteBCbpja7h.t)({ advertiseExecNode: (0, _execDefaults60zNtKRO.t)({
          cfg: params.cfg,
          agentId: params.agentId
        }) }) },
    reservedNames: (0, _skillCommandsBaseDSCgaXEW.t)()
  });
}
function dedupeBySkillName(commands) {
  const seen = /* @__PURE__ */new Set();
  const out = [];
  for (const cmd of commands) {
    const key = (0, _stringCoerceDyL154ka.s)(cmd.skillName);
    if (key && seen.has(key)) continue;
    if (key) seen.add(key);
    out.push(cmd);
  }
  return out;
}
function listSkillCommandsForAgents(params) {
  const mergeSkillFilters = (existing, incoming) => {
    if (existing === void 0 || incoming === void 0) return;
    if (existing.length === 0) return Array.from(new Set(incoming));
    if (incoming.length === 0) return Array.from(new Set(existing));
    return Array.from(new Set([...existing, ...incoming]));
  };
  const agentIds = params.agentIds ?? (0, _agentScopeConfigCMp71_.n)(params.cfg);
  const used = (0, _skillCommandsBaseDSCgaXEW.t)();
  const entries = [];
  const workspaceFilters = /* @__PURE__ */new Map();
  for (const agentId of agentIds) {
    const workspaceDir = (0, _agentScopeConfigCMp71_.o)(params.cfg, agentId);
    if (!_nodeFs.default.existsSync(workspaceDir)) {
      (0, _globalsYU5FjfZK.r)(`Skipping agent "${agentId}": workspace does not exist: ${workspaceDir}`);
      continue;
    }
    let canonicalDir;
    try {
      canonicalDir = _nodeFs.default.realpathSync(workspaceDir);
    } catch {
      (0, _globalsYU5FjfZK.r)(`Skipping agent "${agentId}": cannot resolve workspace: ${workspaceDir}`);
      continue;
    }
    const skillFilter = (0, _agentScopeCtLXGcWm.f)(params.cfg, agentId);
    const existing = workspaceFilters.get(canonicalDir);
    if (existing) {
      existing.skillFilter = mergeSkillFilters(existing.skillFilter, skillFilter);
      continue;
    }
    workspaceFilters.set(canonicalDir, {
      workspaceDir,
      skillFilter
    });
  }
  for (const { workspaceDir, skillFilter } of workspaceFilters.values()) {
    const commands = (0, _skillsJUNRkaHl.n)(workspaceDir, {
      config: params.cfg,
      skillFilter,
      eligibility: { remote: (0, _skillsRemoteBCbpja7h.t)({ advertiseExecNode: (0, _execDefaults60zNtKRO.t)({ cfg: params.cfg }) }) },
      reservedNames: used
    });
    for (const command of commands) {
      used.add((0, _stringCoerceDyL154ka.a)(command.name));
      entries.push(command);
    }
  }
  return dedupeBySkillName(entries);
}
//#endregion /* v9-89ff604a17b1118b */
