"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = buildWorkspaceSkillCommandSpecs;exports.t = resolveSkillsInstallPreferences;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _pathBlG8lhgR = require("./path-BlG8lhgR.js");
var _agentFilterCZoQBzQY = require("./agent-filter-CZoQBzQY.js");
var _bundleManifestS4nKSc4m = require("./bundle-manifest-s4nKSc4m.js");
var _jsonFilesC2hqjU = require("./json-files-C2hqjU--.js");
var _configStateCjJBf8PG = require("./config-state-CjJBf8PG.js");
var _pluginRegistryCgH_ZSlH = require("./plugin-registry-CgH_ZSlH.js");
require("./scan-paths-BJFKmVji.js");
var _subsystemDSPWLoK = require("./subsystem-DSPWLoK5.js");
var _frontmatterDIUKpDA = require("./frontmatter-DIUKpD-a.js");
require("./config-DU04JXyx.js");
require("./env-overrides-DIYux-i5.js");
var _workspaceBoRIIBbL = require("./workspace-BoRIIBbL.js");
var _nodeFs = _interopRequireDefault(require("node:fs"));
var _nodePath = _interopRequireDefault(require("node:path"));function _interopRequireDefault(e) {return e && e.__esModule ? e : { default: e };}
//#region src/plugins/bundle-commands.ts
function parseFrontmatterBool(value, fallback) {
  const normalized = (0, _stringCoerceDyL154ka.s)(value);
  if (!normalized) return fallback;
  if (normalized === "true" || normalized === "yes" || normalized === "1") return true;
  if (normalized === "false" || normalized === "no" || normalized === "0") return false;
  return fallback;
}
function stripFrontmatter(content) {
  const normalized = content.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  if (!normalized.startsWith("---")) return normalized.trim();
  const endIndex = normalized.indexOf("\n---", 3);
  if (endIndex === -1) return normalized.trim();
  return normalized.slice(endIndex + 4).trim();
}
function readClaudeBundleManifest(rootDir) {
  const result = (0, _jsonFilesC2hqjU.u)({
    rootDir,
    relativePath: _bundleManifestS4nKSc4m.t,
    boundaryLabel: "plugin root",
    rejectHardlinks: true
  });
  return result.ok ? result.value : {};
}
function resolveClaudeCommandRootDirs(rootDir) {
  const declared = (0, _bundleManifestS4nKSc4m.s)(readClaudeBundleManifest(rootDir).commands);
  return (0, _bundleManifestS4nKSc4m.o)(_nodeFs.default.existsSync(_nodePath.default.join(rootDir, "commands")) ? ["commands"] : [], declared);
}
function listMarkdownFilesRecursive(rootDir) {
  const pending = [rootDir];
  const files = [];
  while (pending.length > 0) {
    const current = pending.pop();
    if (!current) continue;
    let entries;
    try {
      entries = _nodeFs.default.readdirSync(current, { withFileTypes: true });
    } catch {
      continue;
    }
    for (const entry of entries) {
      if (entry.name.startsWith(".")) continue;
      const fullPath = _nodePath.default.join(current, entry.name);
      if (entry.isDirectory()) {
        pending.push(fullPath);
        continue;
      }
      if (entry.isFile() && (0, _stringCoerceDyL154ka.s)(entry.name)?.endsWith(".md")) files.push(fullPath);
    }
  }
  return files.toSorted((a, b) => a.localeCompare(b));
}
function toDefaultCommandName(rootDir, filePath) {
  return _nodePath.default.relative(rootDir, filePath).replace(/\.[^.]+$/u, "").split(_nodePath.default.sep).join(":");
}
function toDefaultDescription(rawName, promptTemplate) {
  return promptTemplate.split(/\r?\n/u).map((line) => line.trim()).find(Boolean) || rawName;
}
function loadBundleCommandsFromRoot(params) {
  const entries = [];
  for (const filePath of listMarkdownFilesRecursive(params.commandRoot)) {
    let raw;
    try {
      raw = _nodeFs.default.readFileSync(filePath, "utf-8");
    } catch {
      continue;
    }
    const frontmatter = (0, _frontmatterDIUKpDA.u)(raw);
    if (parseFrontmatterBool(frontmatter["disable-model-invocation"], false)) continue;
    const promptTemplate = stripFrontmatter(raw);
    if (!promptTemplate) continue;
    const rawName = (0, _stringCoerceDyL154ka.c)(frontmatter.name) || toDefaultCommandName(params.commandRoot, filePath);
    if (!rawName) continue;
    const description = (0, _stringCoerceDyL154ka.c)(frontmatter.description) || toDefaultDescription(rawName, promptTemplate);
    entries.push({
      pluginId: params.pluginId,
      rawName,
      description,
      promptTemplate,
      sourceFilePath: filePath
    });
  }
  return entries;
}
function loadEnabledClaudeBundleCommands(params) {
  if (!(0, _configStateCjJBf8PG.r)(params.cfg?.plugins)) return [];
  const registry = (0, _pluginRegistryCgH_ZSlH.n)({
    workspaceDir: params.workspaceDir,
    config: params.cfg,
    includeDisabled: true
  });
  const normalizedPlugins = (0, _configStateCjJBf8PG.s)(params.cfg?.plugins);
  const commands = [];
  for (const record of registry.plugins) {
    if (record.format !== "bundle" || record.bundleFormat !== "claude" || !(record.bundleCapabilities ?? []).includes("commands")) continue;
    if (!(0, _configStateCjJBf8PG.l)({
      id: record.id,
      origin: record.origin,
      config: normalizedPlugins,
      rootConfig: params.cfg
    }).activated) continue;
    for (const relativeRoot of resolveClaudeCommandRootDirs(record.rootDir)) {
      const commandRoot = _nodePath.default.resolve(record.rootDir, relativeRoot);
      if (!_nodeFs.default.existsSync(commandRoot)) continue;
      if (!(0, _pathBlG8lhgR.a)(record.rootDir, commandRoot, { requireRealpath: true })) continue;
      commands.push(...loadBundleCommandsFromRoot({
        pluginId: record.id,
        commandRoot
      }));
    }
  }
  return commands;
}
//#endregion
//#region src/agents/skills/command-specs.ts
const skillsLogger = (0, _subsystemDSPWLoK.t)("skills");
const skillCommandDebugOnce = /* @__PURE__ */new Set();
const SKILL_COMMAND_MAX_LENGTH = 32;
const SKILL_COMMAND_FALLBACK = "skill";
const SKILL_COMMAND_DESCRIPTION_MAX_LENGTH = 100;
function debugSkillCommandOnce(messageKey, message, meta) {
  if (skillCommandDebugOnce.has(messageKey)) return;
  skillCommandDebugOnce.add(messageKey);
  skillsLogger.debug(message, meta);
}
function sanitizeSkillCommandName(raw) {
  return (0, _stringCoerceDyL154ka.a)(raw).replace(/[^a-z0-9_]+/g, "_").replace(/_+/g, "_").replace(/^_+|_+$/g, "").slice(0, SKILL_COMMAND_MAX_LENGTH) || SKILL_COMMAND_FALLBACK;
}
function resolveUniqueSkillCommandName(base, used) {
  const normalizedBase = (0, _stringCoerceDyL154ka.a)(base);
  if (!used.has(normalizedBase)) return base;
  for (let index = 2; index < 1e3; index += 1) {
    const suffix = `_${index}`;
    const maxBaseLength = Math.max(1, SKILL_COMMAND_MAX_LENGTH - suffix.length);
    const candidate = `${base.slice(0, maxBaseLength)}${suffix}`;
    const candidateKey = (0, _stringCoerceDyL154ka.a)(candidate);
    if (!used.has(candidateKey)) return candidate;
  }
  return `${base.slice(0, Math.max(1, SKILL_COMMAND_MAX_LENGTH - 2))}_x`;
}
function buildWorkspaceSkillCommandSpecs(workspaceDir, opts) {
  const effectiveSkillFilter = opts?.skillFilter ?? (0, _agentFilterCZoQBzQY.t)(opts?.config, opts?.agentId);
  const userInvocable = (opts?.entries ? (0, _workspaceBoRIIBbL.i)(opts.entries, {
    config: opts?.config,
    skillFilter: effectiveSkillFilter,
    eligibility: opts?.eligibility
  }) : (0, _workspaceBoRIIBbL.a)(workspaceDir, {
    config: opts?.config,
    managedSkillsDir: opts?.managedSkillsDir,
    bundledSkillsDir: opts?.bundledSkillsDir,
    skillFilter: effectiveSkillFilter,
    eligibility: opts?.eligibility
  })).filter((entry) => entry.invocation?.userInvocable !== false);
  const used = /* @__PURE__ */new Set();
  for (const reserved of opts?.reservedNames ?? []) used.add((0, _stringCoerceDyL154ka.a)(reserved));
  const specs = [];
  for (const entry of userInvocable) {
    const rawName = entry.skill.name;
    const base = sanitizeSkillCommandName(rawName);
    if (base !== rawName) debugSkillCommandOnce(`sanitize:${rawName}:${base}`, `Sanitized skill command name "${rawName}" to "/${base}".`, {
      rawName,
      sanitized: `/${base}`
    });
    const unique = resolveUniqueSkillCommandName(base, used);
    if (unique !== base) debugSkillCommandOnce(`dedupe:${rawName}:${unique}`, `De-duplicated skill command name for "${rawName}" to "/${unique}".`, {
      rawName,
      deduped: `/${unique}`
    });
    used.add((0, _stringCoerceDyL154ka.a)(unique));
    const rawDescription = entry.skill.description?.trim() || rawName;
    const description = rawDescription.length > SKILL_COMMAND_DESCRIPTION_MAX_LENGTH ? rawDescription.slice(0, SKILL_COMMAND_DESCRIPTION_MAX_LENGTH - 1) + "…" : rawDescription;
    const dispatch = (() => {
      const kindRaw = (0, _stringCoerceDyL154ka.a)(entry.frontmatter?.["command-dispatch"] ?? entry.frontmatter?.["command_dispatch"] ?? "");
      if (!kindRaw || kindRaw !== "tool") return;
      const toolName = (entry.frontmatter?.["command-tool"] ?? entry.frontmatter?.["command_tool"] ?? "").trim();
      if (!toolName) {
        debugSkillCommandOnce(`dispatch:missingTool:${rawName}`, `Skill command "/${unique}" requested tool dispatch but did not provide command-tool. Ignoring dispatch.`, {
          skillName: rawName,
          command: unique
        });
        return;
      }
      const argModeRaw = (0, _stringCoerceDyL154ka.s)(entry.frontmatter?.["command-arg-mode"] ?? entry.frontmatter?.["command_arg_mode"] ?? "");
      if (!(!argModeRaw || argModeRaw === "raw" ? "raw" : null)) debugSkillCommandOnce(`dispatch:badArgMode:${rawName}:${argModeRaw}`, `Skill command "/${unique}" requested tool dispatch but has unknown command-arg-mode. Falling back to raw.`, {
        skillName: rawName,
        command: unique,
        argMode: argModeRaw
      });
      return {
        kind: "tool",
        toolName,
        argMode: "raw"
      };
    })();
    specs.push({
      name: unique,
      skillName: rawName,
      description,
      ...(dispatch ? { dispatch } : {})
    });
  }
  const bundleCommands = loadEnabledClaudeBundleCommands({
    workspaceDir,
    cfg: opts?.config
  });
  for (const entry of bundleCommands) {
    const base = sanitizeSkillCommandName(entry.rawName);
    if (base !== entry.rawName) debugSkillCommandOnce(`bundle-sanitize:${entry.rawName}:${base}`, `Sanitized bundle command name "${entry.rawName}" to "/${base}".`, {
      rawName: entry.rawName,
      sanitized: `/${base}`
    });
    const unique = resolveUniqueSkillCommandName(base, used);
    if (unique !== base) debugSkillCommandOnce(`bundle-dedupe:${entry.rawName}:${unique}`, `De-duplicated bundle command name for "${entry.rawName}" to "/${unique}".`, {
      rawName: entry.rawName,
      deduped: `/${unique}`
    });
    used.add((0, _stringCoerceDyL154ka.a)(unique));
    const description = entry.description.length > SKILL_COMMAND_DESCRIPTION_MAX_LENGTH ? entry.description.slice(0, SKILL_COMMAND_DESCRIPTION_MAX_LENGTH - 1) + "…" : entry.description;
    specs.push({
      name: unique,
      skillName: entry.rawName,
      description,
      promptTemplate: entry.promptTemplate,
      sourceFilePath: entry.sourceFilePath
    });
  }
  return specs;
}
//#endregion
//#region src/agents/skills.ts
function resolveSkillsInstallPreferences(config) {
  const raw = config?.skills?.install;
  const preferBrew = raw?.preferBrew ?? true;
  const manager = (0, _stringCoerceDyL154ka.a)((0, _stringCoerceDyL154ka.c)(raw?.nodeManager));
  return {
    preferBrew,
    nodeManager: manager === "pnpm" || manager === "yarn" || manager === "bun" || manager === "npm" ? manager : "npm"
  };
}
//#endregion /* v9-c7bac46ea033f0d8 */
