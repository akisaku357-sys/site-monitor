"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = listVideoGenerationProviders;exports.t = getVideoGenerationProvider;var _providerIdZTW9Rdln = require("./provider-id-zTW9Rdln.js");
var _prototypeKeysGIgii6VQ = require("./prototype-keys-gIgii6VQ.js");
require("./model-selection-P-81eBKx.js");
var _capabilityProviderRuntimeBwiWIvn = require("./capability-provider-runtime-BwiWIvn0.js");
//#region src/video-generation/provider-registry.ts
const BUILTIN_VIDEO_GENERATION_PROVIDERS = [];
const UNSAFE_PROVIDER_IDS = new Set([
"__proto__",
"constructor",
"prototype"]
);
function normalizeVideoGenerationProviderId(id) {
  const normalized = (0, _providerIdZTW9Rdln.r)(id ?? "");
  if (!normalized || (0, _prototypeKeysGIgii6VQ.t)(normalized)) return;
  return normalized;
}
function isSafeVideoGenerationProviderId(id) {
  return Boolean(id && !UNSAFE_PROVIDER_IDS.has(id));
}
function resolvePluginVideoGenerationProviders(cfg) {
  return (0, _capabilityProviderRuntimeBwiWIvn.r)({
    key: "videoGenerationProviders",
    cfg
  });
}
function buildProviderMaps(cfg) {
  const canonical = /* @__PURE__ */new Map();
  const aliases = /* @__PURE__ */new Map();
  const register = (provider) => {
    const id = normalizeVideoGenerationProviderId(provider.id);
    if (!isSafeVideoGenerationProviderId(id)) return;
    canonical.set(id, provider);
    aliases.set(id, provider);
    for (const alias of provider.aliases ?? []) {
      const normalizedAlias = normalizeVideoGenerationProviderId(alias);
      if (isSafeVideoGenerationProviderId(normalizedAlias)) aliases.set(normalizedAlias, provider);
    }
  };
  for (const provider of BUILTIN_VIDEO_GENERATION_PROVIDERS) register(provider);
  for (const provider of resolvePluginVideoGenerationProviders(cfg)) register(provider);
  return {
    canonical,
    aliases
  };
}
function listVideoGenerationProviders(cfg) {
  return [...buildProviderMaps(cfg).canonical.values()];
}
function getVideoGenerationProvider(providerId, cfg) {
  const normalized = normalizeVideoGenerationProviderId(providerId);
  if (!normalized) return;
  return buildProviderMaps(cfg).aliases.get(normalized);
}
//#endregion /* v9-853467eaaa5480c9 */
