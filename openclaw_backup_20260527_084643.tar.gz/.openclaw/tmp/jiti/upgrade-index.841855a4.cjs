"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.UPGRADE_COMMAND_NAMES = void 0;exports.parseUpgradeCommand = parseUpgradeCommand;exports.yuanbaobotUpgradeCommand = exports.yuanbaoUpgradeCommand = void 0;var _upgrade = require("./upgrade.js");
var _index = require("../command-sync/index.js");
/**
 * All command names that trigger the upgrade flow.
 */
const UPGRADE_COMMAND_NAMES = exports.UPGRADE_COMMAND_NAMES = ["/yuanbao-upgrade", "/yuanbaobot-upgrade"];
/**
 * Parse upgrade command: supports both bare command name and command with version parameter.
 *
 * Decouples "command matching" from "upgrade execution":
 * The upper layer only needs to check whether a match occurred and whether a target version is provided.
 */
function parseUpgradeCommand(rawBody) {
  const body = rawBody.trim();
  for (const name of UPGRADE_COMMAND_NAMES) {
    if (body === name) {
      return { matched: true };
    }
    if (body.startsWith(`${name} `)) {
      const version = body.slice(name.length + 1).trim() || undefined;
      return { matched: true, version };
    }
  }
  return { matched: false };
}
/**
 * Create upgrade command definition.
 */
function makeUpgradeCommand(name, description) {
  return {
    name,
    description,
    requireAuth: false,
    acceptsArgs: true,
    handler: async (ctx) => {
      const requested = ctx.args?.trim() || undefined;
      const text = await (0, _upgrade.performUpgrade)(ctx.config, ctx.accountId, undefined, requested);
      return { text };
    }
  };
}
const yuanbaoUpgradeCommand = exports.yuanbaoUpgradeCommand = makeUpgradeCommand(UPGRADE_COMMAND_NAMES[0].slice(1), "升级 yuanbao 插件到最新正式版本");
const yuanbaobotUpgradeCommand = exports.yuanbaobotUpgradeCommand = makeUpgradeCommand(UPGRADE_COMMAND_NAMES[1].slice(1), "升级 yuanbao 插件到最新正式版本（别名）");
// Self-register plugin command metadata for backend sync
(0, _index.registerPluginCommand)(yuanbaoUpgradeCommand.name, yuanbaoUpgradeCommand.description);
(0, _index.registerPluginCommand)(yuanbaobotUpgradeCommand.name, yuanbaobotUpgradeCommand.description); /* v9-b571dde4e5166394 */
