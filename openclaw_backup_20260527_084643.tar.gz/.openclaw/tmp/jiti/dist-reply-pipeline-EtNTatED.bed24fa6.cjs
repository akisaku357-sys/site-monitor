"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = resolveChannelSourceReplyDeliveryMode;exports.t = createChannelReplyPipeline;var _registryNormalizeCWTP5axf = require("./registry-normalize-CWTP5axf.js");
var _registryLoadedReadDQJDORLt = require("./registry-loaded-read-DQJDORLt.js");
var _sourceReplyDeliveryModeDng9YkQe = require("./source-reply-delivery-mode-Dng9YkQe.js");
var _replyPrefixD0w1Q_CL = require("./reply-prefix-D0w1Q_CL.js");
var _typingC657onUT = require("./typing-C657onUT.js");
//#region src/channels/message/reply-pipeline.ts
function resolveChannelSourceReplyDeliveryMode(params) {
  return (0, _sourceReplyDeliveryModeDng9YkQe.n)(params);
}
function createChannelReplyPipeline(params) {
  const channelId = params.channel ? (0, _registryNormalizeCWTP5axf.t)(params.channel) ?? params.channel : void 0;
  let plugin;
  let pluginTransformResolved = false;
  const resolvePluginTransform = () => {
    if (pluginTransformResolved) return plugin?.messaging?.transformReplyPayload;
    pluginTransformResolved = true;
    plugin = channelId ? (0, _registryLoadedReadDQJDORLt.t)(channelId) : void 0;
    return plugin?.messaging?.transformReplyPayload;
  };
  const transformReplyPayload = params.transformReplyPayload ? params.transformReplyPayload : channelId ? (payload) => resolvePluginTransform()?.({
    payload,
    cfg: params.cfg,
    accountId: params.accountId
  }) ?? payload : void 0;
  return {
    ...(0, _replyPrefixD0w1Q_CL.n)({
      cfg: params.cfg,
      agentId: params.agentId,
      channel: params.channel,
      accountId: params.accountId
    }),
    ...(transformReplyPayload ? { transformReplyPayload } : {}),
    ...(params.typingCallbacks ? { typingCallbacks: params.typingCallbacks } : params.typing ? { typingCallbacks: (0, _typingC657onUT.t)(params.typing) } : {})
  };
}
//#endregion /* v9-f383260b1f4b19a4 */
