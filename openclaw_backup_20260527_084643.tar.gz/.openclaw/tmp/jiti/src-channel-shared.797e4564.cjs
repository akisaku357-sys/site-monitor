"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.yuanbaoConfigAdapter = exports.yuanbaoCapabilities = exports.YUANBAO_PLUGIN_ID = exports.YUANBAO_CHANNEL_ID = void 0;Object.defineProperty(exports, "yuanbaoConfigSchema", { enumerable: true, get: function () {return _configSchema.yuanbaoConfigSchema;} });exports.yuanbaoReload = exports.yuanbaoMeta = void 0;Object.defineProperty(exports, "yuanbaoSetupAdapter", { enumerable: true, get: function () {return _setupCore.yuanbaoSetupAdapter;} });Object.defineProperty(exports, "yuanbaoSetupWizard", { enumerable: true, get: function () {return _setupSurface.yuanbaoSetupWizard;} });








var _channelPluginCommon = require("openclaw/plugin-sdk/channel-plugin-common");
var _accounts = require("./accounts.js");
var _configSchema = require("./config-schema.js");
var _setupCore = require("./setup-core.js");
var _setupSurface = require("./setup-surface.js"); /**
 * Shared building blocks for the Yuanbao channel plugin.
 *
 * Both the full `yuanbaoPlugin` (used at runtime) and the lightweight
 * `yuanbaoSetupPlugin` (used during `openclaw onboard` / `openclaw configure`)
 * consume these helpers. Keeping them out of `channel.ts` prevents the setup
 * surface from pulling in the full runtime dependencies (WS gateway, message
 * actions, HTTP clients, protobuf, etc.).
 */const YUANBAO_PLUGIN_ID = exports.YUANBAO_PLUGIN_ID = "openclaw-plugin-yuanbao";const YUANBAO_CHANNEL_ID = exports.YUANBAO_CHANNEL_ID = "yuanbao";const yuanbaoMeta = exports.yuanbaoMeta = { id: YUANBAO_CHANNEL_ID, label: "Yuanbao", selectionLabel: "Yuanbao (腾讯元宝)", detailLabel: "Yuanbao", docsPath: "/plugins/community#yuanbao",
  docsLabel: "yuanbao",
  blurb: "Tencent Yuanbao AI assistant conversation channel",
  aliases: ["yb", "yuanbao", "tencent-yuanbao", "元宝"],
  order: 85,
  quickstartAllowFrom: true
};
const yuanbaoCapabilities = exports.yuanbaoCapabilities = {
  chatTypes: ["direct", "group"],
  media: true,
  reactions: true,
  threads: false,
  polls: false,
  nativeCommands: true
};
const yuanbaoReload = exports.yuanbaoReload = {
  configPrefixes: ["channels.yuanbao"]
};
/**
 * Config adapter shared by the full plugin and the setup-only plugin.
 *
 * Note: only imports from `accounts.js`, which stays lightweight (no WS/HTTP
 * runtime). Keep it that way — heavy runtime imports belong in `channel.ts`.
 */
const yuanbaoConfigAdapter = exports.yuanbaoConfigAdapter = {
  listAccountIds: (cfg) => (0, _accounts.listYuanbaoAccountIds)(cfg),
  resolveAccount: (cfg, accountId) => (0, _accounts.resolveYuanbaoAccount)({ cfg, accountId: accountId ?? undefined }),
  defaultAccountId: (cfg) => (0, _accounts.resolveDefaultYuanbaoAccountId)(cfg),
  setAccountEnabled: ({ cfg, accountId, enabled }) => (0, _channelPluginCommon.setAccountEnabledInConfigSection)({
    cfg,
    sectionKey: YUANBAO_CHANNEL_ID,
    accountId,
    enabled,
    allowTopLevel: true
  }),
  deleteAccount: ({ cfg, accountId }) => (0, _channelPluginCommon.deleteAccountFromConfigSection)({
    cfg,
    sectionKey: YUANBAO_CHANNEL_ID,
    accountId,
    clearBaseFields: [
    "name",
    "appKey",
    "appSecret",
    "token",
    "overflowPolicy",
    "replyToMode",
    "outboundQueueStrategy",
    "mediaMaxMb",
    "historyLimit",
    "disableBlockStreaming",
    "fallbackReply"]

  }),
  isConfigured: (account) => Boolean(account?.configured),
  describeAccount: (account) => ({
    accountId: account?.accountId ?? _channelPluginCommon.DEFAULT_ACCOUNT_ID,
    name: account?.name,
    enabled: account?.enabled ?? false,
    configured: account?.configured ?? false,
    tokenStatus: account?.configured ? "available" : "missing"
  }),
  resolveAllowFrom: ({ cfg, accountId }) => {
    const account = (0, _accounts.resolveYuanbaoAccount)({ cfg, accountId: accountId ?? undefined });
    return (account.config.dm?.allowFrom ?? []).map((entry) => String(entry));
  },
  formatAllowFrom: ({ allowFrom }) => (allowFrom ?? []).
  map((entry) => String(entry).trim()).
  filter(Boolean).
  map((entry) => entry.toLowerCase())
};
/** Re-export the shared setup adapter / wizard for call sites that pull them from one place. */

/** Shared config schema re-export. */ /* v9-c35cb81bd4abc0a3 */
