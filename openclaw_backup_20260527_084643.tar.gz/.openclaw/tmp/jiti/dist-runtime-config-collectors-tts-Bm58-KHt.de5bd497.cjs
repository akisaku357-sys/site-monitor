"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.t = collectTtsApiKeyAssignments;var _utilsSBTEdeml = require("./utils-sBTEdeml.js");
require("./shared-Cv5g0_Ch.js");
var _runtimeSharedCPFXAPqc = require("./runtime-shared-CPFXAPqc.js");
//#region src/secrets/runtime-config-collectors-tts.ts
function collectProviderApiKeyAssignment(params) {
  (0, _runtimeSharedCPFXAPqc.n)({
    value: params.providerConfig.apiKey,
    path: `${params.pathPrefix}.providers.${params.providerId}.apiKey`,
    expected: "string",
    defaults: params.defaults,
    context: params.context,
    active: params.active,
    inactiveReason: params.inactiveReason,
    apply: (value) => {
      params.providerConfig.apiKey = value;
    }
  });
}
function collectTtsApiKeyAssignments(params) {
  const providers = params.tts.providers;
  if ((0, _utilsSBTEdeml.c)(providers)) {
    for (const [providerId, providerConfig] of Object.entries(providers)) {
      if (!(0, _utilsSBTEdeml.c)(providerConfig)) continue;
      collectProviderApiKeyAssignment({
        providerId,
        providerConfig,
        pathPrefix: params.pathPrefix,
        defaults: params.defaults,
        context: params.context,
        active: params.active,
        inactiveReason: params.inactiveReason
      });
    }
    return;
  }
}
//#endregion /* v9-fea5c35fb53a5e25 */
