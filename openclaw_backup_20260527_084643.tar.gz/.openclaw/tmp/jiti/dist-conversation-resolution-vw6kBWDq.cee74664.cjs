"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = resolveCommandConversationResolution;exports.r = resolveInboundConversationResolution;exports.t = resolveChannelDefaultBindingPlacement;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _idsBE_yccbC = require("./ids-BE_yccbC.js");
var _registryCtWyD2pE = require("./registry-CtWyD2pE.js");
var _runtimeDHxRl5F = require("./runtime-DHxRl5F1.js");
var _channelRouteL2PJXNE = require("./channel-route-L2PJ-xNE.js");
var _registryBf5TpUad = require("./registry-Bf5TpUad.js");
require("./plugins-DYTHbmt7.js");
var _sessionBindingNormalizationD9PNZGcW = require("./session-binding-normalization-D9PNZGcW.js");
var _conversationIdCW0vVUEs = require("./conversation-id-CW0vVUEs.js");
var _threadBindingApiTBMd1vH = require("./thread-binding-api-tBMd1vH5.js");
//#region src/channels/plugins/target-parsing.ts
function parseWithPlugin(getPlugin, rawChannel, rawTarget) {
  const channel = (0, _idsBE_yccbC.r)(rawChannel) ?? (0, _registryBf5TpUad.a)(rawChannel);
  if (!channel) return null;
  return getPlugin(channel)?.messaging?.parseExplicitTarget?.({ raw: rawTarget }) ?? null;
}
function parseExplicitTargetForChannel(channel, rawTarget) {
  return parseWithPlugin(_registryBf5TpUad.t, channel, rawTarget);
}
//#endregion
//#region src/channels/conversation-resolution.ts
const CANONICAL_TARGET_PREFIXES = ["user:", "spaces/"];
function resolveChannelId(raw) {
  const normalizedRaw = (0, _stringCoerceDyL154ka.c)(raw);
  if (!normalizedRaw) return null;
  return (0, _registryCtWyD2pE.a)(normalizedRaw) ?? (0, _registryBf5TpUad.a)(normalizedRaw) ?? (0, _stringCoerceDyL154ka.s)(normalizedRaw) ?? null;
}
function getActiveRegistryChannelPlugin(rawChannel) {
  const normalized = (0, _registryCtWyD2pE.a)(rawChannel) ?? (0, _stringCoerceDyL154ka.c)(rawChannel);
  if (!normalized) return;
  return (0, _runtimeDHxRl5F.t)()?.channels.find((entry) => entry.plugin.id === normalized)?.plugin;
}
function getRuntimeChannelPluginCandidates(channel) {
  const candidates = [getActiveRegistryChannelPlugin(channel), (0, _registryBf5TpUad.n)(channel)].filter((plugin) => Boolean(plugin));
  return [...new Map(candidates.map((plugin) => [plugin.id, plugin])).values()];
}
function resolveRuntimeChannelPlugin(channel) {
  return getRuntimeChannelPluginCandidates(channel)[0];
}
function shouldDefaultParentConversationToSelf(plugin) {
  return plugin?.bindings?.selfParentConversationByDefault === true;
}
function normalizeResolutionTarget(params) {
  const conversationId = (0, _stringCoerceDyL154ka.c)(params.conversation?.conversationId);
  if (!conversationId) return null;
  const parentConversationId = (0, _stringCoerceDyL154ka.c)(params.conversation?.parentConversationId);
  const defaultParentToSelf = shouldDefaultParentConversationToSelf(params.plugin) && !params.threadId && !parentConversationId;
  const normalized = (0, _sessionBindingNormalizationD9PNZGcW.r)({
    conversationId,
    parentConversationId: defaultParentToSelf ? conversationId : parentConversationId
  });
  const normalizedParentConversationId = defaultParentToSelf ? normalized.conversationId : normalized.parentConversationId;
  const placementHint = params.includePlacementHint === false ? void 0 : resolveChannelDefaultBindingPlacement(params.channel);
  return {
    canonical: {
      channel: params.channel,
      accountId: params.accountId,
      conversationId: normalized.conversationId,
      ...(normalizedParentConversationId ? { parentConversationId: normalizedParentConversationId } : {})
    },
    ...(params.threadId ? { threadId: params.threadId } : {}),
    ...(placementHint ? { placementHint } : {}),
    source: params.source
  };
}
function resolveBindingAccountId(params) {
  return (0, _stringCoerceDyL154ka.c)(params.rawAccountId) || (0, _stringCoerceDyL154ka.c)(params.plugin?.config.defaultAccountId?.(params.cfg)) || "default";
}
function resolveChannelTargetId(params) {
  const target = (0, _stringCoerceDyL154ka.c)(params.target);
  if (!target) return;
  const lower = (0, _stringCoerceDyL154ka.a)(target);
  const channelPrefix = `${params.channel}:`;
  if (lower.startsWith(channelPrefix)) return resolveChannelTargetId({
    channel: params.channel,
    target: target.slice(channelPrefix.length)
  });
  if (CANONICAL_TARGET_PREFIXES.some((prefix) => lower.startsWith(prefix))) return target;
  const explicitConversationId = (0, _conversationIdCW0vVUEs.t)({ targets: [target] });
  if (explicitConversationId) return explicitConversationId;
  const parsedTarget = (0, _stringCoerceDyL154ka.c)(parseExplicitTargetForChannel(params.channel, target)?.to);
  if (parsedTarget) return (0, _conversationIdCW0vVUEs.t)({ targets: [parsedTarget] }) ?? parsedTarget;
  return target;
}
function buildThreadingContext(params) {
  const to = (0, _stringCoerceDyL154ka.c)(params.originatingTo) ?? (0, _stringCoerceDyL154ka.c)(params.fallbackTo);
  return {
    ...(to ? { To: to } : {}),
    ...(params.from ? { From: params.from } : {}),
    ...(params.chatType ? { ChatType: params.chatType } : {}),
    ...(params.threadId ? { MessageThreadId: params.threadId } : {}),
    ...(params.nativeChannelId ? { NativeChannelId: params.nativeChannelId } : {})
  };
}
function resolveChannelDefaultBindingPlacement(rawChannel) {
  const channel = resolveChannelId(rawChannel);
  if (!channel) return;
  return resolveRuntimeChannelPlugin(channel)?.conversationBindings?.defaultTopLevelPlacement ?? (0, _threadBindingApiTBMd1vH.t)(channel);
}
function resolveCommandConversationResolution(params) {
  const channel = resolveChannelId(params.channel);
  if (!channel) return null;
  const plugin = resolveRuntimeChannelPlugin(channel);
  const accountId = resolveBindingAccountId({
    rawAccountId: params.accountId,
    plugin,
    cfg: params.cfg
  });
  const threadId = (0, _channelRouteL2PJXNE.h)(params.threadId);
  const commandParams = {
    accountId,
    threadId,
    threadParentId: (0, _stringCoerceDyL154ka.c)(params.threadParentId),
    senderId: (0, _stringCoerceDyL154ka.c)(params.senderId),
    sessionKey: (0, _stringCoerceDyL154ka.c)(params.sessionKey),
    parentSessionKey: (0, _stringCoerceDyL154ka.c)(params.parentSessionKey),
    from: (0, _stringCoerceDyL154ka.c)(params.from),
    chatType: (0, _stringCoerceDyL154ka.c)(params.chatType),
    originatingTo: params.originatingTo ?? void 0,
    commandTo: params.commandTo ?? void 0,
    fallbackTo: params.fallbackTo ?? void 0
  };
  const resolvedByProvider = plugin?.bindings?.resolveCommandConversation?.(commandParams);
  const providerResolution = normalizeResolutionTarget({
    channel,
    accountId,
    conversation: resolvedByProvider,
    source: "command-provider",
    threadId,
    plugin,
    includePlacementHint: params.includePlacementHint
  });
  if (providerResolution) return providerResolution;
  const focusedBinding = plugin?.threading?.resolveFocusedBinding?.({
    cfg: params.cfg,
    accountId,
    context: buildThreadingContext({
      fallbackTo: params.fallbackTo ?? void 0,
      originatingTo: params.originatingTo ?? void 0,
      threadId,
      from: (0, _stringCoerceDyL154ka.c)(params.from),
      chatType: (0, _stringCoerceDyL154ka.c)(params.chatType),
      nativeChannelId: (0, _stringCoerceDyL154ka.c)(params.nativeChannelId)
    })
  });
  const focusedResolution = normalizeResolutionTarget({
    channel,
    accountId,
    conversation: focusedBinding,
    source: "focused-binding",
    threadId,
    plugin,
    includePlacementHint: params.includePlacementHint
  });
  if (focusedResolution) return focusedResolution;
  const baseConversationId = resolveChannelTargetId({
    channel,
    target: params.originatingTo
  }) ?? resolveChannelTargetId({
    channel,
    target: params.commandTo
  }) ?? resolveChannelTargetId({
    channel,
    target: params.fallbackTo
  });
  const parentConversationId = resolveChannelTargetId({
    channel,
    target: params.threadParentId
  }) ?? (threadId && baseConversationId && baseConversationId !== threadId ? baseConversationId : void 0);
  const conversationId = threadId || baseConversationId;
  if (!conversationId) return null;
  return normalizeResolutionTarget({
    channel,
    accountId,
    conversation: {
      conversationId,
      parentConversationId
    },
    source: "command-fallback",
    threadId,
    plugin,
    includePlacementHint: params.includePlacementHint
  });
}
function resolveInboundConversationResolution(params) {
  const channel = resolveChannelId(params.channel);
  if (!channel) return null;
  const plugin = resolveRuntimeChannelPlugin(channel);
  const accountId = resolveBindingAccountId({
    rawAccountId: params.accountId,
    plugin,
    cfg: params.cfg
  });
  const threadId = (0, _channelRouteL2PJXNE.h)(params.threadId);
  const resolverParams = {
    from: (0, _stringCoerceDyL154ka.c)(params.from),
    to: (0, _stringCoerceDyL154ka.c)(params.to),
    conversationId: (0, _stringCoerceDyL154ka.c)(params.conversationId) ?? (0, _stringCoerceDyL154ka.c)(params.groupId) ?? (0, _stringCoerceDyL154ka.c)(params.to),
    threadId,
    isGroup: params.isGroup ?? true
  };
  const providerConversation = plugin?.messaging?.resolveInboundConversation?.(resolverParams);
  const providerResolution = normalizeResolutionTarget({
    channel,
    accountId,
    conversation: providerConversation,
    source: "inbound-provider",
    threadId,
    plugin
  });
  if (providerResolution || providerConversation === null) return providerResolution;
  const artifactConversation = (0, _threadBindingApiTBMd1vH.n)({
    channelId: channel,
    ...resolverParams
  });
  const artifactResolution = normalizeResolutionTarget({
    channel,
    accountId,
    conversation: artifactConversation,
    source: "inbound-bundled-artifact",
    threadId,
    plugin
  });
  if (artifactResolution || artifactConversation === null) return artifactResolution;
  const parentConversationId = resolveChannelTargetId({
    channel,
    target: params.to
  }) ?? resolveChannelTargetId({
    channel,
    target: params.conversationId
  }) ?? resolveChannelTargetId({
    channel,
    target: params.groupId
  });
  const genericConversationId = threadId ?? resolveChannelTargetId({
    channel,
    target: params.conversationId
  }) ?? resolveChannelTargetId({
    channel,
    target: params.groupId
  }) ?? parentConversationId;
  if (!genericConversationId) return null;
  return normalizeResolutionTarget({
    channel,
    accountId,
    conversation: {
      conversationId: genericConversationId,
      parentConversationId: threadId != null ? parentConversationId : void 0
    },
    source: "inbound-fallback",
    threadId,
    plugin
  });
}
//#endregion /* v9-5625202bc7864a81 */
