"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.i = resolveActiveMemoryBackendConfig;exports.n = closeActiveMemorySearchManagers;exports.r = getActiveMemorySearchManager;exports.t = closeActiveMemorySearchManager;var _utilsSBTEdeml = require("./utils-sBTEdeml.js");
require("./agent-scope-CtLXGcWm.js");
var _agentScopeConfigCMp71_ = require("./agent-scope-config-CMp71_27.js");
var _configStateCjJBf8PG = require("./config-state-CjJBf8PG.js");
var _memoryStateDKjCVvl = require("./memory-state-DKjCVvl8.js");
var _activeRuntimeRegistryWEpAEHY = require("./active-runtime-registry-wEpAEHY2.js");
var _standaloneRuntimeRegistryLoaderB16U68P = require("./standalone-runtime-registry-loader-B16U68P-.js");
//#region src/plugins/memory-runtime.ts
function resolveMemoryRuntimePluginIds(config) {
  const plugins = (0, _configStateCjJBf8PG.s)(config.plugins);
  const memorySlot = plugins.slots.memory;
  if (!plugins.enabled || typeof memorySlot !== "string" || memorySlot.trim().length === 0) return [];
  const pluginId = memorySlot.trim();
  if (plugins.deny.includes(pluginId) || plugins.entries[pluginId]?.enabled === false) return [];
  return [pluginId];
}
function resolveMemoryRuntimeWorkspaceDir(cfg) {
  const dir = (0, _agentScopeConfigCMp71_.o)(cfg, (0, _agentScopeConfigCMp71_.c)(cfg));
  if (typeof dir !== "string" || !dir.trim()) return;
  return (0, _utilsSBTEdeml.p)(dir);
}
function ensureMemoryRuntime(cfg) {
  const current = (0, _memoryStateDKjCVvl.o)();
  if (current || !cfg) return current;
  const onlyPluginIds = resolveMemoryRuntimePluginIds(cfg);
  if (onlyPluginIds.length === 0) return (0, _memoryStateDKjCVvl.o)();
  (0, _activeRuntimeRegistryWEpAEHY.n)({ requiredPluginIds: onlyPluginIds });
  if ((0, _memoryStateDKjCVvl.o)()) return (0, _memoryStateDKjCVvl.o)();
  (0, _standaloneRuntimeRegistryLoaderB16U68P.t)({
    requiredPluginIds: onlyPluginIds,
    loadOptions: {
      config: cfg,
      onlyPluginIds,
      workspaceDir: resolveMemoryRuntimeWorkspaceDir(cfg)
    }
  });
  return (0, _memoryStateDKjCVvl.o)();
}
async function getActiveMemorySearchManager(params) {
  const runtime = ensureMemoryRuntime(params.cfg);
  if (!runtime) return {
    manager: null,
    error: "memory plugin unavailable"
  };
  return await runtime.getMemorySearchManager(params);
}
function resolveActiveMemoryBackendConfig(params) {
  return ensureMemoryRuntime(params.cfg)?.resolveMemoryBackendConfig(params) ?? null;
}
async function closeActiveMemorySearchManagers(cfg) {
  await (0, _memoryStateDKjCVvl.o)()?.closeAllMemorySearchManagers?.();
}
async function closeActiveMemorySearchManager(params) {
  await (0, _memoryStateDKjCVvl.o)()?.closeMemorySearchManager?.(params);
}
//#endregion /* v9-e76056a633c0eaac */
