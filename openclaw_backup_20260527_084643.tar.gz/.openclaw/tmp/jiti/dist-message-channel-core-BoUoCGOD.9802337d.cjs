"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.i = isInternalNonDeliveryChannel;exports.n = normalizeMessageChannel;exports.r = void 0;exports.t = isDeliverableMessageChannel;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _idsBE_yccbC = require("./ids-BE_yccbC.js");
var _registryNormalizeCWTP5axf = require("./registry-normalize-CWTP5axf.js");
//#region src/utils/message-channel-constants.ts
const INTERNAL_MESSAGE_CHANNEL = exports.r = "webchat";
const INTERNAL_NON_DELIVERY_CHANNELS = [
"heartbeat",
"cron",
"webhook",
"voice"];

function isInternalNonDeliveryChannel(value) {
  return INTERNAL_NON_DELIVERY_CHANNELS.includes(value);
}
//#endregion
//#region src/utils/message-channel-core.ts
function normalizeMessageChannel(raw) {
  const normalized = (0, _stringCoerceDyL154ka.s)(raw);
  if (!normalized) return;
  if (normalized === "webchat") return INTERNAL_MESSAGE_CHANNEL;
  const builtIn = (0, _idsBE_yccbC.r)(normalized);
  if (builtIn) return builtIn;
  return (0, _registryNormalizeCWTP5axf.t)(normalized) ?? normalized;
}
function isDeliverableMessageChannel(value) {
  const normalized = normalizeMessageChannel(value);
  return normalized !== void 0 && normalized !== "webchat" && normalized === value;
}
//#endregion /* v9-b9422f1a72eaabdb */
