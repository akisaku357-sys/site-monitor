"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.a = isCommandMessage;exports.c = parseCommandArgs;exports.d = serializeCommandArgs;exports.i = formatCommandArgMenuTitle;exports.l = resolveCommandArgChoices;exports.n = buildCommandTextFromArgs;exports.o = listNativeCommandSpecs;exports.r = findCommandByNativeName;exports.s = listNativeCommandSpecsForConfig;exports.t = buildCommandText;exports.u = resolveCommandArgMenu;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _defaultsMDjiWzE = require("./defaults-mDjiWzE5.js");
var _registryBf5TpUad = require("./registry-Bf5TpUad.js");
require("./plugins-DYTHbmt7.js");
var _modelSelectionSharedClxdEp4X = require("./model-selection-shared-ClxdEp4X.js");
require("./model-selection-P-81eBKx.js");
var _commandsRegistryDataPiUeltWc = require("./commands-registry.data-piUeltWc.js");
var _commandsRegistryList98FRviq = require("./commands-registry-list--98FRviq.js");
var _commandsRegistryNormalizeCnHNsvCE = require("./commands-registry-normalize-CnHNsvCE.js");
require("./commands-text-routing-C2SuW22t.js");
//#region src/auto-reply/commands-registry.ts
function resolveNativeName(command, provider, options) {
  if (!command.nativeName) return;
  if (!provider) return command.nativeName;
  return (options?.includeBundledChannelFallback === false ? (0, _registryBf5TpUad.n)(provider) : (0, _registryBf5TpUad.t)(provider))?.commands?.resolveNativeCommandName?.({
    commandKey: command.key,
    defaultName: command.nativeName
  }) ?? command.nativeName;
}
function toNativeCommandSpec(command, provider) {
  const spec = {
    name: resolveNativeName(command, provider) ?? command.key,
    description: command.description,
    acceptsArgs: Boolean(command.acceptsArgs),
    args: command.args
  };
  if (command.descriptionLocalizations) spec.descriptionLocalizations = command.descriptionLocalizations;
  return spec;
}
function resolveNativeNames(command, provider) {
  return [resolveNativeName(command, provider), ...(command.nativeAliases ?? [])].filter((name) => Boolean(name));
}
function listNativeSpecsFromCommands(commands, provider) {
  return commands.filter((command) => command.scope !== "text" && command.nativeName).flatMap((command) => {
    const spec = toNativeCommandSpec(command, provider);
    return resolveNativeNames(command, provider).map((name) => {
      const nativeSpec = {
        name,
        description: spec.description,
        acceptsArgs: spec.acceptsArgs
      };
      if (spec.args) nativeSpec.args = spec.args;
      if (spec.descriptionLocalizations) nativeSpec.descriptionLocalizations = spec.descriptionLocalizations;
      return nativeSpec;
    });
  });
}
function listNativeCommandSpecs(params) {
  return listNativeSpecsFromCommands((0, _commandsRegistryList98FRviq.n)({ skillCommands: params?.skillCommands }), params?.provider);
}
function listNativeCommandSpecsForConfig(cfg, params) {
  return listNativeSpecsFromCommands((0, _commandsRegistryList98FRviq.r)(cfg, params), params?.provider);
}
function findCommandByNativeName(name, provider, options) {
  const normalized = (0, _stringCoerceDyL154ka.s)(name);
  if (!normalized) return;
  return (0, _commandsRegistryDataPiUeltWc.t)().find((command) => command.scope !== "text" && [resolveNativeName(command, provider, options), ...(command.nativeAliases ?? [])].some((name) => (0, _stringCoerceDyL154ka.s)(name) === normalized));
}
function buildCommandText(commandName, args) {
  const trimmedArgs = args?.trim();
  return trimmedArgs ? `/${commandName} ${trimmedArgs}` : `/${commandName}`;
}
function parsePositionalArgs(definitions, raw) {
  const values = {};
  const trimmed = raw.trim();
  if (!trimmed) return values;
  const tokens = trimmed.split(/\s+/).filter(Boolean);
  let index = 0;
  for (const definition of definitions) {
    if (index >= tokens.length) break;
    if (definition.captureRemaining) {
      values[definition.name] = tokens.slice(index).join(" ");
      index = tokens.length;
      break;
    }
    values[definition.name] = tokens[index];
    index += 1;
  }
  return values;
}
function formatPositionalArgs(definitions, values) {
  const parts = [];
  for (const definition of definitions) {
    const value = values[definition.name];
    if (value == null) continue;
    let rendered;
    if (typeof value === "string") rendered = value.trim();else
    rendered = String(value);
    if (!rendered) continue;
    parts.push(rendered);
    if (definition.captureRemaining) break;
  }
  return parts.length > 0 ? parts.join(" ") : void 0;
}
function parseCommandArgs(command, raw) {
  const trimmed = raw?.trim();
  if (!trimmed) return;
  if (!command.args || command.argsParsing === "none") return { raw: trimmed };
  return {
    raw: trimmed,
    values: parsePositionalArgs(command.args, trimmed)
  };
}
function serializeCommandArgs(command, args) {
  if (!args) return;
  const raw = args.raw?.trim();
  if (raw) return raw;
  if (!args.values || !command.args) return;
  if (command.formatArgs) return command.formatArgs(args.values);
  return formatPositionalArgs(command.args, args.values);
}
function buildCommandTextFromArgs(command, args) {
  return buildCommandText(command.nativeName ?? command.key, serializeCommandArgs(command, args));
}
function resolveDefaultCommandContext(cfg) {
  const resolved = (0, _modelSelectionSharedClxdEp4X.v)({
    cfg: cfg ?? {},
    defaultProvider: _defaultsMDjiWzE.r,
    defaultModel: _defaultsMDjiWzE.n
  });
  return {
    provider: resolved.provider ?? "openai",
    model: resolved.model ?? "gpt-5.5"
  };
}
function resolveCommandArgChoices(params) {
  const { command, arg, cfg } = params;
  if (!arg.choices) return [];
  const provided = arg.choices;
  return (Array.isArray(provided) ? provided : (() => {
    const defaults = resolveDefaultCommandContext(cfg);
    return provided({
      cfg,
      provider: params.provider ?? defaults.provider,
      model: params.model ?? defaults.model,
      catalog: params.catalog ?? (cfg ? (0, _modelSelectionSharedClxdEp4X.r)({ cfg }) : void 0),
      command,
      arg
    });
  })()).map((choice) => typeof choice === "string" ? {
    value: choice,
    label: choice
  } : choice);
}
function resolveCommandArgMenu(params) {
  const { command, args, cfg, provider, model, catalog } = params;
  if (!command.args || !command.argsMenu) return null;
  if (command.argsParsing === "none") return null;
  const resolvedCatalog = catalog ?? (cfg ? (0, _modelSelectionSharedClxdEp4X.r)({ cfg }) : void 0);
  const argSpec = command.argsMenu;
  const argName = argSpec === "auto" ? command.args.find((arg) => resolveCommandArgChoices({
    command,
    arg,
    cfg,
    provider,
    model,
    catalog: resolvedCatalog
  }).length > 0)?.name : argSpec.arg;
  if (!argName) return null;
  if (args?.values && args.values[argName] != null) return null;
  if (args?.raw && !args.values) return null;
  const arg = command.args.find((entry) => entry.name === argName);
  if (!arg) return null;
  const choices = resolveCommandArgChoices({
    command,
    arg,
    cfg,
    provider,
    model,
    catalog: resolvedCatalog
  });
  if (choices.length === 0) return null;
  return {
    arg,
    choices,
    title: argSpec !== "auto" ? argSpec.title : void 0
  };
}
function formatCommandArgMenuTitle(params) {
  const { command, menu } = params;
  if (menu.title) return menu.title;
  const commandLabel = command.nativeName ?? command.key;
  if (typeof menu.arg.choices === "function") {
    const options = menu.choices.map((choice) => choice.label.trim()).filter(Boolean).join(", ");
    if (options.length > 0 && options.length <= 160) return `Choose ${menu.arg.name} for /${commandLabel}.\nOptions: ${options}.`;
    return `Choose ${menu.arg.name} for /${commandLabel}.`;
  }
  return `Choose ${menu.arg.description || menu.arg.name} for /${commandLabel}.`;
}
function isCommandMessage(raw) {
  return (0, _commandsRegistryNormalizeCnHNsvCE.r)(raw).startsWith("/");
}
//#endregion /* v9-1eef255aa9066f78 */
