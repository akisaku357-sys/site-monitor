"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = readGatewayCallOptions;exports.r = resolveGatewayOptions;exports.t = callGatewayTool;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _pathsCw7f9XhU = require("./paths-Cw7f9XhU.js");
var _errorsB3ZrCRlt = require("./errors-b3ZrCRlt.js");
var _credentialPlannerDPeD90hR = require("./credential-planner-DPeD90hR.js");
var _credentialsBJ7jvgw = require("./credentials-BJ7jvgw3.js");
var _ioDoswVvYe = require("./io-DoswVvYe.js");
require("./config-B6Oplu5W.js");
var _clientInfoBVWE_ra = require("./client-info-BVWE_ra1.js");
var _methodScopesD4RcH8qD = require("./method-scopes-D4RcH8qD.js");
var _callT1U2G3yY = require("./call-t1U2G3yY.js");
var _operatorApprovalRuntimeTokenC5pv_wEb = require("./operator-approval-runtime-token-C5pv_wEb.js");
var _commonE9YpX7pB = require("./common-E9YpX7pB.js");
//#region src/agents/tools/gateway.ts
function readGatewayCallOptions(params) {
  return {
    gatewayUrl: (0, _commonE9YpX7pB.g)(params, "gatewayUrl", { trim: false }),
    gatewayToken: (0, _commonE9YpX7pB.g)(params, "gatewayToken", { trim: false }),
    timeoutMs: typeof params.timeoutMs === "number" ? params.timeoutMs : void 0
  };
}
function canonicalizeToolGatewayWsUrl(raw) {
  const input = raw.trim();
  let url;
  try {
    url = new URL(input);
  } catch (error) {
    const message = (0, _errorsB3ZrCRlt.i)(error);
    throw new Error(`invalid gatewayUrl: ${input} (${message})`, { cause: error });
  }
  if (url.protocol !== "ws:" && url.protocol !== "wss:") throw new Error(`invalid gatewayUrl protocol: ${url.protocol} (expected ws:// or wss://)`);
  if (url.username || url.password) throw new Error("invalid gatewayUrl: credentials are not allowed");
  if (url.search || url.hash) throw new Error("invalid gatewayUrl: query/hash not allowed");
  if (url.pathname && url.pathname !== "/") throw new Error("invalid gatewayUrl: path not allowed");
  return {
    origin: url.origin,
    key: `${url.protocol}//${(0, _stringCoerceDyL154ka.a)(url.host)}`
  };
}
function validateGatewayUrlOverrideForAgentTools(params) {
  const { cfg } = params;
  const port = (0, _pathsCw7f9XhU.d)(cfg);
  const localAllowed = new Set([
  `ws://127.0.0.1:${port}`,
  `wss://127.0.0.1:${port}`,
  `ws://localhost:${port}`,
  `wss://localhost:${port}`,
  `ws://[::1]:${port}`,
  `wss://[::1]:${port}`]
  );
  let remoteKey;
  const remoteUrl = (0, _stringCoerceDyL154ka.c)(cfg.gateway?.remote?.url) ?? "";
  if (remoteUrl) try {
    remoteKey = canonicalizeToolGatewayWsUrl(remoteUrl).key;
  } catch {}
  const parsed = canonicalizeToolGatewayWsUrl(params.urlOverride);
  if (localAllowed.has(parsed.key)) return {
    url: parsed.origin,
    target: "local"
  };
  if (remoteKey && parsed.key === remoteKey) return {
    url: parsed.origin,
    target: "remote"
  };
  throw new Error([
  "gatewayUrl override rejected.",
  `Allowed: ws(s) loopback on port ${port} (127.0.0.1/localhost/[::1])`,
  "Or: configure gateway.remote.url and omit gatewayUrl to use the configured remote gateway."].
  join(" "));
}
function resolveGatewayOverrideToken(params) {
  if (params.explicitToken) return params.explicitToken;
  return (0, _credentialsBJ7jvgw.r)({
    cfg: params.cfg,
    env: process.env,
    modeOverride: params.target,
    remoteTokenFallback: params.target === "remote" ? "remote-only" : "remote-env-local",
    remotePasswordFallback: params.target === "remote" ? "remote-only" : "remote-env-local"
  }).token;
}
function resolveGatewayOptions(opts) {
  const cfg = (0, _ioDoswVvYe.i)();
  const validatedOverride = (0, _credentialPlannerDPeD90hR.a)(opts?.gatewayUrl) !== void 0 ? validateGatewayUrlOverrideForAgentTools({
    cfg,
    urlOverride: String(opts?.gatewayUrl)
  }) : void 0;
  const explicitToken = (0, _credentialPlannerDPeD90hR.a)(opts?.gatewayToken);
  const token = validatedOverride ? resolveGatewayOverrideToken({
    cfg,
    target: validatedOverride.target,
    explicitToken
  }) : explicitToken;
  const timeoutMs = typeof opts?.timeoutMs === "number" && Number.isFinite(opts.timeoutMs) ? Math.max(1, Math.floor(opts.timeoutMs)) : 3e4;
  return {
    url: validatedOverride?.url,
    token,
    timeoutMs
  };
}
const APPROVAL_RUNTIME_METHODS = new Set([
"exec.approval.request",
"exec.approval.waitDecision",
"plugin.approval.request",
"plugin.approval.waitDecision"]
);
function resolveApprovalRuntimeTokenForGatewayTool(params) {
  if (!APPROVAL_RUNTIME_METHODS.has(params.method)) return;
  if ((0, _credentialPlannerDPeD90hR.a)(params.opts.gatewayUrl) !== void 0) return;
  return (0, _operatorApprovalRuntimeTokenC5pv_wEb.t)();
}
async function callGatewayTool(method, opts, params, extra) {
  const gateway = resolveGatewayOptions(opts);
  const scopes = Array.isArray(extra?.scopes) ? extra.scopes : (0, _methodScopesD4RcH8qD.u)(method, params);
  const approvalRuntimeToken = resolveApprovalRuntimeTokenForGatewayTool({
    method,
    opts
  });
  return await (0, _callT1U2G3yY.r)({
    url: gateway.url,
    token: gateway.token,
    method,
    params,
    timeoutMs: gateway.timeoutMs,
    expectFinal: extra?.expectFinal,
    clientName: _clientInfoBVWE_ra.i.GATEWAY_CLIENT,
    clientDisplayName: "agent",
    mode: _clientInfoBVWE_ra.r.BACKEND,
    ...(approvalRuntimeToken ? { approvalRuntimeToken } : {}),
    scopes
  });
}
//#endregion /* v9-fc2aa3acbdc87000 */
