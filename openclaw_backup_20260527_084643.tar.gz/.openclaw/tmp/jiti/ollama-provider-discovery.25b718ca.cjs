"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.ollamaProviderDiscovery = exports.default = void 0;var _providerBaseUrlCrecHiog = require("../../provider-base-url-CrecHiog.js");
var _discoverySharedROvQIBGQ = require("../../discovery-shared-ROvQIBGQ.js");
//#region extensions/ollama/provider-discovery.ts
function resolveOllamaPluginConfig(ctx) {
  return (ctx.config.plugins?.entries ?? {}).ollama?.config ?? {};
}
async function runOllamaDiscovery(ctx) {
  return await (0, _discoverySharedROvQIBGQ.r)({
    ctx,
    pluginConfig: resolveOllamaPluginConfig(ctx),
    buildProvider: _providerBaseUrlCrecHiog.i
  });
}
const ollamaProviderDiscovery = exports.ollamaProviderDiscovery = exports.default = {
  id: _discoverySharedROvQIBGQ.n,
  label: "Ollama",
  docsPath: "/providers/ollama",
  envVars: ["OLLAMA_API_KEY"],
  auth: [],
  resolveSyntheticAuth: ({ provider, providerConfig }) => {
    if (!(0, _discoverySharedROvQIBGQ.i)(providerConfig)) return;
    return {
      apiKey: _discoverySharedROvQIBGQ.t,
      source: `models.providers.${provider ?? "ollama"} (synthetic local key)`,
      mode: "api-key"
    };
  },
  catalog: {
    order: "late",
    run: runOllamaDiscovery
  }
};
//#endregion /* v9-d48c1cd225f4b94d */
