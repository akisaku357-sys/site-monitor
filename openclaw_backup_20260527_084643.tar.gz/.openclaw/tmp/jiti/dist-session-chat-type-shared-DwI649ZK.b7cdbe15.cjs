"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.t = deriveSessionChatTypeFromKey;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _sessionKeyUtilsCe_xWkNq = require("./session-key-utils-Ce_xWkNq.js");
//#region src/sessions/session-chat-type-shared.ts
function deriveBuiltInLegacySessionChatType(scopedSessionKey) {
  if (/^group:[^:]+$/.test(scopedSessionKey)) return "group";
  if (/^(?:whatsapp:)?[^:]+@g\.us$/.test(scopedSessionKey)) return "group";
  if (/^discord:(?:[^:]+:)?guild-[^:]+:channel-[^:]+$/.test(scopedSessionKey)) return "channel";
}
function deriveSessionChatTypeFromScopedKey(scopedSessionKey, deriveLegacySessionChatTypes = []) {
  const tokens = new Set(scopedSessionKey.split(":").filter(Boolean));
  if (tokens.has("group")) return "group";
  if (tokens.has("channel")) return "channel";
  if (tokens.has("direct") || tokens.has("dm")) return "direct";
  const builtInLegacy = deriveBuiltInLegacySessionChatType(scopedSessionKey);
  if (builtInLegacy) return builtInLegacy;
  for (const deriveLegacySessionChatType of deriveLegacySessionChatTypes) {
    const derived = deriveLegacySessionChatType(scopedSessionKey);
    if (derived) return derived;
  }
  return "unknown";
}
/**
* Best-effort chat-type extraction from session keys across canonical and legacy formats.
*/
function deriveSessionChatTypeFromKey(sessionKey, deriveLegacySessionChatTypes = []) {
  const raw = (0, _stringCoerceDyL154ka.a)(sessionKey);
  if (!raw) return "unknown";
  return deriveSessionChatTypeFromScopedKey((0, _sessionKeyUtilsCe_xWkNq.c)(raw)?.rest ?? raw, deriveLegacySessionChatTypes);
}
//#endregion /* v9-4e7e06e6b17c8631 */
