"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.i = isSameToolMutationAction;exports.n = isLikelyMutatingToolName;exports.r = isMutatingToolCall;exports.t = buildToolMutationState;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _recordCoerceAMlBWINm = require("./record-coerce-aMlBWINm.js");
//#region src/agents/tool-mutation.ts
const MUTATING_TOOL_NAMES = new Set([
"write",
"edit",
"apply_patch",
"exec",
"bash",
"process",
"message",
"sessions_spawn",
"sessions_send",
"cron",
"gateway",
"canvas",
"nodes",
"session_status"]
);
const FILE_MUTATING_TOOL_NAMES = new Set(["edit", "write"]);
const FILE_TARGET_PATH_ARG_KEYS = [
"path",
"file_path",
"filePath",
"filepath",
"file"];

const FILE_TARGET_OLDPATH_ARG_KEYS = ["oldPath", "old_path"];
const READ_ONLY_ACTIONS = new Set([
"get",
"list",
"read",
"status",
"show",
"fetch",
"search",
"query",
"view",
"poll",
"log",
"inspect",
"check",
"probe"]
);
const PROCESS_MUTATING_ACTIONS = new Set([
"write",
"send_keys",
"submit",
"paste",
"kill"]
);
const MESSAGE_MUTATING_ACTIONS = new Set([
"send",
"reply",
"thread_reply",
"threadreply",
"edit",
"delete",
"react",
"pin",
"unpin"]
);
function normalizeActionName(value) {
  return (0, _stringCoerceDyL154ka.s)(value)?.replace(/[\s-]+/g, "_") || void 0;
}
function normalizeFingerprintValue(value) {
  if (typeof value === "string") {
    const normalized = value.trim();
    return normalized ? (0, _stringCoerceDyL154ka.a)(normalized) : void 0;
  }
  if (typeof value === "number" || typeof value === "bigint" || typeof value === "boolean") return (0, _stringCoerceDyL154ka.a)(String(value));
}
function appendFingerprintAlias(parts, record, label, keys) {
  for (const key of keys) {
    const value = normalizeFingerprintValue(record?.[key]);
    if (!value) continue;
    parts.push(`${label}=${value}`);
    return true;
  }
  return false;
}
function isLikelyMutatingToolName(toolName) {
  const normalized = (0, _stringCoerceDyL154ka.a)(toolName);
  if (!normalized) return false;
  return MUTATING_TOOL_NAMES.has(normalized) || normalized.endsWith("_actions") || normalized.startsWith("message_") || normalized.includes("send");
}
function isMutatingToolCall(toolName, args) {
  const normalized = (0, _stringCoerceDyL154ka.a)(toolName);
  const record = (0, _recordCoerceAMlBWINm.r)(args);
  const action = normalizeActionName(record?.action);
  switch (normalized) {
    case "write":
    case "edit":
    case "apply_patch":
    case "exec":
    case "bash":
    case "sessions_send":return true;
    case "process":return action != null && PROCESS_MUTATING_ACTIONS.has(action);
    case "message":return action != null && MESSAGE_MUTATING_ACTIONS.has(action) || typeof record?.content === "string" || typeof record?.message === "string";
    case "subagents":return action === "kill" || action === "steer";
    case "session_status":return typeof record?.model === "string" && record.model.trim().length > 0;
    default:
      if (normalized === "cron" || normalized === "gateway" || normalized === "canvas") return action == null || !READ_ONLY_ACTIONS.has(action);
      if (normalized === "nodes") return action == null || action !== "list";
      if (normalized.endsWith("_actions")) return action == null || !READ_ONLY_ACTIONS.has(action);
      if (normalized.startsWith("message_") || normalized.includes("send")) return true;
      return false;
  }
}
function buildToolActionFingerprint(toolName, args, meta) {
  if (!isMutatingToolCall(toolName, args)) return;
  const normalizedTool = (0, _stringCoerceDyL154ka.a)(toolName);
  const record = (0, _recordCoerceAMlBWINm.r)(args);
  const action = normalizeActionName(record?.action);
  const parts = [`tool=${normalizedTool}`];
  if (action) parts.push(`action=${action}`);
  let hasStableTarget = false;
  hasStableTarget = appendFingerprintAlias(parts, record, "path", [
  "path",
  "file_path",
  "filePath",
  "filepath",
  "file"]
  ) || hasStableTarget;
  hasStableTarget = appendFingerprintAlias(parts, record, "oldpath", ["oldPath", "old_path"]) || hasStableTarget;
  hasStableTarget = appendFingerprintAlias(parts, record, "newpath", ["newPath", "new_path"]) || hasStableTarget;
  hasStableTarget = appendFingerprintAlias(parts, record, "to", ["to", "target"]) || hasStableTarget;
  hasStableTarget = appendFingerprintAlias(parts, record, "messageid", ["messageId", "message_id"]) || hasStableTarget;
  hasStableTarget = appendFingerprintAlias(parts, record, "sessionkey", ["sessionKey", "session_key"]) || hasStableTarget;
  hasStableTarget = appendFingerprintAlias(parts, record, "jobid", ["jobId", "job_id"]) || hasStableTarget;
  hasStableTarget = appendFingerprintAlias(parts, record, "id", ["id"]) || hasStableTarget;
  hasStableTarget = appendFingerprintAlias(parts, record, "model", ["model"]) || hasStableTarget;
  const normalizedMeta = (0, _stringCoerceDyL154ka.s)(meta?.trim().replace(/\s+/g, " "));
  if (normalizedMeta && !hasStableTarget) parts.push(`meta=${normalizedMeta}`);
  return parts.join("|");
}
function isFileMutatingToolName(rawName) {
  return FILE_MUTATING_TOOL_NAMES.has((0, _stringCoerceDyL154ka.a)(rawName));
}
function readArgFingerprintValue(record, keys) {
  if (!record) return;
  for (const key of keys) {
    const normalized = normalizeFingerprintValue(record[key]);
    if (normalized) return normalized;
  }
}
function extractFileTarget(toolName, args) {
  if (!isFileMutatingToolName(toolName)) return;
  const record = (0, _recordCoerceAMlBWINm.r)(args);
  const path = readArgFingerprintValue(record, FILE_TARGET_PATH_ARG_KEYS);
  const oldpath = readArgFingerprintValue(record, FILE_TARGET_OLDPATH_ARG_KEYS);
  if (!path && !oldpath) return;
  return {
    ...(path !== void 0 ? { path } : {}),
    ...(oldpath !== void 0 ? { oldpath } : {})
  };
}
function fileTargetsEqual(a, b) {
  return (a.path ?? "") === (b.path ?? "") && (a.oldpath ?? "") === (b.oldpath ?? "");
}
function buildToolMutationState(toolName, args, meta) {
  const actionFingerprint = buildToolActionFingerprint(toolName, args, meta);
  const fileTarget = extractFileTarget(toolName, args);
  return {
    mutatingAction: actionFingerprint != null,
    actionFingerprint,
    ...(fileTarget !== void 0 ? { fileTarget } : {})
  };
}
function isSameToolMutationAction(existing, next) {
  if (existing.actionFingerprint != null || next.actionFingerprint != null) {
    if (existing.actionFingerprint == null || next.actionFingerprint == null) return false;
    if (existing.actionFingerprint === next.actionFingerprint) return true;
    if (isFileMutatingToolName(existing.toolName) && isFileMutatingToolName(next.toolName) && existing.fileTarget !== void 0 && next.fileTarget !== void 0 && fileTargetsEqual(existing.fileTarget, next.fileTarget)) return true;
    return false;
  }
  return existing.toolName === next.toolName && (existing.meta ?? "") === (next.meta ?? "");
}
//#endregion /* v9-2b7b0887becbcf5a */
