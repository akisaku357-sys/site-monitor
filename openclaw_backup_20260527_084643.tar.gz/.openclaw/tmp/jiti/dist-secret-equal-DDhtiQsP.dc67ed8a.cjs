"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.t = safeEqualSecret;var _nodeCrypto = require("node:crypto");
//#region src/security/secret-equal.ts
function padSecretBytes(bytes, length) {
  if (bytes.length === length) return bytes;
  const padded = Buffer.alloc(length);
  bytes.copy(padded);
  return padded;
}
function safeEqualSecret(provided, expected) {
  if (typeof provided !== "string" || typeof expected !== "string") return false;
  const providedBytes = Buffer.from(provided, "utf8");
  const expectedBytes = Buffer.from(expected, "utf8");
  const byteLength = Math.max(providedBytes.length, expectedBytes.length);
  if (byteLength === 0) return true;
  return (0, _nodeCrypto.timingSafeEqual)(padSecretBytes(providedBytes, byteLength), padSecretBytes(expectedBytes, byteLength)) && providedBytes.length === expectedBytes.length;
}
//#endregion /* v9-83426a95a286dc0e */
