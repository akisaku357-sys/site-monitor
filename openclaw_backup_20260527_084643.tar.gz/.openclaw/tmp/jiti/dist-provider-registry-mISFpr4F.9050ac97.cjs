"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.a = normalizeSpeechProviderId;exports.t = exports.r = exports.n = exports.i = void 0;var _activeRuntimeRegistryWEpAEHY = require("./active-runtime-registry-wEpAEHY2.js");
var _capabilityProviderRuntimeBwiWIvn = require("./capability-provider-runtime-BwiWIvn0.js");
var _providerRegistrySharedBvRrJpZ_ = require("./provider-registry-shared-BvRrJpZ_.js");
//#region src/tts/provider-registry-core.ts
function normalizeSpeechProviderId(providerId) {
  return (0, _providerRegistrySharedBvRrJpZ_.n)(providerId);
}
function createSpeechProviderRegistry(resolver) {
  const buildResolvedProviderMaps = (cfg) => (0, _providerRegistrySharedBvRrJpZ_.t)(resolver.listProviders(cfg));
  const listProviders = (cfg) => [...buildResolvedProviderMaps(cfg).canonical.values()];
  const getProvider = (providerId, cfg) => {
    const normalized = normalizeSpeechProviderId(providerId);
    if (!normalized) return;
    return resolver.getProvider(normalized, cfg) ?? buildResolvedProviderMaps(cfg).aliases.get(normalized);
  };
  const canonicalizeProviderId = (providerId, cfg) => {
    const normalized = normalizeSpeechProviderId(providerId);
    if (!normalized) return;
    return getProvider(normalized, cfg)?.id ?? normalized;
  };
  return {
    canonicalizeSpeechProviderId: canonicalizeProviderId,
    getSpeechProvider: getProvider,
    listSpeechProviders: listProviders
  };
}
//#endregion
//#region src/tts/provider-registry.ts
function resolveSpeechProviderPluginEntries(cfg) {
  return (0, _capabilityProviderRuntimeBwiWIvn.r)({
    key: "speechProviders",
    cfg
  });
}
function resolveLoadedSpeechProviderPluginEntries() {
  return ((0, _activeRuntimeRegistryWEpAEHY.t)()?.speechProviders ?? []).map((entry) => entry.provider);
}
const defaultSpeechProviderRegistry = createSpeechProviderRegistry({
  getProvider: (providerId, cfg) => (0, _capabilityProviderRuntimeBwiWIvn.n)({
    key: "speechProviders",
    providerId,
    cfg
  }),
  listProviders: resolveSpeechProviderPluginEntries
});
const loadedSpeechProviderRegistry = createSpeechProviderRegistry({
  getProvider: (providerId) => resolveLoadedSpeechProviderPluginEntries().find((provider) => {
    if (provider.id === providerId) return true;
    return provider.aliases?.includes(providerId) ?? false;
  }),
  listProviders: () => resolveLoadedSpeechProviderPluginEntries()
});
const listSpeechProviders = exports.i = defaultSpeechProviderRegistry.listSpeechProviders;
const listLoadedSpeechProviders = exports.r = loadedSpeechProviderRegistry.listSpeechProviders;
const getSpeechProvider = exports.n = defaultSpeechProviderRegistry.getSpeechProvider;
const canonicalizeSpeechProviderId = exports.t = defaultSpeechProviderRegistry.canonicalizeSpeechProviderId;
//#endregion /* v9-01f022adb0ffaa7b */
