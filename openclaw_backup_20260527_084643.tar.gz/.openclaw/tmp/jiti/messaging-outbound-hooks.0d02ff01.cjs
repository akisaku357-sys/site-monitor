"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.applyWeixinMessageSendingHook = applyWeixinMessageSendingHook;exports.emitWeixinMessageSent = emitWeixinMessageSent;var _hookRuntime = require("openclaw/plugin-sdk/hook-runtime");
var _pluginRuntime = require("openclaw/plugin-sdk/plugin-runtime");
var _logger = require("../util/logger.js");
const CHANNEL_ID = "openclaw-weixin";
/**
 * Run message_sending hook before sending.
 * Returns the (possibly modified) text content plus a cancelled flag.
 * Hook errors are caught and logged — sending proceeds regardless.
 */
async function applyWeixinMessageSendingHook(params) {
  const hookRunner = (0, _pluginRuntime.getGlobalHookRunner)();
  if (!hookRunner?.hasHooks("message_sending")) {
    return { cancelled: false, text: params.text };
  }
  try {
    const hookResult = await hookRunner.runMessageSending({
      to: params.to,
      content: params.text,
      metadata: {
        channel: CHANNEL_ID,
        accountId: params.accountId,
        ...(params.mediaUrl ? { mediaUrls: [params.mediaUrl] } : {})
      }
    }, { channelId: CHANNEL_ID, accountId: params.accountId });
    if (hookResult?.cancel) {
      return { cancelled: true, text: params.text };
    }
    return {
      cancelled: false,
      text: hookResult?.content ?? params.text
    };
  }
  catch (err) {
    _logger.logger.warn(`message_sending hook error, proceeding with send: ${String(err)}`);
    return { cancelled: false, text: params.text };
  }
}
/**
 * Fire message_sent hook (fire-and-forget) after a send attempt.
 */
function emitWeixinMessageSent(params) {
  const hookRunner = (0, _pluginRuntime.getGlobalHookRunner)();
  if (!hookRunner?.hasHooks("message_sent"))
  return;
  const canonical = (0, _hookRuntime.buildCanonicalSentMessageHookContext)({
    to: params.to,
    content: params.content,
    success: params.success,
    error: params.error,
    channelId: CHANNEL_ID,
    accountId: params.accountId,
    conversationId: params.to
  });
  (0, _hookRuntime.fireAndForgetHook)(Promise.resolve(hookRunner.runMessageSent((0, _hookRuntime.toPluginMessageSentEvent)(canonical), (0, _hookRuntime.toPluginMessageContext)(canonical))), "weixin: message_sent plugin hook failed");
} /* v9-ca36120121a59f98 */
