"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.a = markDiagnosticActivity;exports.i = logLaneEnqueue;exports.n = getLastDiagnosticActivityAt;exports.o = resetDiagnosticActivityForTest;exports.r = logLaneDequeue;exports.t = void 0;var _diagnosticEventsBLgzARSp = require("./diagnostic-events-BLgzARSp.js");
var _subsystemDSPWLoK = require("./subsystem-DSPWLoK5.js");
//#region src/logging/diagnostic-runtime.ts
const diag = (0, _subsystemDSPWLoK.t)("diagnostic");
let lastActivityAt = 0;
const diagnosticLogger = exports.t = diag;
function markDiagnosticActivity() {
  lastActivityAt = Date.now();
}
function getLastDiagnosticActivityAt() {
  return lastActivityAt;
}
function resetDiagnosticActivityForTest() {
  lastActivityAt = 0;
}
function logLaneEnqueue(lane, queueSize) {
  if (!(0, _diagnosticEventsBLgzARSp.t)()) return;
  diag.debug(`lane enqueue: lane=${lane} queueSize=${queueSize}`);
  (0, _diagnosticEventsBLgzARSp.n)({
    type: "queue.lane.enqueue",
    lane,
    queueSize
  });
  markDiagnosticActivity();
}
function logLaneDequeue(lane, waitMs, queueSize) {
  if (!(0, _diagnosticEventsBLgzARSp.t)()) return;
  diag.debug(`lane dequeue: lane=${lane} waitMs=${waitMs} queueSize=${queueSize}`);
  (0, _diagnosticEventsBLgzARSp.n)({
    type: "queue.lane.dequeue",
    lane,
    queueSize,
    waitMs
  });
  markDiagnosticActivity();
}
//#endregion /* v9-c0054afe9f3c80d1 */
