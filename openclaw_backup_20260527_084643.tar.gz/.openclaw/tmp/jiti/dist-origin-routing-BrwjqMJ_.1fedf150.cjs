"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = resolveOriginMessageProvider;exports.r = resolveOriginMessageTo;exports.t = resolveOriginAccountId;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
//#region src/auto-reply/reply/origin-routing.ts
function resolveOriginMessageProvider(params) {
  return (0, _stringCoerceDyL154ka.s)(params.originatingChannel) ?? (0, _stringCoerceDyL154ka.s)(params.provider);
}
function resolveOriginMessageTo(params) {
  return params.originatingTo ?? params.to;
}
function resolveOriginAccountId(params) {
  return params.originatingAccountId ?? params.accountId;
}
//#endregion /* v9-6910b999d4feafd9 */
