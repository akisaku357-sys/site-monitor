"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.a = void 0;exports.i = stripFormattedReasoningMessage;exports.n = runMessageAction;exports.o = void 0;exports.r = resolveAllowedMessageActions;exports.s = dispatchChannelMessageAction;exports.t = getToolResult;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _errorsB3ZrCRlt = require("./errors-b3ZrCRlt.js");
var _fsSafeCV86zY9G = require("./fs-safe-CV86zY9G.js");
var _secureTempDirAidxCRgA = require("./secure-temp-dir-aidxCRgA.js");
var _agentScopeCtLXGcWm = require("./agent-scope-CtLXGcWm.js");
var _clientInfoBVWE_ra = require("./client-info-BVWE_ra1.js");
var _messageChannelCoreBoUoCGOD = require("./message-channel-core-BoUoCGOD.js");
var _messageChannelCYCKkVrh = require("./message-channel-CYCKkVrh.js");
var _channelTargetNug_hTy = require("./channel-target-Nug_hTy8.js");
var _sandboxPathsBTYunIeX = require("./sandbox-paths-BTYunIeX.js");
require("./local-file-access-CBe_wA_B.js");
var _pathsBg3PO6Gj = require("./paths-Bg3PO6Gj.js");
var _storeLoadZ4thf6ld = require("./store-load-z4thf6ld.js");
var _registryBf5TpUad = require("./registry-Bf5TpUad.js");
var _chatTypeD_QPUzR = require("./chat-type-D_QPUzR1.js");
require("./plugins-DYTHbmt7.js");
require("./sessions-CQHHcgC_.js");
var _mimeDppuTPZ = require("./mime-DppuT-pZ.js");
var _transcriptBA0NgdA = require("./transcript-BA0Ngd-A.js");
var _assistantVisibleTextBoF6Ixue = require("./assistant-visible-text-BoF6Ixue.js");
var _toolPayloadGp3uQTKH = require("./tool-payload-Gp3uQTKH.js");
var _replyPayloadDMPQsrQC = require("./reply-payload-DMPQsrQC.js");
var _payloadBDV15CYA = require("./payload-BDV15CYA.js");
var _fileNameR4prf02z = require("./file-name-r4prf02z.js");
var _messageActionDiscoveryC_vRmQ0H = require("./message-action-discovery-C_vRmQ0H.js");
var _commonE9YpX7pB = require("./common-E9YpX7pB.js");
var _targetIdResolutionDVSHqxJ = require("./target-id-resolution-DVSHqxJ3.js");
var _payloadsBOM5t2O = require("./payloads-BOM5t2O4.js");
var _configuredMaxBytesCNKFB65A = require("./configured-max-bytes-CNKFB65A.js");
var _localRootsPi6a9oaK = require("./local-roots-Pi6a9oaK.js");
var _webMediaGlH39bZn = require("./web-media-GlH39bZn.js");
var _ttsConfigWOpwhkHq = require("./tts-config-WOpwhkHq.js");
var _deliverWPtVqUMT = require("./deliver-WPtVqUMT.js");
var _readCapabilityCUZ0OarG = require("./read-capability-CUZ0OarG.js");
var _channelResolutionEcs0HEdK = require("./channel-resolution-Ecs0HEdK.js");
var _pollsCV11_tu = require("./polls-C-v11_tu.js");
var _channelSelectionDQG3SYlu = require("./channel-selection-DQG3SYlu.js");
var _messageCZZW9OgM = require("./message-CZZW9OgM.js");
var _boundAccountReadQnHEyAzX = require("./bound-account-read-qnHEyAzX.js");
var _loadOptionsLnfEFXDj = require("./load-options-LnfEFXDj.js");
var _booleanParamCh5dc2FQ = require("./boolean-param-Ch5dc2FQ.js");
var _targetResolver8NiS43Zp = require("./target-resolver-8NiS43Zp.js");
var _outboundSessionDKXWYF4a = require("./outbound-session-DKXWYF4a.js");function _interopRequireWildcard(e, t) {if ("function" == typeof WeakMap) var r = new WeakMap(),n = new WeakMap();return (_interopRequireWildcard = function (e, t) {if (!t && e && e.__esModule) return e;var o,i,f = { __proto__: null, default: e };if (null === e || "object" != typeof e && "function" != typeof e) return f;if (o = t ? n : r) {if (o.has(e)) return o.get(e);o.set(e, f);}for (const t in e) "default" !== t && {}.hasOwnProperty.call(e, t) && ((i = (o = Object.defineProperty) && Object.getOwnPropertyDescriptor(e, t)) && (i.get || i.set) ? o(f, t, i) : f[t] = e[t]);return f;})(e, t);}
//#region src/channels/plugins/message-action-dispatch.ts
function requiresTrustedRequesterSender(ctx) {
  const plugin = (0, _registryBf5TpUad.t)(ctx.channel);
  return Boolean(plugin?.actions?.requiresTrustedRequesterSender?.({
    action: ctx.action,
    toolContext: ctx.toolContext
  }));
}
async function dispatchChannelMessageAction(ctx) {
  if (requiresTrustedRequesterSender(ctx) && !ctx.requesterSenderId?.trim()) throw new Error(`Trusted sender identity is required for ${ctx.channel}:${ctx.action} in tool-driven contexts.`);
  const plugin = (0, _registryBf5TpUad.t)(ctx.channel);
  if (!plugin?.actions?.handleAction) return null;
  if (plugin.actions.supportsAction && !plugin.actions.supportsAction({ action: ctx.action })) return null;
  return await plugin.actions.handleAction(ctx);
}
//#endregion
//#region src/poll-params.ts
const SHARED_POLL_CREATION_PARAM_DEFS = {
  pollQuestion: { kind: "string" },
  pollOption: { kind: "stringArray" },
  pollDurationHours: { kind: "number" },
  pollMulti: { kind: "boolean" }
};
const POLL_CREATION_PARAM_DEFS = exports.a = SHARED_POLL_CREATION_PARAM_DEFS;
const SHARED_POLL_CREATION_PARAM_NAMES = exports.o = Object.keys(SHARED_POLL_CREATION_PARAM_DEFS);
const SHARED_POLL_CREATION_PARAM_KEY_SET = new Set(SHARED_POLL_CREATION_PARAM_NAMES.map(normalizePollParamKey));
const POLL_VOTE_PARAM_KEY_SET = new Set([
"pollId",
"pollOptionId",
"pollOptionIds",
"pollOptionIndex",
"pollOptionIndexes"].
map(normalizePollParamKey));
function readPollParamRaw(params, key) {
  return (0, _commonE9YpX7pB.y)(params, key);
}
function normalizePollParamKey(key) {
  return (0, _stringCoerceDyL154ka.a)(key.replaceAll("_", ""));
}
function isChannelPollCreationParamName(key) {
  const normalized = normalizePollParamKey(key);
  return normalized.startsWith("poll") && !SHARED_POLL_CREATION_PARAM_KEY_SET.has(normalized) && !POLL_VOTE_PARAM_KEY_SET.has(normalized);
}
function hasExplicitUnknownPollValue(key, value) {
  if (value === true) return true;
  if (typeof value === "number") return Number.isFinite(value) && value !== 0;
  if (typeof value === "string") {
    const trimmed = value.trim();
    if (trimmed.length === 0) return false;
    if (normalizePollParamKey(key).includes("duration")) {
      const parsed = Number(trimmed);
      return Number.isFinite(parsed) && parsed !== 0;
    }
    const normalized = (0, _stringCoerceDyL154ka.a)(trimmed);
    return normalized !== "false" && normalized !== "0";
  }
  if (Array.isArray(value)) return value.some((entry) => hasExplicitUnknownPollValue(key, entry));
  return false;
}
function hasPollCreationParams(params) {
  for (const key of SHARED_POLL_CREATION_PARAM_NAMES) {
    const def = POLL_CREATION_PARAM_DEFS[key];
    const value = readPollParamRaw(params, key);
    if (def.kind === "string" && typeof value === "string" && value.trim().length > 0) return true;
    if (def.kind === "stringArray") {
      if (Array.isArray(value) && value.some((entry) => typeof entry === "string" && entry.trim())) return true;
      if (typeof value === "string" && value.trim().length > 0) return true;
    }
    if (def.kind === "number") {
      if (typeof value === "number" && Number.isFinite(value) && value !== 0) return true;
      if (typeof value === "string") {
        const trimmed = value.trim();
        const parsed = Number(trimmed);
        if (trimmed.length > 0 && Number.isFinite(parsed) && parsed !== 0) return true;
      }
    }
    if (def.kind === "boolean") {
      if (value === true) return true;
      if (typeof value === "string" && (0, _stringCoerceDyL154ka.a)(value) === "true") return true;
    }
  }
  for (const [key, value] of Object.entries(params)) if (isChannelPollCreationParamName(key) && hasExplicitUnknownPollValue(key, value)) return true;
  return false;
}
//#endregion
//#region src/shared/text/formatted-reasoning-message.ts
function stripFormattedReasoningMessage(text) {
  const stripped = (0, _assistantVisibleTextBoF6Ixue.u)(text);
  const lines = stripped.split(/\r?\n/u);
  const prefix = lines[0]?.trim();
  if (prefix !== "Reasoning:" && !/^Thinking\.{0,3}$/u.test(prefix ?? "")) return stripped;
  if (/^Thinking\.{0,3}$/u.test(prefix ?? "")) {
    const trimmedBodyLine = lines.slice(1).find((line) => line.trim())?.trim() ?? "";
    if (!trimmedBodyLine || !(trimmedBodyLine.startsWith("_") && trimmedBodyLine.endsWith("_") && trimmedBodyLine.length >= 2)) return stripped;
  }
  let index = 1;
  while (index < lines.length) {
    const trimmed = lines[index]?.trim() ?? "";
    if (!trimmed || trimmed.startsWith("_") && trimmed.endsWith("_") && trimmed.length >= 2) {
      index += 1;
      continue;
    }
    break;
  }
  return lines.slice(index).join("\n").trim();
}
//#endregion
//#region src/infra/outbound/message-action-normalization.ts
function normalizeMessageActionInput(params) {
  const normalizedArgs = { ...params.args };
  const { action, toolContext } = params;
  const explicitChannel = (0, _stringCoerceDyL154ka.c)(normalizedArgs.channel) ?? "";
  const inferredChannel = explicitChannel || (0, _messageChannelCYCKkVrh.u)(toolContext?.currentChannelProvider) || "";
  const explicitTarget = (0, _stringCoerceDyL154ka.c)(normalizedArgs.target) ?? "";
  const hasLegacyTargetFields = typeof normalizedArgs.to === "string" || typeof normalizedArgs.channelId === "string";
  const hasLegacyTarget = ((0, _stringCoerceDyL154ka.c)(normalizedArgs.to) ?? "").length > 0 || ((0, _stringCoerceDyL154ka.c)(normalizedArgs.channelId) ?? "").length > 0;
  if (explicitTarget && hasLegacyTargetFields) {
    delete normalizedArgs.to;
    delete normalizedArgs.channelId;
  }
  if (!explicitTarget && !hasLegacyTarget && (0, _channelTargetNug_hTy.o)(action) && !(0, _channelTargetNug_hTy.a)(action, normalizedArgs, { channel: inferredChannel })) {
    const inferredTarget = (0, _stringCoerceDyL154ka.c)(toolContext?.currentChannelId);
    if (inferredTarget) normalizedArgs.target = inferredTarget;
  }
  if (!explicitTarget && (0, _channelTargetNug_hTy.o)(action) && hasLegacyTarget) {
    const legacyTo = (0, _stringCoerceDyL154ka.c)(normalizedArgs.to) ?? "";
    const legacyChannelId = (0, _stringCoerceDyL154ka.c)(normalizedArgs.channelId) ?? "";
    const legacyTarget = legacyTo || legacyChannelId;
    if (legacyTarget) {
      normalizedArgs.target = legacyTarget;
      delete normalizedArgs.to;
      delete normalizedArgs.channelId;
    }
  }
  if (!explicitChannel) {
    if (inferredChannel && (0, _messageChannelCYCKkVrh.s)(inferredChannel)) normalizedArgs.channel = inferredChannel;
  }
  (0, _channelTargetNug_hTy.r)({
    action,
    args: normalizedArgs
  });
  if ((0, _channelTargetNug_hTy.o)(action) && !(0, _channelTargetNug_hTy.a)(action, normalizedArgs, { channel: inferredChannel })) throw new Error(`Action ${action} requires a target.`);
  return normalizedArgs;
}
//#endregion
//#region src/infra/outbound/message-action-params.ts
const readBooleanParam = _booleanParamCh5dc2FQ.t;
const BASE_ACTION_MEDIA_SOURCE_PARAM_KEYS = [
"media",
"path",
"filePath",
"mediaUrl",
"fileUrl",
"image"];

function readMediaParam(args, key) {
  return (0, _commonE9YpX7pB.g)(args, key, { trim: false });
}
function resolveMediaParamEntry(args, key) {
  const resolvedKey = (0, _commonE9YpX7pB.b)(args, key);
  if (!resolvedKey) return;
  const value = readMediaParam(args, key);
  if (!value) return;
  return {
    key: resolvedKey,
    value
  };
}
function buildActionMediaSourceParamKeys(extraParamKeys) {
  const keys = new Set(BASE_ACTION_MEDIA_SOURCE_PARAM_KEYS);
  extraParamKeys?.forEach((key) => keys.add(key));
  return Array.from(keys);
}
function resolveExtraActionMediaSourceParamKeys(params) {
  if (!(0, _channelTargetNug_hTy.s)(params.args)) return [];
  return (0, _messageActionDiscoveryC_vRmQ0H.a)({
    cfg: params.cfg,
    action: params.action,
    channel: params.channel,
    accountId: params.accountId,
    sessionKey: params.sessionKey,
    sessionId: params.sessionId,
    agentId: params.agentId,
    requesterSenderId: params.requesterSenderId,
    senderIsOwner: params.senderIsOwner
  });
}
function collectActionMediaSourceHints(args, extraParamKeys) {
  const sources = [];
  for (const key of buildActionMediaSourceParamKeys(extraParamKeys)) {
    const entry = resolveMediaParamEntry(args, key);
    if (entry && (0, _stringCoerceDyL154ka.c)(entry.value)) sources.push(entry.value);
  }
  return sources;
}
function readAttachmentMediaHint(args) {
  return readMediaParam(args, "media") ?? readMediaParam(args, "mediaUrl");
}
function readAttachmentFileHint(args) {
  return readMediaParam(args, "path") ?? readMediaParam(args, "filePath") ?? readMediaParam(args, "fileUrl");
}
function resolveAttachmentMaxBytes(params) {
  const limitMb = (0, _configuredMaxBytesCNKFB65A.t)(params) ?? params.cfg.agents?.defaults?.mediaMaxMb;
  return typeof limitMb === "number" ? limitMb * 1024 * 1024 : void 0;
}
function inferAttachmentFilename(params) {
  const mediaHint = params.mediaHint?.trim();
  if (mediaHint) {
    const base = (0, _fsSafeCV86zY9G.x)(mediaHint);
    const safeBase = base ? (0, _fileNameR4prf02z.t)(base) : void 0;
    if (safeBase) return safeBase;
  }
  const ext = params.contentType ? (0, _mimeDppuTPZ.r)(params.contentType) : void 0;
  return ext ? `attachment${ext}` : "attachment";
}
function normalizeBase64Payload(params) {
  if (!params.base64) return {
    base64: params.base64,
    contentType: params.contentType
  };
  const match = /^data:([^;]+);base64,(.*)$/i.exec(params.base64.trim());
  if (!match) return {
    base64: params.base64,
    contentType: params.contentType
  };
  const [, mime, payload] = match;
  return {
    base64: payload,
    contentType: params.contentType ?? mime
  };
}
function resolveAttachmentMediaPolicy(params) {
  const sandboxRoot = params.sandboxRoot?.trim();
  if (sandboxRoot) return {
    mode: "sandbox",
    sandboxRoot
  };
  const explicitLocalRoots = (0, _loadOptionsLnfEFXDj.r)(params.mediaLocalRoots);
  return {
    mode: "host",
    mediaAccess: (0, _loadOptionsLnfEFXDj.n)({
      mediaAccess: params.mediaAccess,
      mediaLocalRoots: explicitLocalRoots === "any" ? void 0 : explicitLocalRoots,
      mediaReadFile: params.mediaAccess?.readFile ? void 0 : params.mediaReadFile
    }),
    ...(explicitLocalRoots !== void 0 ? { mediaLocalRoots: explicitLocalRoots } : {}),
    ...(params.mediaAccess?.readFile ? {} : params.mediaReadFile ? { mediaReadFile: params.mediaReadFile } : {})
  };
}
function buildAttachmentMediaLoadOptions(params) {
  if (params.policy.mode === "sandbox") {
    const sandboxRoot = params.policy.sandboxRoot.trim();
    let sandboxFsPromise;
    const readSandboxFile = async (filePath) => {
      sandboxFsPromise ??= (0, _secureTempDirAidxCRgA.o)(sandboxRoot);
      return await (await sandboxFsPromise).readBytes(filePath);
    };
    return {
      maxBytes: params.maxBytes,
      ...(params.optimizeImages !== void 0 ? { optimizeImages: params.optimizeImages } : {}),
      sandboxValidated: true,
      readFile: readSandboxFile
    };
  }
  return (0, _loadOptionsLnfEFXDj.t)({
    maxBytes: params.maxBytes,
    mediaAccess: params.policy.mediaAccess,
    mediaLocalRoots: params.policy.mediaLocalRoots,
    mediaReadFile: params.policy.mediaReadFile,
    optimizeImages: params.optimizeImages
  });
}
async function hydrateAttachmentPayload(params) {
  const contentTypeParam = params.contentTypeParam ?? void 0;
  const rawBuffer = (0, _commonE9YpX7pB.g)(params.args, "buffer", { trim: false });
  const normalized = normalizeBase64Payload({
    base64: rawBuffer,
    contentType: contentTypeParam ?? void 0
  });
  if (normalized.base64 !== rawBuffer && normalized.base64) {
    params.args.buffer = normalized.base64;
    if (normalized.contentType && !contentTypeParam) params.args.contentType = normalized.contentType;
  }
  const filename = (0, _commonE9YpX7pB.g)(params.args, "filename");
  const mediaSource = (params.mediaHint ?? void 0) || (params.fileHint ?? void 0);
  if (!params.dryRun && !(0, _commonE9YpX7pB.g)(params.args, "buffer", { trim: false }) && mediaSource) {
    const maxBytes = resolveAttachmentMaxBytes({
      cfg: params.cfg,
      channel: params.channel,
      accountId: params.accountId
    });
    const media = await (0, _webMediaGlH39bZn.t)(mediaSource, buildAttachmentMediaLoadOptions({
      policy: params.mediaPolicy,
      maxBytes,
      optimizeImages: params.optimizeImages
    }));
    params.args.buffer = media.buffer.toString("base64");
    if (!contentTypeParam && media.contentType) params.args.contentType = media.contentType;
    if (!filename) params.args.filename = inferAttachmentFilename({
      mediaHint: media.fileName ?? mediaSource,
      contentType: media.contentType ?? contentTypeParam ?? void 0
    });
  } else if (!filename) params.args.filename = inferAttachmentFilename({
    mediaHint: mediaSource,
    contentType: contentTypeParam ?? void 0
  });
}
async function normalizeSandboxMediaParams(params) {
  const sandboxRoot = params.mediaPolicy.mode === "sandbox" ? params.mediaPolicy.sandboxRoot.trim() : void 0;
  for (const key of buildActionMediaSourceParamKeys(params.extraParamKeys)) {
    const entry = resolveMediaParamEntry(params.args, key);
    if (!entry) continue;
    (0, _sandboxPathsBTYunIeX.t)(entry.value);
    if (!sandboxRoot) continue;
    const normalized = await (0, _sandboxPathsBTYunIeX.o)({
      media: entry.value,
      sandboxRoot
    });
    if (normalized !== entry.value) params.args[entry.key] = normalized;
  }
}
async function normalizeSandboxMediaList(params) {
  const sandboxRoot = params.sandboxRoot?.trim();
  const normalized = [];
  const seen = /* @__PURE__ */new Set();
  for (const value of params.values) {
    const raw = value?.trim();
    if (!raw) continue;
    (0, _sandboxPathsBTYunIeX.t)(raw);
    const resolved = sandboxRoot ? await (0, _sandboxPathsBTYunIeX.o)({
      media: raw,
      sandboxRoot
    }) : raw;
    if (seen.has(resolved)) continue;
    seen.add(resolved);
    normalized.push(resolved);
  }
  return normalized;
}
async function hydrateAttachmentActionPayload(params) {
  const mediaHint = readAttachmentMediaHint(params.args);
  const fileHint = readAttachmentFileHint(params.args);
  const contentTypeParam = (0, _commonE9YpX7pB.g)(params.args, "contentType") ?? (0, _commonE9YpX7pB.g)(params.args, "mimeType");
  if (params.allowMessageCaptionFallback) {
    const caption = (0, _commonE9YpX7pB.g)(params.args, "caption", { allowEmpty: true })?.trim();
    const message = (0, _commonE9YpX7pB.g)(params.args, "message", { allowEmpty: true })?.trim();
    if (!caption && message) params.args.caption = message;
  }
  await hydrateAttachmentPayload({
    cfg: params.cfg,
    channel: params.channel,
    accountId: params.accountId,
    args: params.args,
    dryRun: params.dryRun,
    contentTypeParam,
    mediaHint,
    fileHint,
    mediaPolicy: params.mediaPolicy,
    optimizeImages: params.optimizeImages
  });
}
async function hydrateAttachmentParamsForAction(params) {
  const shouldHydrateUploadFile = params.action === "upload-file";
  if (params.action !== "sendAttachment" && params.action !== "setGroupIcon" && params.action !== "reply" && !shouldHydrateUploadFile) return;
  const forceDocument = (0, _booleanParamCh5dc2FQ.t)(params.args, "forceDocument") ?? (0, _booleanParamCh5dc2FQ.t)(params.args, "asDocument") ?? false;
  await hydrateAttachmentActionPayload({
    cfg: params.cfg,
    channel: params.channel,
    accountId: params.accountId,
    args: params.args,
    dryRun: params.dryRun,
    mediaPolicy: params.mediaPolicy,
    optimizeImages: shouldHydrateUploadFile && forceDocument ? false : void 0,
    allowMessageCaptionFallback: params.action === "sendAttachment" || shouldHydrateUploadFile
  });
}
function parseJsonMessageParam(params, key) {
  const raw = params[key];
  if (typeof raw !== "string") return;
  const trimmed = raw.trim();
  if (!trimmed) {
    delete params[key];
    return;
  }
  try {
    params[key] = JSON.parse(trimmed);
  } catch {
    throw new Error(`--${key} must be valid JSON`);
  }
}
function parseInteractiveParam(params) {
  const raw = params.interactive;
  if (typeof raw !== "string") return;
  const trimmed = raw.trim();
  if (!trimmed) {
    delete params.interactive;
    return;
  }
  try {
    params.interactive = JSON.parse(trimmed);
  } catch {
    throw new Error("--interactive must be valid JSON");
  }
}
//#endregion
//#region src/infra/outbound/message-action-threading.ts
function suppressesImplicitThreading(actionParams) {
  return actionParams.topLevel === true || actionParams.threadId === null;
}
function resolveAndApplyOutboundThreadId(actionParams, context) {
  const threadId = (0, _commonE9YpX7pB.g)(actionParams, "threadId");
  if (!threadId && suppressesImplicitThreading(actionParams)) return;
  const resolved = threadId ?? context.resolveAutoThreadId?.({
    cfg: context.cfg,
    accountId: context.accountId,
    to: context.to,
    toolContext: context.toolContext,
    replyToId: (0, _commonE9YpX7pB.g)(actionParams, "replyTo")
  });
  if (resolved && !actionParams.threadId) actionParams.threadId = resolved;
  return resolved ?? void 0;
}
function isSameConversationTarget(actionParams, channel, toolContext) {
  const currentChannelId = toolContext?.currentChannelId?.trim();
  if (!currentChannelId) return false;
  const currentChannelProvider = toolContext?.currentChannelProvider?.trim();
  if (currentChannelProvider && currentChannelProvider !== channel) return false;
  const explicitTarget = (0, _commonE9YpX7pB.g)(actionParams, "target") ?? (0, _commonE9YpX7pB.g)(actionParams, "to") ?? (0, _commonE9YpX7pB.g)(actionParams, "channelId");
  if (!explicitTarget) return true;
  return explicitTarget.trim() === currentChannelId;
}
function resolveAndApplyOutboundReplyToId(actionParams, context) {
  const explicitReplyToId = (0, _commonE9YpX7pB.g)(actionParams, "replyTo");
  if (explicitReplyToId) {
    if (context.toolContext?.replyToMode === "first") {
      const hasRepliedRef = context.toolContext.hasRepliedRef;
      if (hasRepliedRef) hasRepliedRef.value = true;
    }
    return explicitReplyToId;
  }
  if (suppressesImplicitThreading(actionParams)) return;
  if (!isSameConversationTarget(actionParams, context.channel, context.toolContext)) return;
  const currentMessageId = context.toolContext?.currentMessageId;
  if (currentMessageId == null) return;
  const mode = context.toolContext?.replyToMode ?? "off";
  if (mode === "off" || mode === "batched") return;
  if (mode === "first") {
    const hasRepliedRef = context.toolContext?.hasRepliedRef;
    if (hasRepliedRef?.value) return;
    if (hasRepliedRef) hasRepliedRef.value = true;
  }
  const resolvedReplyToId = typeof currentMessageId === "number" ? String(currentMessageId) : currentMessageId.trim();
  if (!resolvedReplyToId) return;
  actionParams.replyTo = resolvedReplyToId;
  return resolvedReplyToId;
}
async function prepareOutboundMirrorRoute(params) {
  const replyToId = (0, _commonE9YpX7pB.g)(params.actionParams, "replyTo");
  const resolvedThreadId = resolveAndApplyOutboundThreadId(params.actionParams, {
    cfg: params.cfg,
    to: params.to,
    accountId: params.accountId,
    toolContext: params.toolContext,
    resolveAutoThreadId: params.resolveAutoThreadId
  });
  const outboundRoute = params.agentId && !params.dryRun ? await params.resolveOutboundSessionRoute({
    cfg: params.cfg,
    channel: params.channel,
    agentId: params.agentId,
    accountId: params.accountId,
    target: params.to,
    currentSessionKey: params.currentSessionKey,
    resolvedTarget: params.resolvedTarget,
    replyToId,
    threadId: resolvedThreadId
  }) : null;
  if (outboundRoute && params.agentId && !params.dryRun) await params.ensureOutboundSessionEntry({
    cfg: params.cfg,
    channel: params.channel,
    accountId: params.accountId,
    route: outboundRoute
  });
  if (outboundRoute && !params.dryRun) params.actionParams["__sessionKey"] = outboundRoute.sessionKey;
  if (params.agentId) params.actionParams["__agentId"] = params.agentId;
  return {
    resolvedThreadId,
    outboundRoute
  };
}
//#endregion
//#region src/infra/outbound/message-action-tts.ts
let ttsRuntimePromise = null;
function loadMessageActionTtsRuntime() {
  ttsRuntimePromise ??= Promise.resolve().then(() => jitiImport("./tts.runtime-hD3depa3.js").then((m) => _interopRequireWildcard(m)));
  return ttsRuntimePromise;
}
function resolveMessageActionSessionTtsAuto(params) {
  const sessionKey = params.sessionKey?.trim();
  if (!sessionKey) return;
  try {
    return (0, _storeLoadZ4thf6ld.F)({
      store: (0, _storeLoadZ4thf6ld.t)((0, _pathsBg3PO6Gj.u)(params.cfg.session?.store, { agentId: params.agentId })),
      sessionKey
    }).existing?.ttsAuto;
  } catch {
    return;
  }
}
async function maybeApplyTtsToMessageActionSendPayload(params) {
  if (params.dryRun) return params.payload;
  const ttsAuto = resolveMessageActionSessionTtsAuto({
    cfg: params.cfg,
    sessionKey: params.sessionKey,
    agentId: params.agentId
  });
  if (!(0, _ttsConfigWOpwhkHq.r)({
    cfg: params.cfg,
    ttsAuto,
    agentId: params.agentId,
    channelId: params.channel,
    accountId: params.accountId ?? void 0
  })) return params.payload;
  const { maybeApplyTtsToPayload } = await loadMessageActionTtsRuntime();
  return await maybeApplyTtsToPayload({
    payload: params.payload,
    cfg: params.cfg,
    channel: params.channel,
    kind: "final",
    inboundAudio: params.inboundAudio,
    ttsAuto,
    agentId: params.agentId,
    accountId: params.accountId ?? void 0
  });
}
//#endregion
//#region src/infra/outbound/outbound-policy.ts
const CONTEXT_GUARDED_ACTIONS = new Set([
"send",
"poll",
"reply",
"sendWithEffect",
"sendAttachment",
"upload-file",
"thread-create",
"thread-reply",
"sticker"]
);
const CONTEXT_MARKER_ACTIONS = new Set([
"send",
"poll",
"reply",
"sendWithEffect",
"sendAttachment",
"upload-file",
"thread-reply",
"sticker"]
);
function resolveContextGuardTarget(action, params) {
  if (!CONTEXT_GUARDED_ACTIONS.has(action)) return;
  if (action === "thread-reply" || action === "thread-create") {
    if (typeof params.channelId === "string") return params.channelId;
    if (typeof params.to === "string") return params.to;
    return;
  }
  if (typeof params.to === "string") return params.to;
  if (typeof params.channelId === "string") return params.channelId;
}
function normalizeTarget(channel, raw) {
  return (0, _targetIdResolutionDVSHqxJ.o)(channel, raw) ?? raw.trim();
}
function isCrossContextTarget(params) {
  const currentTarget = params.toolContext?.currentChannelId?.trim();
  if (!currentTarget) return false;
  const normalizedTarget = normalizeTarget(params.channel, params.target);
  const normalizedCurrent = normalizeTarget(params.channel, currentTarget);
  if (!normalizedTarget || !normalizedCurrent) return false;
  return normalizedTarget !== normalizedCurrent;
}
function resolveAgentMessageToolsConfig(cfg, agentId) {
  const trimmedAgentId = agentId?.trim();
  const globalConfig = cfg.tools?.message;
  if (!trimmedAgentId) return globalConfig;
  const agentConfig = cfg.agents?.list?.find((entry) => entry.id === trimmedAgentId)?.tools?.message;
  if (!agentConfig) return globalConfig;
  return {
    ...globalConfig,
    ...agentConfig,
    crossContext: globalConfig?.crossContext || agentConfig.crossContext ? {
      ...globalConfig?.crossContext,
      ...agentConfig.crossContext,
      marker: globalConfig?.crossContext?.marker || agentConfig.crossContext?.marker ? {
        ...globalConfig?.crossContext?.marker,
        ...agentConfig.crossContext?.marker
      } : void 0
    } : void 0,
    broadcast: globalConfig?.broadcast || agentConfig.broadcast ? {
      ...globalConfig?.broadcast,
      ...agentConfig.broadcast
    } : void 0,
    actions: globalConfig?.actions || agentConfig.actions ? {
      ...globalConfig?.actions,
      ...agentConfig.actions
    } : void 0
  };
}
function resolveEffectiveMessageToolsConfig(params) {
  return resolveAgentMessageToolsConfig(params.cfg, params.agentId);
}
function resolveAllowedMessageActions(params) {
  const allow = resolveEffectiveMessageToolsConfig(params)?.actions?.allow;
  if (!allow) return;
  const normalized = allow.map((entry) => entry.trim()).filter(Boolean);
  return normalized.length > 0 ? Array.from(new Set(normalized)) : void 0;
}
function enforceMessageActionAllowlist(params) {
  const allowed = resolveAllowedMessageActions(params);
  if (!allowed || allowed.includes(params.action)) return;
  throw new Error(`Message action "${params.action}" is disabled for this agent.`);
}
function enforceCrossContextPolicy(params) {
  const currentTarget = params.toolContext?.currentChannelId?.trim();
  if (!currentTarget) return;
  if (!CONTEXT_GUARDED_ACTIONS.has(params.action)) return;
  const messageConfig = resolveEffectiveMessageToolsConfig({
    cfg: params.cfg,
    agentId: params.agentId
  });
  if (messageConfig?.allowCrossContextSend) return;
  const currentProvider = params.toolContext?.currentChannelProvider;
  const allowWithinProvider = messageConfig?.crossContext?.allowWithinProvider !== false;
  const allowAcrossProviders = messageConfig?.crossContext?.allowAcrossProviders === true;
  if (currentProvider && currentProvider !== params.channel) {
    if (!allowAcrossProviders) throw new Error(`Cross-context messaging denied: action=${params.action} target provider "${params.channel}" while bound to "${currentProvider}".`);
    return;
  }
  if (allowWithinProvider) return;
  const target = resolveContextGuardTarget(params.action, params.args);
  if (!target) return;
  if (!isCrossContextTarget({
    channel: params.channel,
    target,
    toolContext: params.toolContext
  })) return;
  throw new Error(`Cross-context messaging denied: action=${params.action} target="${target}" while bound to "${currentTarget}" (channel=${params.channel}).`);
}
async function buildCrossContextDecoration(params) {
  if (!params.toolContext?.currentChannelId) return null;
  if (params.toolContext.skipCrossContextDecoration) return null;
  if (!isCrossContextTarget(params)) return null;
  const markerConfig = resolveEffectiveMessageToolsConfig({
    cfg: params.cfg,
    agentId: params.agentId
  })?.crossContext?.marker;
  if (markerConfig?.enabled === false) return null;
  const currentName = (await (0, _targetResolver8NiS43Zp.n)({
    cfg: params.cfg,
    channel: params.channel,
    targetId: params.toolContext.currentChannelId,
    accountId: params.accountId ?? void 0
  })) ?? params.toolContext.currentChannelId;
  const originLabel = (0, _targetResolver8NiS43Zp.t)({
    channel: params.channel,
    target: params.toolContext.currentChannelId,
    display: currentName
  });
  const prefixTemplate = markerConfig?.prefix ?? "[from {channel}] ";
  const suffixTemplate = markerConfig?.suffix ?? "";
  const prefix = prefixTemplate.replaceAll("{channel}", originLabel);
  const suffix = suffixTemplate.replaceAll("{channel}", originLabel);
  const buildPresentation = (0, _registryBf5TpUad.t)(params.channel)?.messaging?.buildCrossContextPresentation;
  return {
    prefix,
    suffix,
    presentationBuilder: buildPresentation ? (message) => buildPresentation({
      originLabel,
      message,
      cfg: params.cfg,
      accountId: params.accountId ?? void 0
    }) : void 0
  };
}
function shouldApplyCrossContextMarker(action) {
  return CONTEXT_MARKER_ACTIONS.has(action);
}
function applyCrossContextDecoration(params) {
  if (params.preferPresentation && params.decoration.presentationBuilder) return {
    message: params.message,
    presentation: params.decoration.presentationBuilder?.(params.message),
    usedPresentation: true
  };
  return {
    message: `${params.decoration.prefix}${params.message}${params.decoration.suffix}`,
    usedPresentation: false
  };
}
//#endregion
//#region src/infra/outbound/outbound-send-service.ts
async function sendCoreMessage(params) {
  return await (0, _messageCZZW9OgM.t)({
    cfg: params.ctx.cfg,
    to: params.to,
    content: params.message,
    ...(params.payloads ? { payloads: params.payloads } : {}),
    agentId: params.ctx.agentId,
    requesterSessionKey: params.ctx.sessionKey,
    requesterAccountId: params.ctx.requesterAccountId ?? params.ctx.accountId ?? void 0,
    requesterSenderId: params.ctx.requesterSenderId,
    requesterSenderName: params.ctx.requesterSenderName,
    requesterSenderUsername: params.ctx.requesterSenderUsername,
    requesterSenderE164: params.ctx.requesterSenderE164,
    mediaUrl: params.mediaUrl || void 0,
    mediaUrls: params.mediaUrls,
    asVoice: params.asVoice,
    channel: params.ctx.channel || void 0,
    accountId: params.ctx.accountId ?? void 0,
    replyToId: params.replyToId,
    threadId: params.threadId,
    gifPlayback: params.gifPlayback,
    forceDocument: params.forceDocument,
    dryRun: params.ctx.dryRun,
    bestEffort: params.bestEffort ?? void 0,
    queuePolicy: params.queuePolicy,
    deps: params.ctx.deps,
    gateway: params.ctx.gateway,
    mirror: params.ctx.mirror,
    abortSignal: params.ctx.abortSignal,
    silent: params.ctx.silent,
    mediaAccess: params.ctx.mediaAccess
  });
}
function collectActionMediaSources(params) {
  const sources = [];
  for (const key of [
  "media",
  "mediaUrl",
  "path",
  "filePath",
  "fileUrl"])
  {
    const value = params[key];
    if (typeof value === "string" && value.trim()) sources.push(value);
  }
  return sources;
}
async function tryHandleWithPluginAction(params) {
  if (params.ctx.dryRun) return null;
  const mediaAccess = (0, _readCapabilityCUZ0OarG.t)({
    cfg: params.ctx.cfg,
    agentId: params.ctx.agentId ?? params.ctx.mirror?.agentId,
    mediaSources: collectActionMediaSources(params.ctx.params),
    sessionKey: params.ctx.sessionKey,
    messageProvider: params.ctx.sessionKey ? void 0 : params.ctx.channel,
    accountId: (params.ctx.sessionKey ? params.ctx.requesterAccountId ?? params.ctx.accountId : params.ctx.accountId) ?? void 0,
    requesterSenderId: params.ctx.requesterSenderId,
    requesterSenderName: params.ctx.requesterSenderName,
    requesterSenderUsername: params.ctx.requesterSenderUsername,
    requesterSenderE164: params.ctx.requesterSenderE164,
    mediaAccess: params.ctx.mediaAccess,
    mediaReadFile: params.ctx.mediaReadFile
  });
  const handled = await dispatchChannelMessageAction({
    channel: params.ctx.channel,
    action: params.action,
    cfg: params.ctx.cfg,
    params: params.ctx.params,
    mediaAccess,
    mediaLocalRoots: mediaAccess.localRoots,
    mediaReadFile: mediaAccess.readFile,
    accountId: params.ctx.accountId ?? void 0,
    requesterSenderId: params.ctx.requesterSenderId,
    senderIsOwner: params.ctx.senderIsOwner,
    sessionKey: params.ctx.sessionKey,
    sessionId: params.ctx.sessionId,
    inboundEventKind: params.ctx.inboundEventKind,
    agentId: params.ctx.agentId,
    gateway: params.ctx.gateway,
    toolContext: params.ctx.toolContext,
    dryRun: params.ctx.dryRun
  });
  if (!handled) return null;
  await params.onHandled?.();
  return {
    handledBy: "plugin",
    payload: (0, _toolPayloadGp3uQTKH.t)(handled),
    toolResult: handled
  };
}
function createChannelActionContext(params) {
  const mediaAccess = params.mediaAccess ?? params.ctx.mediaAccess;
  return {
    channel: params.ctx.channel,
    action: params.action,
    cfg: params.ctx.cfg,
    params: params.ctx.params,
    ...(mediaAccess ? { mediaAccess } : {}),
    mediaLocalRoots: mediaAccess?.localRoots ?? params.ctx.mediaAccess?.localRoots,
    mediaReadFile: mediaAccess?.readFile ?? params.ctx.mediaReadFile,
    accountId: params.ctx.accountId ?? void 0,
    requesterSenderId: params.ctx.requesterSenderId,
    senderIsOwner: params.ctx.senderIsOwner,
    sessionKey: params.ctx.sessionKey,
    sessionId: params.ctx.sessionId,
    inboundEventKind: params.ctx.inboundEventKind,
    agentId: params.ctx.agentId,
    gateway: params.ctx.gateway,
    toolContext: params.ctx.toolContext,
    dryRun: params.ctx.dryRun
  };
}
async function tryPreparePluginSendPayload(params) {
  const plugin = (0, _channelResolutionEcs0HEdK.r)({
    channel: params.ctx.channel,
    cfg: params.ctx.cfg
  });
  if (!plugin?.outbound) return null;
  const prepareSendPayload = plugin?.actions?.prepareSendPayload;
  if (!prepareSendPayload) return null;
  return (await prepareSendPayload({
    ctx: createChannelActionContext({
      ctx: params.ctx,
      action: "send"
    }),
    to: params.to,
    payload: params.payload,
    replyToId: params.replyToId,
    threadId: params.threadId
  })) ?? null;
}
async function executeSendAction(params) {
  (0, _deliverWPtVqUMT.i)(params.ctx.abortSignal);
  const defaultPayload = params.payload ?? {
    text: params.message,
    mediaUrl: params.mediaUrl,
    mediaUrls: params.mediaUrls,
    audioAsVoice: params.asVoice === true
  };
  const queuePolicy = params.bestEffort === false ? "required" : "best_effort";
  const preparedPayload = await tryPreparePluginSendPayload({
    ctx: params.ctx,
    to: params.to,
    payload: defaultPayload,
    replyToId: params.replyToId,
    threadId: params.threadId
  });
  if (preparedPayload) {
    (0, _deliverWPtVqUMT.i)(params.ctx.abortSignal);
    const result = await sendCoreMessage({
      ...params,
      queuePolicy,
      payloads: [preparedPayload]
    });
    return {
      handledBy: "core",
      payload: result,
      sendResult: result
    };
  }
  const pluginHandled = await tryHandleWithPluginAction({
    ctx: params.ctx,
    action: "send",
    onHandled: async () => {
      if (!params.ctx.mirror) return;
      const mirrorText = params.ctx.mirror.text ?? params.message;
      const mirrorMediaUrls = params.ctx.mirror.mediaUrls ?? params.mediaUrls ?? (params.mediaUrl ? [params.mediaUrl] : void 0);
      await (0, _transcriptBA0NgdA.t)({
        agentId: params.ctx.mirror.agentId,
        sessionKey: params.ctx.mirror.sessionKey,
        text: mirrorText,
        mediaUrls: mirrorMediaUrls,
        idempotencyKey: params.ctx.mirror.idempotencyKey,
        config: params.ctx.cfg
      });
    }
  });
  if (pluginHandled) return pluginHandled;
  (0, _deliverWPtVqUMT.i)(params.ctx.abortSignal);
  const result = await sendCoreMessage({
    ...params,
    queuePolicy
  });
  return {
    handledBy: "core",
    payload: result,
    sendResult: result
  };
}
async function executePollAction(params) {
  const pluginHandled = await tryHandleWithPluginAction({
    ctx: params.ctx,
    action: "poll"
  });
  if (pluginHandled) return pluginHandled;
  const corePoll = params.resolveCorePoll();
  const result = await (0, _messageCZZW9OgM.n)({
    cfg: params.ctx.cfg,
    to: corePoll.to,
    question: corePoll.question,
    options: corePoll.options,
    maxSelections: corePoll.maxSelections,
    durationSeconds: corePoll.durationSeconds ?? void 0,
    durationHours: corePoll.durationHours ?? void 0,
    channel: params.ctx.channel,
    accountId: params.ctx.accountId ?? void 0,
    threadId: corePoll.threadId ?? void 0,
    silent: params.ctx.silent ?? void 0,
    isAnonymous: corePoll.isAnonymous ?? void 0,
    dryRun: params.ctx.dryRun,
    gateway: params.ctx.gateway
  });
  return {
    handledBy: "core",
    payload: result,
    pollResult: result
  };
}
//#endregion
//#region src/infra/outbound/message-action-runner.ts
let messageActionGatewayRuntimePromise = null;
function loadMessageActionGatewayRuntime() {
  messageActionGatewayRuntimePromise ??= Promise.resolve().then(() => jitiImport("./message.gateway.runtime.js").then((m) => _interopRequireWildcard(m)));
  return messageActionGatewayRuntimePromise;
}
function getToolResult(result) {
  return "toolResult" in result ? result.toolResult : void 0;
}
function resolveGatewayActionOptions(gateway) {
  return {
    url: gateway?.mode === _clientInfoBVWE_ra.r.BACKEND || gateway?.clientName === _clientInfoBVWE_ra.i.GATEWAY_CLIENT ? void 0 : gateway?.url,
    token: gateway?.token,
    timeoutMs: typeof gateway?.timeoutMs === "number" && Number.isFinite(gateway.timeoutMs) ? Math.max(1, Math.floor(gateway.timeoutMs)) : 1e4,
    clientName: gateway?.clientName ?? _clientInfoBVWE_ra.i.CLI,
    clientDisplayName: gateway?.clientDisplayName,
    mode: gateway?.mode ?? _clientInfoBVWE_ra.r.CLI
  };
}
async function callGatewayMessageAction(params) {
  const { callGatewayLeastPrivilege } = await loadMessageActionGatewayRuntime();
  const gateway = resolveGatewayActionOptions(params.gateway);
  return await callGatewayLeastPrivilege({
    url: gateway.url,
    token: gateway.token,
    method: "message.action",
    params: params.actionParams,
    timeoutMs: gateway.timeoutMs,
    clientName: gateway.clientName,
    clientDisplayName: gateway.clientDisplayName,
    mode: gateway.mode
  });
}
async function resolveGatewayActionIdempotencyKey(idempotencyKey) {
  if (idempotencyKey) return idempotencyKey;
  const { randomIdempotencyKey } = await loadMessageActionGatewayRuntime();
  return randomIdempotencyKey();
}
function applyCrossContextMessageDecoration({ params, message, decoration, preferPresentation }) {
  const applied = applyCrossContextDecoration({
    message,
    decoration,
    preferPresentation
  });
  params.message = applied.message;
  if (applied.presentation) {
    const existing = (0, _payloadBDV15CYA.l)(params.presentation);
    params.presentation = existing ? {
      ...existing,
      blocks: [...applied.presentation.blocks, ...existing.blocks]
    } : applied.presentation;
  }
  return applied.message;
}
async function maybeApplyCrossContextMarker(params) {
  if (!shouldApplyCrossContextMarker(params.action) || !params.toolContext) return params.message;
  const decoration = await buildCrossContextDecoration({
    cfg: params.cfg,
    channel: params.channel,
    target: params.target,
    toolContext: params.toolContext,
    accountId: params.accountId ?? void 0,
    agentId: params.agentId ?? void 0
  });
  if (!decoration) return params.message;
  return applyCrossContextMessageDecoration({
    params: params.args,
    message: params.message,
    decoration,
    preferPresentation: params.preferPresentation
  });
}
async function resolveChannel(cfg, params, toolContext) {
  const selection = await (0, _channelSelectionDQG3SYlu.n)({
    cfg,
    channel: (0, _commonE9YpX7pB.g)(params, "channel"),
    fallbackChannel: toolContext?.currentChannelProvider
  });
  if (selection.source === "tool-context-fallback") params.channel = selection.channel;
  return selection.channel;
}
function addCandidateAndUnprefixedAlias(candidates, value) {
  const normalized = (0, _stringCoerceDyL154ka.c)(value);
  if (!normalized) return;
  candidates.add(normalized);
  const unprefixed = normalized.replace(/^(channel|group|user):/i, "").trim();
  if (unprefixed && unprefixed !== normalized) candidates.add(unprefixed);
}
function normalizeTargetForAccountBinding(channel, target) {
  try {
    return (0, _targetIdResolutionDVSHqxJ.o)(channel, target);
  } catch {
    return;
  }
}
function inferPeerKindForAccountBinding(channel, target) {
  const inferred = (0, _chatTypeD_QPUzR.t)((0, _registryBf5TpUad.t)(channel)?.messaging?.inferTargetChatType?.({ to: target }));
  if (inferred) return inferred;
  const candidates = [target, normalizeTargetForAccountBinding(channel, target)].filter((value) => Boolean(value));
  if (candidates.some((value) => /^user:/i.test(value))) return "direct";
  if (candidates.some((value) => /^(channel|group):/i.test(value))) return "channel";
}
function resolveTargetBoundAccountId(params) {
  if (!params.agentId) return;
  const target = (0, _stringCoerceDyL154ka.c)(params.args.to) ?? (0, _stringCoerceDyL154ka.c)(params.args.channelId) ?? "";
  if (!target) return (0, _boundAccountReadQnHEyAzX.t)({
    cfg: params.cfg,
    channelId: params.channel,
    agentId: params.agentId
  });
  const candidates = /* @__PURE__ */new Set();
  addCandidateAndUnprefixedAlias(candidates, target);
  addCandidateAndUnprefixedAlias(candidates, normalizeTargetForAccountBinding(params.channel, target));
  const [peerId, ...exactPeerIdAliases] = Array.from(candidates);
  return (0, _boundAccountReadQnHEyAzX.t)({
    cfg: params.cfg,
    channelId: params.channel,
    agentId: params.agentId,
    peerId,
    exactPeerIdAliases,
    peerKind: inferPeerKindForAccountBinding(params.channel, target)
  });
}
async function resolveActionTarget(params) {
  let resolvedTarget;
  const toRaw = (0, _stringCoerceDyL154ka.c)(params.args.to) ?? "";
  if (toRaw) {
    const resolved = await resolveResolvedTargetOrThrow({
      cfg: params.cfg,
      channel: params.channel,
      input: toRaw,
      accountId: params.accountId ?? void 0
    });
    params.args.to = resolved.to;
    resolvedTarget = resolved;
  }
  const channelIdRaw = (0, _stringCoerceDyL154ka.c)(params.args.channelId) ?? "";
  if (channelIdRaw) {
    const resolved = await resolveResolvedTargetOrThrow({
      cfg: params.cfg,
      channel: params.channel,
      input: channelIdRaw,
      accountId: params.accountId ?? void 0,
      preferredKind: "group",
      validateResolvedTarget: (target) => target.kind === "user" ? `Channel id "${channelIdRaw}" resolved to a user target.` : void 0
    });
    params.args.channelId = sanitizeGroupTargetId(resolved.to);
  }
  return resolvedTarget;
}
function sanitizeGroupTargetId(target) {
  return target.replace(/^(channel|group):/i, "");
}
async function resolveResolvedTargetOrThrow(params) {
  const resolved = await (0, _targetResolver8NiS43Zp.i)({
    cfg: params.cfg,
    channel: params.channel,
    input: params.input,
    accountId: params.accountId,
    preferredKind: params.preferredKind
  });
  if (!resolved.ok) throw resolved.error;
  const validationError = params.validateResolvedTarget?.(resolved.target);
  if (validationError) throw new Error(validationError);
  return resolved.target;
}
function updateSendPayloadPartsFromReplyPayload(parts, payload) {
  const sendable = (0, _replyPayloadDMPQsrQC.m)(payload);
  const mediaUrls = sendable.mediaUrls.length > 0 ? sendable.mediaUrls : void 0;
  return {
    ...parts,
    message: payload.text ?? "",
    payload,
    mediaUrl: mediaUrls?.[0],
    mediaUrls,
    asVoice: payload.audioAsVoice === true
  };
}
function applySendPayloadPartsToActionParams(actionParams, parts) {
  actionParams.message = parts.message;
  actionParams.media = parts.mediaUrl;
  actionParams.mediaUrl = parts.mediaUrl;
  actionParams.mediaUrls = parts.mediaUrls;
  actionParams.asVoice = parts.asVoice || void 0;
  actionParams.audioAsVoice = parts.asVoice || void 0;
}
function collectMessageAttachmentMediaHints(value) {
  if (!Array.isArray(value)) return [];
  const mediaUrls = [];
  const seen = /* @__PURE__ */new Set();
  const pushMedia = (entry) => {
    const normalized = (0, _stringCoerceDyL154ka.c)(entry);
    if (!normalized || seen.has(normalized)) return;
    seen.add(normalized);
    mediaUrls.push(normalized);
  };
  for (const attachment of value) {
    if (!attachment || typeof attachment !== "object" || Array.isArray(attachment)) continue;
    const record = attachment;
    pushMedia(record.media);
    pushMedia(record.mediaUrl);
    pushMedia(record.path);
    pushMedia(record.filePath);
    pushMedia(record.fileUrl);
    pushMedia(record.url);
  }
  return mediaUrls;
}
function hasExplicitRouteParam(params) {
  for (const key of [
  "channel",
  "target",
  "to",
  "channelId"])
  if ((0, _stringCoerceDyL154ka.c)(params[key])) return true;
  return Array.isArray(params.targets) && params.targets.some((value) => (0, _stringCoerceDyL154ka.c)(value));
}
function shouldUseInternalSourceReplySink(input, params) {
  return input.action === "send" && input.sourceReplyDeliveryMode === "message_tool_only" && (0, _stringCoerceDyL154ka.s)(input.toolContext?.currentChannelProvider) === "webchat" && Boolean(input.sessionKey?.trim()) && !hasExplicitRouteParam(params);
}
async function runGatewayPluginMessageActionOrNull(params) {
  if (params.dryRun || !params.gateway) return null;
  const plugin = (0, _channelResolutionEcs0HEdK.r)({
    channel: params.channel,
    cfg: params.cfg
  });
  if (!plugin?.actions?.handleAction) return null;
  if ((plugin.actions.resolveExecutionMode?.({ action: params.action }) ?? "local") !== "gateway") return null;
  const payload = await callGatewayMessageAction({
    gateway: params.gateway,
    actionParams: {
      channel: params.channel,
      action: params.action,
      params: params.params,
      accountId: params.accountId ?? void 0,
      requesterSenderId: params.input.requesterSenderId ?? void 0,
      senderIsOwner: params.input.senderIsOwner,
      sessionKey: params.input.sessionKey,
      sessionId: params.input.sessionId,
      inboundTurnKind: params.input.inboundEventKind,
      agentId: params.agentId,
      toolContext: params.input.toolContext,
      idempotencyKey: await resolveGatewayActionIdempotencyKey((0, _stringCoerceDyL154ka.c)(params.params.idempotencyKey))
    }
  });
  return params.result(payload);
}
function resolveGateway(input) {
  if (!input.gateway) return;
  return {
    url: input.gateway.url,
    token: input.gateway.token,
    timeoutMs: input.gateway.timeoutMs,
    clientName: input.gateway.clientName,
    clientDisplayName: input.gateway.clientDisplayName,
    mode: input.gateway.mode
  };
}
async function handleBroadcastAction(input, params) {
  (0, _deliverWPtVqUMT.i)(input.abortSignal);
  if (!(resolveEffectiveMessageToolsConfig({
    cfg: input.cfg,
    agentId: input.agentId
  })?.broadcast?.enabled !== false)) throw new Error("Broadcast is disabled. Set tools.message.broadcast.enabled to true.");
  const rawTargets = (0, _commonE9YpX7pB.m)(params, "targets", { required: true });
  if (rawTargets.length === 0) throw new Error("Broadcast requires at least one target in --targets.");
  const channelHint = (0, _commonE9YpX7pB.g)(params, "channel");
  const targetChannels = channelHint && (0, _stringCoerceDyL154ka.s)(channelHint) !== "all" ? [await resolveChannel(input.cfg, { channel: channelHint }, input.toolContext)] : await (async () => {
    const configured = await (0, _channelSelectionDQG3SYlu.t)(input.cfg);
    if (configured.length === 0) throw new Error("Broadcast requires at least one configured channel.");
    return configured;
  })();
  const results = [];
  const isAbortError = (err) => err instanceof Error && err.name === "AbortError";
  for (const targetChannel of targetChannels) {
    (0, _deliverWPtVqUMT.i)(input.abortSignal);
    for (const target of rawTargets) {
      (0, _deliverWPtVqUMT.i)(input.abortSignal);
      try {
        const resolved = await resolveResolvedTargetOrThrow({
          cfg: input.cfg,
          channel: targetChannel,
          input: target
        });
        const sendResult = await runMessageAction({
          ...input,
          action: "send",
          params: {
            ...params,
            channel: targetChannel,
            target: resolved.to
          }
        });
        results.push({
          channel: targetChannel,
          to: resolved.to,
          ok: true,
          result: sendResult.kind === "send" ? sendResult.sendResult : void 0
        });
      } catch (err) {
        if (isAbortError(err)) throw err;
        results.push({
          channel: targetChannel,
          to: target,
          ok: false,
          error: (0, _errorsB3ZrCRlt.i)(err)
        });
      }
    }
  }
  return {
    kind: "broadcast",
    channel: targetChannels[0] ?? (0, _stringCoerceDyL154ka.s)(channelHint) ?? "unknown",
    action: "broadcast",
    handledBy: input.dryRun ? "dry-run" : "core",
    payload: { results },
    dryRun: Boolean(input.dryRun)
  };
}
async function handleInternalSourceReplySendAction(input, params) {
  (0, _deliverWPtVqUMT.i)(input.abortSignal);
  const dryRun = Boolean(input.dryRun ?? readBooleanParam(params, "dryRun"));
  const sourceReply = await buildSendPayloadParts({
    cfg: input.cfg,
    actionParams: params,
    input,
    agentId: input.agentId ?? (input.sessionKey ? (0, _agentScopeCtLXGcWm._)({
      sessionKey: input.sessionKey,
      config: input.cfg
    }) : void 0)
  });
  return {
    kind: "send",
    channel: _messageChannelCoreBoUoCGOD.r,
    action: "send",
    to: "current-run",
    handledBy: "internal-source",
    payload: {
      status: "ok",
      deliveryStatus: dryRun ? "dry_run" : "sent",
      channel: _messageChannelCoreBoUoCGOD.r,
      target: "current-run",
      sourceReplyDeliveryMode: input.sourceReplyDeliveryMode,
      ...(dryRun ? {} : { sourceReplySink: "internal-ui" }),
      sourceReply: sourceReply.payload,
      ...(sourceReply.message ? { message: sourceReply.message } : {}),
      ...(sourceReply.mediaUrl ? { mediaUrl: sourceReply.mediaUrl } : {}),
      ...(sourceReply.mediaUrls?.length ? { mediaUrls: sourceReply.mediaUrls } : {}),
      dryRun
    },
    dryRun
  };
}
async function buildSendPayloadParts(params) {
  const { actionParams, input } = params;
  if (actionParams.pin === true && actionParams.delivery == null) actionParams.delivery = { pin: { enabled: true } };
  if (typeof actionParams.message !== "string" || !actionParams.message.trim()) for (const alias of [
  "SendMessage",
  "content",
  "text"])
  {
    const value = actionParams[alias];
    if (typeof value === "string" && value.trim()) {
      actionParams.message = stripFormattedReasoningMessage(value);
      console.warn(`[message-tool] normalized alias "${alias}" to "message" for send action`);
      break;
    }
  }
  const mediaHint = (0, _commonE9YpX7pB.g)(actionParams, "media", { trim: false }) ?? (0, _commonE9YpX7pB.g)(actionParams, "mediaUrl", { trim: false }) ?? (0, _commonE9YpX7pB.g)(actionParams, "path", { trim: false }) ?? (0, _commonE9YpX7pB.g)(actionParams, "filePath", { trim: false }) ?? (0, _commonE9YpX7pB.g)(actionParams, "fileUrl", { trim: false });
  const attachmentMediaHints = collectMessageAttachmentMediaHints(actionParams.attachments);
  const hasMediaHint = Boolean(mediaHint) || attachmentMediaHints.length > 0;
  const hasPresentation = (0, _payloadBDV15CYA.n)(actionParams.presentation);
  const hasInteractive = (0, _payloadBDV15CYA.t)(actionParams.interactive);
  const caption = (0, _commonE9YpX7pB.g)(actionParams, "caption", { allowEmpty: true }) ?? "";
  let message = (0, _commonE9YpX7pB.g)(actionParams, "message", {
    required: !hasMediaHint && !hasPresentation && !hasInteractive,
    allowEmpty: true
  }) ?? "";
  if (message.includes("\\n")) message = message.replaceAll("\\n", "\n");
  if (!message.trim() && caption.trim()) message = caption;
  const parsed = (0, _payloadsBOM5t2O.d)(message);
  const mergedMediaUrls = [];
  const seenMedia = /* @__PURE__ */new Set();
  const pushMedia = (value) => {
    const trimmed = (0, _stringCoerceDyL154ka.c)(value);
    if (!trimmed || seenMedia.has(trimmed)) return;
    seenMedia.add(trimmed);
    mergedMediaUrls.push(trimmed);
  };
  pushMedia(mediaHint);
  for (const attachmentMediaHint of attachmentMediaHints) pushMedia(attachmentMediaHint);
  for (const url of parsed.mediaUrls ?? []) pushMedia(url);
  pushMedia(parsed.mediaUrl);
  const normalizedMediaUrls = await normalizeSandboxMediaList({
    values: mergedMediaUrls,
    sandboxRoot: input.sandboxRoot
  });
  mergedMediaUrls.length = 0;
  mergedMediaUrls.push(...normalizedMediaUrls);
  message = (0, _payloadsBOM5t2O.u)(parsed.text);
  actionParams.message = message;
  if (!actionParams.replyTo && parsed.replyToId) actionParams.replyTo = parsed.replyToId;
  if (!actionParams.media) actionParams.media = mergedMediaUrls[0] || void 0;
  if (params.channel && params.target) message = await maybeApplyCrossContextMarker({
    cfg: params.cfg,
    channel: params.channel,
    action: "send",
    target: params.target,
    toolContext: input.toolContext,
    accountId: params.accountId,
    agentId: params.agentId,
    args: actionParams,
    message,
    preferPresentation: true
  });
  const mediaUrl = (0, _commonE9YpX7pB.g)(actionParams, "media", { trim: false });
  if (!(0, _payloadBDV15CYA.a)({
    text: message,
    mediaUrl,
    mediaUrls: mergedMediaUrls,
    presentation: actionParams.presentation,
    interactive: actionParams.interactive
  })) throw new Error("send requires text or media");
  actionParams.message = message;
  const gifPlayback = readBooleanParam(actionParams, "gifPlayback") ?? false;
  const forceDocument = readBooleanParam(actionParams, "forceDocument") ?? readBooleanParam(actionParams, "asDocument") ?? false;
  const asVoice = readBooleanParam(actionParams, "asVoice") ?? readBooleanParam(actionParams, "audioAsVoice") ?? parsed.audioAsVoice ?? false;
  const bestEffort = readBooleanParam(actionParams, "bestEffort");
  const silent = readBooleanParam(actionParams, "silent");
  const mirrorMediaUrls = mergedMediaUrls.length > 0 ? mergedMediaUrls : mediaUrl ? [mediaUrl] : void 0;
  const rawDelivery = actionParams.delivery;
  const delivery = rawDelivery && typeof rawDelivery === "object" && !Array.isArray(rawDelivery) ? rawDelivery : void 0;
  const rawChannelData = actionParams.channelData;
  const channelData = rawChannelData && typeof rawChannelData === "object" && !Array.isArray(rawChannelData) ? rawChannelData : void 0;
  const presentation = (0, _payloadBDV15CYA.l)(actionParams.presentation);
  const interactive = (0, _payloadBDV15CYA.c)(actionParams.interactive);
  return {
    message,
    payload: {
      text: message,
      ...(mediaUrl ? { mediaUrl } : {}),
      ...(mergedMediaUrls.length ? { mediaUrls: mergedMediaUrls } : {}),
      ...(asVoice ? { audioAsVoice: true } : {}),
      ...(presentation ? { presentation } : {}),
      ...(interactive ? { interactive } : {}),
      ...(delivery ? { delivery } : {}),
      ...(channelData ? { channelData } : {})
    },
    ...(mediaUrl ? { mediaUrl } : {}),
    ...(mirrorMediaUrls ? { mediaUrls: mirrorMediaUrls } : {}),
    asVoice,
    gifPlayback,
    forceDocument,
    ...(bestEffort !== void 0 ? { bestEffort } : {}),
    ...(silent !== void 0 ? { silent } : {})
  };
}
async function handleSendAction(ctx) {
  const { cfg, params, channel, accountId, dryRun, gateway, input, agentId, resolvedTarget, abortSignal } = ctx;
  (0, _deliverWPtVqUMT.i)(abortSignal);
  const action = "send";
  const to = (0, _commonE9YpX7pB.g)(params, "to", { required: true });
  let sendPayload = await buildSendPayloadParts({
    cfg,
    actionParams: params,
    input,
    channel,
    target: to,
    accountId,
    agentId
  });
  const replyToId = resolveAndApplyOutboundReplyToId(params, {
    channel,
    toolContext: input.toolContext
  });
  const { resolvedThreadId, outboundRoute } = await prepareOutboundMirrorRoute({
    cfg,
    channel,
    to,
    actionParams: params,
    accountId,
    toolContext: input.toolContext,
    agentId,
    currentSessionKey: input.sessionKey,
    dryRun,
    resolvedTarget,
    resolveAutoThreadId: (0, _registryBf5TpUad.t)(channel)?.threading?.resolveAutoThreadId,
    resolveOutboundSessionRoute: _outboundSessionDKXWYF4a.n,
    ensureOutboundSessionEntry: _outboundSessionDKXWYF4a.t
  });
  (0, _deliverWPtVqUMT.i)(abortSignal);
  const ttsPayload = await maybeApplyTtsToMessageActionSendPayload({
    payload: sendPayload.payload,
    cfg,
    channel,
    accountId,
    agentId,
    sessionKey: input.sessionKey,
    dryRun
  });
  if (ttsPayload !== sendPayload.payload) {
    sendPayload = updateSendPayloadPartsFromReplyPayload(sendPayload, ttsPayload);
    applySendPayloadPartsToActionParams(params, sendPayload);
  }
  (0, _deliverWPtVqUMT.i)(abortSignal);
  const gatewayPluginAction = await runGatewayPluginMessageActionOrNull({
    cfg,
    params,
    channel,
    action,
    accountId,
    dryRun,
    gateway,
    input,
    agentId,
    result: (payload) => ({
      kind: "send",
      channel,
      action,
      to,
      handledBy: "plugin",
      payload,
      dryRun
    })
  });
  if (gatewayPluginAction) return gatewayPluginAction;
  const send = await executeSendAction({
    ctx: {
      cfg,
      channel,
      params,
      agentId,
      sessionKey: input.sessionKey,
      requesterAccountId: input.requesterAccountId ?? void 0,
      requesterSenderId: input.requesterSenderId ?? void 0,
      requesterSenderName: input.requesterSenderName ?? void 0,
      requesterSenderUsername: input.requesterSenderUsername ?? void 0,
      requesterSenderE164: input.requesterSenderE164 ?? void 0,
      senderIsOwner: input.senderIsOwner,
      mediaAccess: ctx.mediaAccess,
      accountId: accountId ?? void 0,
      sessionId: input.sessionId,
      inboundEventKind: input.inboundEventKind,
      gateway,
      toolContext: input.toolContext,
      deps: input.deps,
      dryRun,
      mirror: outboundRoute && !dryRun ? {
        sessionKey: outboundRoute.sessionKey,
        agentId,
        text: sendPayload.message,
        mediaUrls: sendPayload.mediaUrls,
        idempotencyKey: (0, _stringCoerceDyL154ka.c)(params.idempotencyKey) ?? void 0
      } : void 0,
      abortSignal,
      silent: sendPayload.silent ?? void 0
    },
    to,
    message: sendPayload.message,
    payload: sendPayload.payload,
    mediaUrl: sendPayload.mediaUrl,
    mediaUrls: sendPayload.mediaUrls,
    asVoice: sendPayload.asVoice,
    gifPlayback: sendPayload.gifPlayback,
    forceDocument: sendPayload.forceDocument,
    bestEffort: sendPayload.bestEffort,
    replyToId: replyToId ?? void 0,
    threadId: resolvedThreadId ?? void 0
  });
  return {
    kind: "send",
    channel,
    action,
    to,
    handledBy: send.handledBy,
    payload: send.payload,
    toolResult: send.toolResult,
    sendResult: send.sendResult,
    dryRun
  };
}
async function handlePollAction(ctx) {
  const { cfg, params, channel, accountId, dryRun, gateway, input, agentId, abortSignal } = ctx;
  (0, _deliverWPtVqUMT.i)(abortSignal);
  const action = "poll";
  const to = (0, _commonE9YpX7pB.g)(params, "to", { required: true });
  const silent = readBooleanParam(params, "silent");
  const resolvedThreadId = resolveAndApplyOutboundThreadId(params, {
    cfg,
    to,
    accountId,
    toolContext: input.toolContext,
    resolveAutoThreadId: (0, _registryBf5TpUad.t)(channel)?.threading?.resolveAutoThreadId
  });
  const base = typeof params.message === "string" ? params.message : "";
  await maybeApplyCrossContextMarker({
    cfg,
    channel,
    action,
    target: to,
    toolContext: input.toolContext,
    accountId,
    agentId,
    args: params,
    message: base,
    preferPresentation: false
  });
  const gatewayPluginAction = await runGatewayPluginMessageActionOrNull({
    cfg,
    params,
    channel,
    action,
    accountId,
    dryRun,
    gateway,
    input,
    agentId,
    result: (payload) => ({
      kind: "poll",
      channel,
      action,
      to,
      handledBy: "plugin",
      payload,
      dryRun
    })
  });
  if (gatewayPluginAction) return gatewayPluginAction;
  const poll = await executePollAction({
    ctx: {
      cfg,
      channel,
      params,
      accountId: accountId ?? void 0,
      agentId,
      requesterSenderId: input.requesterSenderId ?? void 0,
      sessionKey: input.sessionKey,
      sessionId: input.sessionId,
      inboundEventKind: input.inboundEventKind,
      gateway,
      toolContext: input.toolContext,
      dryRun,
      silent: silent ?? void 0
    },
    resolveCorePoll: () => {
      const question = (0, _commonE9YpX7pB.g)(params, "pollQuestion", { required: true });
      const options = (0, _commonE9YpX7pB.m)(params, "pollOption", { required: true });
      if (options.length < 2) throw new Error("pollOption requires at least two values");
      const allowMultiselect = readBooleanParam(params, "pollMulti") ?? false;
      const durationHours = (0, _commonE9YpX7pB.f)(params, "pollDurationHours", {
        integer: true,
        strict: true
      });
      return {
        to,
        question,
        options,
        maxSelections: (0, _pollsCV11_tu.r)(options.length, allowMultiselect),
        durationHours: durationHours ?? void 0,
        threadId: resolvedThreadId ?? void 0
      };
    }
  });
  return {
    kind: "poll",
    channel,
    action,
    to,
    handledBy: poll.handledBy,
    payload: poll.payload,
    toolResult: poll.toolResult,
    pollResult: poll.pollResult,
    dryRun
  };
}
async function handlePluginAction(ctx) {
  const { cfg, params, channel, mediaAccess, accountId, dryRun, gateway, input, abortSignal, agentId } = ctx;
  (0, _deliverWPtVqUMT.i)(abortSignal);
  const action = input.action;
  if (dryRun) return {
    kind: "action",
    channel,
    action,
    handledBy: "dry-run",
    payload: {
      ok: true,
      dryRun: true,
      channel,
      action
    },
    dryRun: true
  };
  if (!(0, _channelResolutionEcs0HEdK.r)({
    channel,
    cfg
  })?.actions?.handleAction) throw new Error(`Channel ${channel} is unavailable for message actions (plugin not loaded).`);
  const gatewayPluginAction = await runGatewayPluginMessageActionOrNull({
    cfg,
    params,
    channel,
    action,
    accountId,
    dryRun,
    gateway,
    input,
    agentId,
    result: (payload) => ({
      kind: "action",
      channel,
      action,
      handledBy: "plugin",
      payload,
      dryRun
    })
  });
  if (gatewayPluginAction) return gatewayPluginAction;
  const handled = await dispatchChannelMessageAction({
    channel,
    action,
    cfg,
    params,
    mediaAccess,
    mediaLocalRoots: mediaAccess.localRoots,
    mediaReadFile: mediaAccess.readFile,
    accountId: accountId ?? void 0,
    requesterSenderId: input.requesterSenderId ?? void 0,
    senderIsOwner: input.senderIsOwner,
    sessionKey: input.sessionKey,
    sessionId: input.sessionId,
    inboundEventKind: input.inboundEventKind,
    agentId,
    gateway,
    toolContext: input.toolContext,
    dryRun
  });
  if (!handled) throw new Error(`Message action ${action} not supported for channel ${channel}.`);
  return {
    kind: "action",
    channel,
    action,
    handledBy: "plugin",
    payload: (0, _toolPayloadGp3uQTKH.t)(handled),
    toolResult: handled,
    dryRun
  };
}
async function runMessageAction(input) {
  const cfg = input.cfg;
  let params = { ...input.params };
  const resolvedAgentId = input.agentId ?? (input.sessionKey ? (0, _agentScopeCtLXGcWm._)({
    sessionKey: input.sessionKey,
    config: cfg
  }) : void 0);
  parseJsonMessageParam(params, "presentation");
  parseJsonMessageParam(params, "delivery");
  parseInteractiveParam(params);
  const action = input.action;
  enforceMessageActionAllowlist({
    cfg,
    agentId: resolvedAgentId,
    action
  });
  if (action === "broadcast") return handleBroadcastAction(input, params);
  if (action === "send" && hasPollCreationParams(params)) throw new Error("Poll fields require action \"poll\"; use action \"poll\" instead of \"send\".");
  if (shouldUseInternalSourceReplySink(input, params)) return handleInternalSourceReplySendAction({
    ...input,
    agentId: resolvedAgentId
  }, params);
  params = normalizeMessageActionInput({
    action,
    args: params,
    toolContext: input.toolContext
  });
  const channel = await resolveChannel(cfg, params, input.toolContext);
  let accountId = (0, _commonE9YpX7pB.g)(params, "accountId") ?? input.defaultAccountId;
  if (!accountId && resolvedAgentId) accountId = resolveTargetBoundAccountId({
    cfg,
    channel,
    args: params,
    agentId: resolvedAgentId
  });
  if (accountId) params.accountId = accountId;
  const dryRun = Boolean(input.dryRun ?? readBooleanParam(params, "dryRun"));
  const normalizationPolicy = resolveAttachmentMediaPolicy({
    sandboxRoot: input.sandboxRoot,
    mediaLocalRoots: (0, _localRootsPi6a9oaK.r)(cfg, resolvedAgentId)
  });
  const extraActionMediaSourceParamKeys = resolveExtraActionMediaSourceParamKeys({
    cfg,
    action,
    args: params,
    channel,
    accountId,
    sessionKey: input.sessionKey,
    sessionId: input.sessionId,
    agentId: resolvedAgentId,
    requesterSenderId: input.requesterSenderId,
    senderIsOwner: input.senderIsOwner
  });
  await normalizeSandboxMediaParams({
    args: params,
    mediaPolicy: normalizationPolicy,
    extraParamKeys: extraActionMediaSourceParamKeys
  });
  const mediaAccess = (0, _readCapabilityCUZ0OarG.t)({
    cfg,
    agentId: resolvedAgentId,
    mediaSources: collectActionMediaSourceHints(params, extraActionMediaSourceParamKeys),
    sessionKey: input.sessionKey,
    messageProvider: input.sessionKey ? void 0 : channel,
    accountId: input.sessionKey ? input.requesterAccountId ?? accountId : accountId,
    requesterSenderId: input.requesterSenderId,
    requesterSenderName: input.requesterSenderName,
    requesterSenderUsername: input.requesterSenderUsername,
    requesterSenderE164: input.requesterSenderE164
  });
  const mediaPolicy = resolveAttachmentMediaPolicy({
    sandboxRoot: input.sandboxRoot,
    mediaAccess
  });
  await hydrateAttachmentParamsForAction({
    cfg,
    channel,
    accountId,
    args: params,
    action,
    dryRun,
    mediaPolicy
  });
  const resolvedTarget = await resolveActionTarget({
    cfg,
    channel,
    action,
    args: params,
    accountId
  });
  enforceCrossContextPolicy({
    channel,
    action,
    args: params,
    toolContext: input.toolContext,
    cfg,
    agentId: resolvedAgentId
  });
  const gateway = resolveGateway(input);
  if (action === "send") return handleSendAction({
    cfg,
    params,
    channel,
    mediaAccess,
    accountId,
    dryRun,
    gateway,
    input,
    agentId: resolvedAgentId,
    resolvedTarget,
    abortSignal: input.abortSignal
  });
  if (action === "poll") return handlePollAction({
    cfg,
    params,
    channel,
    mediaAccess,
    accountId,
    dryRun,
    gateway,
    input,
    abortSignal: input.abortSignal
  });
  return handlePluginAction({
    cfg,
    params,
    channel,
    mediaAccess,
    accountId,
    dryRun,
    gateway,
    input,
    agentId: resolvedAgentId,
    abortSignal: input.abortSignal
  });
}
//#endregion /* v9-854eef5708fbb176 */
