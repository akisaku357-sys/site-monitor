"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = resetAdjustedParamsByToolCallIdForTests;exports.t = void 0; //#region src/agents/pi-tools.before-tool-call.state.ts
const adjustedParamsByToolCallId = exports.t = /* @__PURE__ */new Map();
function resetAdjustedParamsByToolCallIdForTests() {
  adjustedParamsByToolCallId.clear();
}
//#endregion /* v9-04abede2ebe4c0e5 */
