"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = getActiveRuntimeWebToolsMetadata;exports.r = setActiveRuntimeWebToolsMetadata;exports.t = clearActiveRuntimeWebToolsMetadata; //#region src/secrets/runtime-web-tools-state.ts
let activeRuntimeWebToolsMetadata = null;
function clearActiveRuntimeWebToolsMetadata() {
  activeRuntimeWebToolsMetadata = null;
}
function setActiveRuntimeWebToolsMetadata(metadata) {
  activeRuntimeWebToolsMetadata = structuredClone(metadata);
}
function getActiveRuntimeWebToolsMetadata() {
  if (!activeRuntimeWebToolsMetadata) return null;
  return structuredClone(activeRuntimeWebToolsMetadata);
}
//#endregion /* v9-abdbb650f25c0297 */
