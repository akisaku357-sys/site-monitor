"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = isToolAllowed;exports.r = resolveSandboxToolPolicyForAgent;exports.t = classifyToolAgainstSandboxToolPolicy;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
require("./agent-scope-CtLXGcWm.js");
var _agentScopeConfigCMp71_ = require("./agent-scope-config-CMp71_27.js");
var _globPatternCrqljM7B = require("./glob-pattern-CrqljM7B.js");
var _toolPolicyCOX5DaEj = require("./tool-policy-COX5DaEj.js");
var _constantsBy80hBjs = require("./constants-By80hBjs.js");
//#region src/agents/sandbox/tool-policy.ts
function buildSource(params) {
  return {
    source: params.scope,
    key: params.key
  };
}
function pickConfiguredList(params) {
  if (Array.isArray(params.agent)) return {
    values: params.agent,
    source: buildSource({
      scope: "agent",
      key: "agents.list[].tools.sandbox.tools.allow"
    })
  };
  if (Array.isArray(params.global)) return {
    values: params.global,
    source: buildSource({
      scope: "global",
      key: "tools.sandbox.tools.allow"
    })
  };
  return {
    values: void 0,
    source: buildSource({
      scope: "default",
      key: "tools.sandbox.tools.allow"
    })
  };
}
function pickConfiguredDeny(params) {
  if (Array.isArray(params.agent)) return {
    values: params.agent,
    source: buildSource({
      scope: "agent",
      key: "agents.list[].tools.sandbox.tools.deny"
    })
  };
  if (Array.isArray(params.global)) return {
    values: params.global,
    source: buildSource({
      scope: "global",
      key: "tools.sandbox.tools.deny"
    })
  };
  return {
    values: void 0,
    source: buildSource({
      scope: "default",
      key: "tools.sandbox.tools.deny"
    })
  };
}
function pickConfiguredAlsoAllow(params) {
  if (Array.isArray(params.agent)) return {
    values: params.agent,
    source: buildSource({
      scope: "agent",
      key: "agents.list[].tools.sandbox.tools.alsoAllow"
    })
  };
  if (Array.isArray(params.global)) return {
    values: params.global,
    source: buildSource({
      scope: "global",
      key: "tools.sandbox.tools.alsoAllow"
    })
  };
  return {
    values: void 0,
    source: void 0
  };
}
function mergeAllowlist(base, extra) {
  if (Array.isArray(base)) {
    if (base.length === 0) return [];
    if (!Array.isArray(extra) || extra.length === 0) return [...base];
    return Array.from(new Set([...base, ...extra]));
  }
  if (Array.isArray(extra) && extra.length > 0) return Array.from(new Set([..._constantsBy80hBjs.h, ...extra]));
  return [..._constantsBy80hBjs.h];
}
function pickAllowSource(params) {
  if (params.allowDefined && params.allow.source === "agent") return params.allow;
  if (params.alsoAllow?.source === "agent") return params.alsoAllow;
  if (params.allowDefined && params.allow.source === "global") return params.allow;
  if (params.alsoAllow?.source === "global") return params.alsoAllow;
  return params.allow;
}
function resolveExplicitSandboxReAllowPatterns(params) {
  return Array.from(new Set([...(params.allow ?? []), ...(params.alsoAllow ?? [])]));
}
function filterDefaultDenyForExplicitAllows(params) {
  if (params.explicitAllowPatterns.length === 0) return [...params.deny];
  const allowPatterns = (0, _globPatternCrqljM7B.t)({
    raw: (0, _toolPolicyCOX5DaEj.f)(params.explicitAllowPatterns),
    normalize: _toolPolicyCOX5DaEj.m
  });
  if (allowPatterns.length === 0) return [...params.deny];
  return params.deny.filter((toolName) => !(0, _globPatternCrqljM7B.n)((0, _toolPolicyCOX5DaEj.m)(toolName), allowPatterns));
}
function expandResolvedPolicy(policy) {
  const expandedDeny = (0, _toolPolicyCOX5DaEj.f)(policy.deny ?? []);
  let expandedAllow = (0, _toolPolicyCOX5DaEj.f)(policy.allow ?? []);
  const expandedDenyLower = expandedDeny.map(_stringCoerceDyL154ka.a);
  const expandedAllowLower = expandedAllow.map(_stringCoerceDyL154ka.a);
  if (expandedAllow.length > 0 && !expandedDenyLower.includes("image") && !expandedAllowLower.includes("image")) expandedAllow = [...expandedAllow, "image"];
  return {
    allow: expandedAllow,
    deny: expandedDeny
  };
}
function classifyToolAgainstSandboxToolPolicy(name, policy) {
  if (!policy) return {
    blockedByDeny: false,
    blockedByAllow: false
  };
  const normalized = (0, _toolPolicyCOX5DaEj.m)(name);
  const blockedByDeny = (0, _globPatternCrqljM7B.n)(normalized, (0, _globPatternCrqljM7B.t)({
    raw: (0, _toolPolicyCOX5DaEj.f)(policy.deny ?? []),
    normalize: _toolPolicyCOX5DaEj.m
  }));
  const allow = (0, _globPatternCrqljM7B.t)({
    raw: (0, _toolPolicyCOX5DaEj.f)(policy.allow ?? []),
    normalize: _toolPolicyCOX5DaEj.m
  });
  return {
    blockedByDeny,
    blockedByAllow: !blockedByDeny && allow.length > 0 && !(0, _globPatternCrqljM7B.n)(normalized, allow)
  };
}
function isToolAllowed(policy, name) {
  const { blockedByDeny, blockedByAllow } = classifyToolAgainstSandboxToolPolicy(name, policy);
  return !blockedByDeny && !blockedByAllow;
}
function resolveSandboxToolPolicyForAgent(cfg, agentId) {
  const agentPolicy = (cfg && agentId ? (0, _agentScopeConfigCMp71_.r)(cfg, agentId) : void 0)?.tools?.sandbox?.tools;
  const globalPolicy = cfg?.tools?.sandbox?.tools;
  const allowConfig = pickConfiguredList({
    agent: agentPolicy?.allow,
    global: globalPolicy?.allow
  });
  const alsoAllowConfig = pickConfiguredAlsoAllow({
    agent: agentPolicy?.alsoAllow,
    global: globalPolicy?.alsoAllow
  });
  const denyConfig = pickConfiguredDeny({
    agent: agentPolicy?.deny,
    global: globalPolicy?.deny
  });
  const explicitAllowPatterns = resolveExplicitSandboxReAllowPatterns({
    allow: allowConfig.values,
    alsoAllow: alsoAllowConfig.values
  });
  const expanded = expandResolvedPolicy({
    allow: mergeAllowlist(allowConfig.values, alsoAllowConfig.values),
    deny: Array.isArray(denyConfig.values) ? [...denyConfig.values] : filterDefaultDenyForExplicitAllows({
      deny: [..._constantsBy80hBjs.g],
      explicitAllowPatterns
    })
  });
  return {
    allow: expanded.allow ?? [],
    deny: expanded.deny ?? [],
    sources: {
      allow: pickAllowSource({
        allow: allowConfig.source,
        allowDefined: Array.isArray(allowConfig.values),
        alsoAllow: alsoAllowConfig.source
      }),
      deny: denyConfig.source
    }
  };
}
//#endregion /* v9-4cd415a9d2f29250 */
