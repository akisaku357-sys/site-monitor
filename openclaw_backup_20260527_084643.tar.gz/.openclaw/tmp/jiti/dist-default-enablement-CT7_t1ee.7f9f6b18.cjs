"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.t = isPluginEnabledByDefaultForPlatform; //#region src/plugins/default-enablement.ts
function isPluginEnabledByDefaultForPlatform(plugin, platform = process.platform) {
  if (plugin.enabledByDefault === true) return true;
  return plugin.enabledByDefaultOnPlatforms?.includes(platform) === true;
}
//#endregion /* v9-d04e67c6f78ea844 */
