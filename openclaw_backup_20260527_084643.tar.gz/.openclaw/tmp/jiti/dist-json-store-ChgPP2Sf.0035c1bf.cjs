"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.i = writeJsonFileAtomically;exports.n = readJsonFileWithFallback;exports.r = void 0;exports.t = loadJsonFile;require("./fs-safe-defaults-B7hUN42l.js");
var _fsSafeCV86zY9G = require("./fs-safe-CV86zY9G.js");
var _jsonFilesC2hqjU = require("./json-files-C2hqjU--.js");
//#region src/plugin-sdk/json-store.ts
/** Read small JSON blobs synchronously for token/state caches. */
function loadJsonFile(filePath) {
  return (0, _jsonFilesC2hqjU.p)(filePath) ?? void 0;
}
/** Persist small JSON blobs synchronously with restrictive permissions. */
const saveJsonFile = exports.r = _jsonFilesC2hqjU.h;
/** Read JSON from disk and fall back cleanly when the file is missing or invalid. */
async function readJsonFileWithFallback(filePath, fallback) {
  const parsed = await (0, _jsonFilesC2hqjU.o)(filePath);
  if (parsed != null) return {
    value: parsed,
    exists: true
  };
  return {
    value: fallback,
    exists: await (0, _fsSafeCV86zY9G.E)(filePath)
  };
}
/** Write JSON with secure file permissions and atomic replacement semantics. */
async function writeJsonFileAtomically(filePath, value) {
  await (0, _jsonFilesC2hqjU.m)(filePath, value, {
    mode: 384,
    dirMode: 448,
    trailingNewline: true
  });
}
//#endregion /* v9-88adaa5016b8909a */
