"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.guardGroupCommand = void 0;





var _member = require("../../../infra/cache/member.js");
var _transport = require("../../../infra/transport.js");
var _index = require("../../messaging/handlers/index.js"); /**
 * Middleware: group command whitelist guard.
 *
 * Only applies to registered openclaw commands; non-public commands are owner-only.
 * Unregistered /xxx messages (e.g. /asdasdasd) are treated as plain text for AI.
 */ /** Public commands available to all group members */const GROUP_PUBLIC_COMMANDS = new Set([]);const guardGroupCommand = exports.guardGroupCommand = { name: "guard-group-command", when: (ctx) => ctx.isGroup,
  handler: async (ctx, next) => {
    const { core, config, rawBody, raw, account, groupCode, fromAccount } = ctx;
    const q = rawBody.trim().split(/\s+/).
    find((part) => !part.trim().startsWith("@")) || rawBody;
    const hasRegisteredCommand = core.channel.text.hasControlCommand(q, config);
    const isOwner = Boolean(raw.bot_owner_id && raw.from_account === raw.bot_owner_id);
    const cmdMatch = q.trim().match(/^\/([a-z_-]+)/i);
    ctx.log.info('[guard-group-command] come in', { hasRegisteredCommand, isOwner, isCmd: !!cmdMatch });
    if (hasRegisteredCommand && cmdMatch) {
      const cmdName = cmdMatch[1].toLowerCase();
      if (!GROUP_PUBLIC_COMMANDS.has(cmdName) && !isOwner) {
        await (0, _transport.sendGroupMsgBody)({
          account,
          groupCode: groupCode,
          msgBody: (0, _index.buildOutboundMsgBody)((0, _index.prepareOutboundContent)(`⚠️ /${cmdName} 仅限创建者${!raw?.bot_owner_id ? "并且在私聊模式下" : ""}使用哦~`, groupCode, (0, _member.getMember)(account.accountId))),
          fromAccount: account.botId,
          refMsgId: raw.msg_id || raw.msg_key || undefined,
          refFromAccount: fromAccount,
          wsClient: ctx.wsClient
        });
        return; // Abort pipeline
      }
    }
    await next();
  }
}; /* v9-5724b1808f0e6c3f */
