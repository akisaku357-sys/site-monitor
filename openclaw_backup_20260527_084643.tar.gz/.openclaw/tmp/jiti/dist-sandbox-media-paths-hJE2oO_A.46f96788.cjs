"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = resolveSandboxedBridgeMediaPath;exports.t = createSandboxBridgeReadFile;var _sandboxPathsBTYunIeX = require("./sandbox-paths-BTYunIeX.js");
var _nodePath = _interopRequireDefault(require("node:path"));function _interopRequireDefault(e) {return e && e.__esModule ? e : { default: e };}
//#region src/agents/sandbox-media-paths.ts
function createSandboxBridgeReadFile(params) {
  return async (filePath) => await params.sandbox.bridge.readFile({
    filePath,
    cwd: params.sandbox.root
  });
}
async function resolveSandboxedBridgeMediaPath(params) {
  const normalizeFileUrl = (rawPath) => rawPath.startsWith("file://") ? rawPath.slice(7) : rawPath;
  const filePath = normalizeFileUrl(params.mediaPath);
  const enforceWorkspaceBoundary = async (hostPath) => {
    if (!params.sandbox.workspaceOnly) return;
    await (0, _sandboxPathsBTYunIeX.n)({
      filePath: hostPath,
      cwd: params.sandbox.root,
      root: params.sandbox.root
    });
  };
  const resolveDirect = () => params.sandbox.bridge.resolvePath({
    filePath,
    cwd: params.sandbox.root
  });
  try {
    const resolved = resolveDirect();
    if (resolved.hostPath) await enforceWorkspaceBoundary(resolved.hostPath);
    return { resolved: resolved.hostPath ?? resolved.containerPath };
  } catch (err) {
    const fallbackDir = params.inboundFallbackDir?.trim();
    if (!fallbackDir) throw err;
    const fallbackPath = _nodePath.default.join(fallbackDir, _nodePath.default.basename(filePath));
    try {
      if (!(await params.sandbox.bridge.stat({
        filePath: fallbackPath,
        cwd: params.sandbox.root
      }))) throw err;
    } catch {
      throw err;
    }
    const resolvedFallback = params.sandbox.bridge.resolvePath({
      filePath: fallbackPath,
      cwd: params.sandbox.root
    });
    if (resolvedFallback.hostPath) await enforceWorkspaceBoundary(resolvedFallback.hostPath);
    return {
      resolved: resolvedFallback.hostPath ?? resolvedFallback.containerPath,
      rewrittenFrom: filePath
    };
  }
}
//#endregion /* v9-f5dda2b9e8adf6e9 */
