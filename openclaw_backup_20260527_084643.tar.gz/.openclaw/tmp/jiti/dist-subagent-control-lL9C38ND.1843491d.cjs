"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.a = killSubagentRunAdmin;exports.c = resolveSubagentController;exports.i = killControlledSubagentRun;exports.l = sendControlledSubagentMessage;exports.n = void 0;exports.o = listControlledSubagentRuns;exports.r = killAllControlledSubagentRuns;exports.s = resolveControlledSubagentTarget;exports.t = void 0;exports.u = steerControlledSubagentRun;var _errorsB3ZrCRlt = require("./errors-b3ZrCRlt.js");
var _lazyPromiseDjskx0qC = require("./lazy-promise-Djskx0qC.js");
var _sessionKeyUtilsCe_xWkNq = require("./session-key-utils-Ce_xWkNq.js");
var _globalsYU5FjfZK = require("./globals-YU5FjfZK.js");
var _messageChannelCoreBoUoCGOD = require("./message-channel-core-BoUoCGOD.js");
require("./message-channel-CYCKkVrh.js");
var _callT1U2G3yY = require("./call-t1U2G3yY.js");
var _pathsBg3PO6Gj = require("./paths-Bg3PO6Gj.js");
var _storeLoadZ4thf6ld = require("./store-load-z4thf6ld.js");
var _storeBmtchQvp = require("./store-BmtchQvp.js");
var _subagentRegistryStateDbOPrqYx = require("./subagent-registry-state-DbOPrqYx.js");
var _subagentRegistryRead0y5BjaUV = require("./subagent-registry-read-0y5BjaUV.js");
var _subagentCapabilitiesMB73wM9t = require("./subagent-capabilities-mB73wM9t.js");
var _sessionsHelpersAhiZZPDz = require("./sessions-helpers-AhiZZPDz.js");
var _lanesReZ09_e = require("./lanes-ReZ09_e4.js");
var _runWaitBlZoP48F = require("./run-wait-BlZoP48F.js");
var _subagentRegistryQwuPQSxK = require("./subagent-registry-QwuPQSxK.js");
var _subagentsUtilsB4IBbOXw = require("./subagents-utils-B4IBbOXw.js");
var _subagentListGHsV668o = require("./subagent-list-GHsV668o.js");
var _nodeCrypto = _interopRequireDefault(require("node:crypto"));function _interopRequireDefault(e) {return e && e.__esModule ? e : { default: e };}function _interopRequireWildcard(e, t) {if ("function" == typeof WeakMap) var r = new WeakMap(),n = new WeakMap();return (_interopRequireWildcard = function (e, t) {if (!t && e && e.__esModule) return e;var o,i,f = { __proto__: null, default: e };if (null === e || "object" != typeof e && "function" != typeof e) return f;if (o = t ? n : r) {if (o.has(e)) return o.get(e);o.set(e, f);}for (const t in e) "default" !== t && {}.hasOwnProperty.call(e, t) && ((i = (o = Object.defineProperty) && Object.getOwnPropertyDescriptor(e, t)) && (i.get || i.set) ? o(f, t, i) : f[t] = e[t]);return f;})(e, t);}
const MAX_RECENT_MINUTES = exports.t = 1440;
const MAX_STEER_MESSAGE_CHARS = exports.n = 4e3;
const STEER_RATE_LIMIT_MS = 2e3;
const STEER_ABORT_SETTLE_TIMEOUT_MS = 5e3;
const SUBAGENT_REPLY_HISTORY_LIMIT = 50;
const steerRateLimit = /* @__PURE__ */new Map();
let subagentControlDeps = {
  callGateway: _callT1U2G3yY.r,
  updateSessionStore: _storeBmtchQvp.u
};
const subagentControlRuntimeLoader = (0, _lazyPromiseDjskx0qC.t)(() => Promise.resolve().then(() => jitiImport("./subagent-control.runtime.js").then((m) => _interopRequireWildcard(m))));
function loadSubagentControlRuntime() {
  return subagentControlRuntimeLoader.load();
}
async function resolveSubagentControlRuntime() {
  if (subagentControlDeps.abortEmbeddedPiRun && subagentControlDeps.clearSessionQueues) return {
    abortEmbeddedPiRun: subagentControlDeps.abortEmbeddedPiRun,
    clearSessionQueues: subagentControlDeps.clearSessionQueues
  };
  const runtime = await loadSubagentControlRuntime();
  return {
    abortEmbeddedPiRun: subagentControlDeps.abortEmbeddedPiRun ?? runtime.abortEmbeddedPiRun,
    clearSessionQueues: subagentControlDeps.clearSessionQueues ?? runtime.clearSessionQueues
  };
}
function resolveSubagentController(params) {
  const { mainKey, alias } = (0, _sessionsHelpersAhiZZPDz.c)(params.cfg);
  const callerSessionKey = (0, _sessionsHelpersAhiZZPDz.s)({
    key: params.agentSessionKey?.trim() || alias,
    alias,
    mainKey
  });
  if (!(0, _sessionKeyUtilsCe_xWkNq.a)(callerSessionKey)) return {
    controllerSessionKey: callerSessionKey,
    callerSessionKey,
    callerIsSubagent: false,
    controlScope: "children"
  };
  return {
    controllerSessionKey: callerSessionKey,
    callerSessionKey,
    callerIsSubagent: true,
    controlScope: (0, _subagentCapabilitiesMB73wM9t.n)(callerSessionKey, { cfg: params.cfg }).controlScope
  };
}
function listControlledSubagentRuns(controllerSessionKey) {
  const key = controllerSessionKey.trim();
  if (!key) return [];
  const latestByChildSessionKey = (0, _subagentListGHsV668o.t)((0, _subagentRegistryStateDbOPrqYx.t)(_subagentRegistryStateDbOPrqYx.M)).latestByChildSessionKey;
  return (0, _subagentsUtilsB4IBbOXw.a)(Array.from(latestByChildSessionKey.values()).filter((entry) => {
    return (entry.controllerSessionKey?.trim() || entry.requesterSessionKey?.trim()) === key;
  }));
}
function ensureControllerOwnsRun(params) {
  if ((params.entry.controllerSessionKey?.trim() || params.entry.requesterSessionKey) === params.controller.controllerSessionKey) return;
  return "Subagents can only control runs spawned from their own session.";
}
async function killSubagentRun(params) {
  if (params.entry.endedAt) return { killed: false };
  const childSessionKey = params.entry.childSessionKey;
  const resolved = (0, _subagentListGHsV668o.a)({
    cfg: params.cfg,
    key: childSessionKey,
    cache: params.cache
  });
  const sessionId = resolved.entry?.sessionId;
  const runtime = await resolveSubagentControlRuntime();
  const aborted = sessionId ? runtime.abortEmbeddedPiRun(sessionId) : false;
  const cleared = runtime.clearSessionQueues([childSessionKey, sessionId]);
  if (cleared.followupCleared > 0 || cleared.laneCleared > 0) (0, _globalsYU5FjfZK.r)(`subagents control kill: cleared followups=${cleared.followupCleared} lane=${cleared.laneCleared} keys=${cleared.keys.join(",")}`);
  if (resolved.entry) try {
    await subagentControlDeps.updateSessionStore(resolved.storePath, (store) => {
      const current = store[childSessionKey];
      if (!current) return;
      current.abortedLastRun = true;
      current.updatedAt = Date.now();
      store[childSessionKey] = current;
    });
  } catch (error) {
    (0, _globalsYU5FjfZK.r)(`subagents control kill: failed to persist abortedLastRun for ${childSessionKey}: ${(0, _errorsB3ZrCRlt.i)(error)}`);
  }
  return {
    killed: (0, _subagentRegistryQwuPQSxK.f)({
      runId: params.entry.runId,
      childSessionKey,
      reason: "killed"
    }) > 0 || aborted || cleared.followupCleared > 0 || cleared.laneCleared > 0,
    sessionId
  };
}
async function cascadeKillChildren(params) {
  const childRunsBySessionKey = /* @__PURE__ */new Map();
  for (const run of (0, _subagentRegistryRead0y5BjaUV.s)(params.parentChildSessionKey)) {
    const childKey = run.childSessionKey?.trim();
    if (!childKey) continue;
    const latest = (0, _subagentRegistryRead0y5BjaUV.r)(childKey);
    const latestControllerSessionKey = latest?.controllerSessionKey?.trim() || latest?.requesterSessionKey?.trim();
    if (!latest || latest.runId !== run.runId || latestControllerSessionKey !== params.parentChildSessionKey) continue;
    const existing = childRunsBySessionKey.get(childKey);
    if (!existing || run.createdAt >= existing.createdAt) childRunsBySessionKey.set(childKey, run);
  }
  const childRuns = Array.from(childRunsBySessionKey.values());
  const seenChildSessionKeys = params.seenChildSessionKeys ?? /* @__PURE__ */new Set();
  let killed = 0;
  const labels = [];
  for (const run of childRuns) {
    const childKey = run.childSessionKey?.trim();
    if (!childKey || seenChildSessionKeys.has(childKey)) continue;
    seenChildSessionKeys.add(childKey);
    if (!run.endedAt) {
      if ((await killSubagentRun({
        cfg: params.cfg,
        entry: run,
        cache: params.cache
      })).killed) {
        killed += 1;
        labels.push((0, _subagentsUtilsB4IBbOXw.r)(run));
      }
    }
    const cascade = await cascadeKillChildren({
      cfg: params.cfg,
      parentChildSessionKey: childKey,
      cache: params.cache,
      seenChildSessionKeys
    });
    killed += cascade.killed;
    labels.push(...cascade.labels);
  }
  return {
    killed,
    labels
  };
}
async function killAllControlledSubagentRuns(params) {
  if (params.controller.controlScope !== "children") return {
    status: "forbidden",
    error: "Leaf subagents cannot control other sessions.",
    killed: 0,
    labels: []
  };
  const cache = /* @__PURE__ */new Map();
  const seenChildSessionKeys = /* @__PURE__ */new Set();
  const killedLabels = [];
  let killed = 0;
  for (const entry of params.runs) {
    const childKey = entry.childSessionKey?.trim();
    if (!childKey || seenChildSessionKeys.has(childKey)) continue;
    const currentEntry = (0, _subagentRegistryRead0y5BjaUV.r)(childKey);
    if (!currentEntry || currentEntry.runId !== entry.runId) continue;
    seenChildSessionKeys.add(childKey);
    if (!currentEntry.endedAt) {
      if ((await killSubagentRun({
        cfg: params.cfg,
        entry: currentEntry,
        cache
      })).killed) {
        killed += 1;
        killedLabels.push((0, _subagentsUtilsB4IBbOXw.r)(currentEntry));
      }
    }
    const cascade = await cascadeKillChildren({
      cfg: params.cfg,
      parentChildSessionKey: childKey,
      cache,
      seenChildSessionKeys
    });
    killed += cascade.killed;
    killedLabels.push(...cascade.labels);
  }
  return {
    status: "ok",
    killed,
    labels: killedLabels
  };
}
async function killControlledSubagentRun(params) {
  const ownershipError = ensureControllerOwnsRun({
    controller: params.controller,
    entry: params.entry
  });
  if (ownershipError) return {
    status: "forbidden",
    runId: params.entry.runId,
    sessionKey: params.entry.childSessionKey,
    error: ownershipError
  };
  if (params.controller.controlScope !== "children") return {
    status: "forbidden",
    runId: params.entry.runId,
    sessionKey: params.entry.childSessionKey,
    error: "Leaf subagents cannot control other sessions."
  };
  const currentEntry = (0, _subagentRegistryRead0y5BjaUV.r)(params.entry.childSessionKey);
  if (!currentEntry || currentEntry.runId !== params.entry.runId) return {
    status: "done",
    runId: params.entry.runId,
    sessionKey: params.entry.childSessionKey,
    label: (0, _subagentsUtilsB4IBbOXw.r)(params.entry),
    text: `${(0, _subagentsUtilsB4IBbOXw.r)(params.entry)} is already finished.`
  };
  const killCache = /* @__PURE__ */new Map();
  const stopResult = await killSubagentRun({
    cfg: params.cfg,
    entry: currentEntry,
    cache: killCache
  });
  const seenChildSessionKeys = /* @__PURE__ */new Set();
  const targetChildKey = params.entry.childSessionKey?.trim();
  if (targetChildKey) seenChildSessionKeys.add(targetChildKey);
  const cascade = await cascadeKillChildren({
    cfg: params.cfg,
    parentChildSessionKey: params.entry.childSessionKey,
    cache: killCache,
    seenChildSessionKeys
  });
  if (!stopResult.killed && cascade.killed === 0) return {
    status: "done",
    runId: params.entry.runId,
    sessionKey: params.entry.childSessionKey,
    label: (0, _subagentsUtilsB4IBbOXw.r)(params.entry),
    text: `${(0, _subagentsUtilsB4IBbOXw.r)(params.entry)} is already finished.`
  };
  const cascadeText = cascade.killed > 0 ? ` (+ ${cascade.killed} descendant${cascade.killed === 1 ? "" : "s"})` : "";
  return {
    status: "ok",
    runId: params.entry.runId,
    sessionKey: params.entry.childSessionKey,
    label: (0, _subagentsUtilsB4IBbOXw.r)(params.entry),
    cascadeKilled: cascade.killed,
    cascadeLabels: cascade.killed > 0 ? cascade.labels : void 0,
    text: stopResult.killed ? `killed ${(0, _subagentsUtilsB4IBbOXw.r)(params.entry)}${cascadeText}.` : `killed ${cascade.killed} descendant${cascade.killed === 1 ? "" : "s"} of ${(0, _subagentsUtilsB4IBbOXw.r)(params.entry)}.`
  };
}
async function killSubagentRunAdmin(params) {
  const targetSessionKey = params.sessionKey.trim();
  if (!targetSessionKey) return {
    found: false,
    killed: false
  };
  const entry = (0, _subagentRegistryRead0y5BjaUV.r)(targetSessionKey);
  if (!entry) return {
    found: false,
    killed: false
  };
  const killCache = /* @__PURE__ */new Map();
  const stopResult = await killSubagentRun({
    cfg: params.cfg,
    entry,
    cache: killCache
  });
  const seenChildSessionKeys = new Set([targetSessionKey]);
  const cascade = await cascadeKillChildren({
    cfg: params.cfg,
    parentChildSessionKey: targetSessionKey,
    cache: killCache,
    seenChildSessionKeys
  });
  return {
    found: true,
    killed: stopResult.killed || cascade.killed > 0,
    runId: entry.runId,
    sessionKey: entry.childSessionKey,
    cascadeKilled: cascade.killed,
    cascadeLabels: cascade.killed > 0 ? cascade.labels : void 0
  };
}
async function steerControlledSubagentRun(params) {
  const ownershipError = ensureControllerOwnsRun({
    controller: params.controller,
    entry: params.entry
  });
  if (ownershipError) return {
    status: "forbidden",
    runId: params.entry.runId,
    sessionKey: params.entry.childSessionKey,
    error: ownershipError
  };
  if (params.controller.controlScope !== "children") return {
    status: "forbidden",
    runId: params.entry.runId,
    sessionKey: params.entry.childSessionKey,
    error: "Leaf subagents cannot control other sessions."
  };
  const targetHasPendingDescendants = (0, _subagentRegistryQwuPQSxK.i)(params.entry.childSessionKey) > 0;
  if (params.entry.endedAt && !targetHasPendingDescendants) return {
    status: "done",
    runId: params.entry.runId,
    sessionKey: params.entry.childSessionKey,
    text: `${(0, _subagentsUtilsB4IBbOXw.r)(params.entry)} is already finished.`
  };
  if (params.controller.callerSessionKey === params.entry.childSessionKey) return {
    status: "forbidden",
    runId: params.entry.runId,
    sessionKey: params.entry.childSessionKey,
    error: "Subagents cannot steer themselves."
  };
  const currentEntry = (0, _subagentRegistryRead0y5BjaUV.r)(params.entry.childSessionKey);
  const currentHasPendingDescendants = currentEntry && (0, _subagentRegistryQwuPQSxK.i)(currentEntry.childSessionKey) > 0;
  if (!currentEntry || currentEntry.runId !== params.entry.runId || currentEntry.endedAt && !currentHasPendingDescendants) return {
    status: "done",
    runId: params.entry.runId,
    sessionKey: params.entry.childSessionKey,
    text: `${(0, _subagentsUtilsB4IBbOXw.r)(params.entry)} is already finished.`
  };
  const rateKey = `${params.controller.callerSessionKey}:${params.entry.childSessionKey}`;
  if (process.env.VITEST !== "true") {
    const now = Date.now();
    if (now - (steerRateLimit.get(rateKey) ?? 0) < STEER_RATE_LIMIT_MS) return {
      status: "rate_limited",
      runId: params.entry.runId,
      sessionKey: params.entry.childSessionKey,
      error: "Steer rate limit exceeded. Wait a moment before sending another steer."
    };
    steerRateLimit.set(rateKey, now);
  }
  (0, _subagentRegistryQwuPQSxK.d)(params.entry.runId);
  const targetSession = (0, _subagentListGHsV668o.a)({
    cfg: params.cfg,
    key: params.entry.childSessionKey,
    cache: /* @__PURE__ */new Map()
  });
  const sessionId = typeof targetSession.entry?.sessionId === "string" && targetSession.entry.sessionId.trim() ? targetSession.entry.sessionId.trim() : void 0;
  if (sessionId) (await resolveSubagentControlRuntime()).abortEmbeddedPiRun(sessionId);
  const cleared = (await resolveSubagentControlRuntime()).clearSessionQueues([params.entry.childSessionKey, sessionId]);
  if (cleared.followupCleared > 0 || cleared.laneCleared > 0) (0, _globalsYU5FjfZK.r)(`subagents control steer: cleared followups=${cleared.followupCleared} lane=${cleared.laneCleared} keys=${cleared.keys.join(",")}`);
  try {
    await subagentControlDeps.callGateway({
      method: "agent.wait",
      params: {
        runId: params.entry.runId,
        timeoutMs: STEER_ABORT_SETTLE_TIMEOUT_MS
      },
      timeoutMs: 7e3
    });
  } catch {}
  const idempotencyKey = _nodeCrypto.default.randomUUID();
  let runId = idempotencyKey;
  try {
    const response = await subagentControlDeps.callGateway({
      method: "agent",
      params: {
        message: params.message,
        sessionKey: params.entry.childSessionKey,
        sessionId,
        idempotencyKey,
        deliver: false,
        channel: _messageChannelCoreBoUoCGOD.r,
        lane: _lanesReZ09_e.t,
        timeout: 0
      },
      timeoutMs: 1e4
    });
    if (typeof response?.runId === "string" && response.runId) runId = response.runId;
  } catch (err) {
    (0, _subagentRegistryQwuPQSxK.t)(params.entry.runId);
    const error = (0, _errorsB3ZrCRlt.i)(err);
    return {
      status: "error",
      runId,
      sessionKey: params.entry.childSessionKey,
      sessionId,
      error
    };
  }
  if (!(0, _subagentRegistryQwuPQSxK.m)({
    previousRunId: params.entry.runId,
    nextRunId: runId,
    fallback: params.entry,
    runTimeoutSeconds: params.entry.runTimeoutSeconds ?? 0
  })) {
    (0, _subagentRegistryQwuPQSxK.t)(params.entry.runId);
    return {
      status: "error",
      runId,
      sessionKey: params.entry.childSessionKey,
      sessionId,
      error: "failed to replace steered subagent run"
    };
  }
  return {
    status: "accepted",
    runId,
    sessionKey: params.entry.childSessionKey,
    sessionId,
    mode: "restart",
    label: (0, _subagentsUtilsB4IBbOXw.r)(params.entry),
    text: `steered ${(0, _subagentsUtilsB4IBbOXw.r)(params.entry)}.`
  };
}
async function sendControlledSubagentMessage(params) {
  const ownershipError = ensureControllerOwnsRun({
    controller: params.controller,
    entry: params.entry
  });
  if (ownershipError) return {
    status: "forbidden",
    error: ownershipError
  };
  if (params.controller.controlScope !== "children") return {
    status: "forbidden",
    error: "Leaf subagents cannot control other sessions."
  };
  const currentEntry = (0, _subagentRegistryRead0y5BjaUV.r)(params.entry.childSessionKey);
  if (!currentEntry || currentEntry.runId !== params.entry.runId) return {
    status: "done",
    runId: params.entry.runId,
    text: `${(0, _subagentsUtilsB4IBbOXw.r)(params.entry)} is already finished.`
  };
  const targetSessionKey = params.entry.childSessionKey;
  const parsed = (0, _sessionKeyUtilsCe_xWkNq.c)(targetSessionKey);
  const targetSessionEntry = (0, _storeLoadZ4thf6ld.t)((0, _pathsBg3PO6Gj.u)(params.cfg.session?.store, { agentId: parsed?.agentId }))[targetSessionKey];
  const targetSessionId = typeof targetSessionEntry?.sessionId === "string" && targetSessionEntry.sessionId.trim() ? targetSessionEntry.sessionId.trim() : void 0;
  const idempotencyKey = _nodeCrypto.default.randomUUID();
  let runId = idempotencyKey;
  try {
    const baselineReply = await (0, _runWaitBlZoP48F.r)({
      sessionKey: targetSessionKey,
      limit: SUBAGENT_REPLY_HISTORY_LIMIT,
      callGateway: subagentControlDeps.callGateway
    });
    const response = await subagentControlDeps.callGateway({
      method: "agent",
      params: {
        message: params.message,
        sessionKey: targetSessionKey,
        sessionId: targetSessionId,
        idempotencyKey,
        deliver: false,
        channel: _messageChannelCoreBoUoCGOD.r,
        lane: _lanesReZ09_e.t,
        timeout: 0
      },
      timeoutMs: 1e4
    });
    const responseRunId = typeof response?.runId === "string" ? response.runId : void 0;
    if (responseRunId) runId = responseRunId;
    const result = await (0, _runWaitBlZoP48F.a)({
      runId,
      sessionKey: targetSessionKey,
      timeoutMs: 3e4,
      limit: SUBAGENT_REPLY_HISTORY_LIMIT,
      baseline: baselineReply,
      callGateway: subagentControlDeps.callGateway
    });
    if (result.status === "timeout") return {
      status: "timeout",
      runId
    };
    if (result.status === "error") return {
      status: "error",
      runId,
      error: result.error ?? "unknown error"
    };
    return {
      status: "ok",
      runId,
      replyText: result.replyText
    };
  } catch (err) {
    const error = (0, _errorsB3ZrCRlt.i)(err);
    return {
      status: "error",
      runId,
      error
    };
  }
}
function resolveControlledSubagentTarget(runs, token, options) {
  return (0, _subagentsUtilsB4IBbOXw.i)({
    runs,
    token,
    recentWindowMinutes: options?.recentMinutes ?? 30,
    label: (entry) => (0, _subagentsUtilsB4IBbOXw.r)(entry),
    aliases: (entry) => entry.taskName ? [entry.taskName] : [],
    isActive: options?.isActive,
    errors: {
      missingTarget: "Missing subagent target.",
      invalidIndex: (value) => `Invalid subagent index: ${value}`,
      unknownSession: (value) => `Unknown subagent session: ${value}`,
      ambiguousLabel: (value) => `Ambiguous subagent label: ${value}`,
      ambiguousLabelPrefix: (value) => `Ambiguous subagent label prefix: ${value}`,
      ambiguousRunIdPrefix: (value) => `Ambiguous subagent run id prefix: ${value}`,
      unknownTarget: (value) => `Unknown subagent target: ${value}`
    }
  });
}
//#endregion /* v9-d16b7022028d2471 */
