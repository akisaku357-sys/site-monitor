"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.i = isKnownNativeApprovalPromptChannel;exports.n = channelPluginHasNativeApprovalPromptUi;exports.r = hasNativeApprovalPromptRuntimeCapability;exports.t = void 0;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _pluginsDYTHbmt = require("./plugins-DYTHbmt7.js");
//#region src/channels/plugins/native-approval-prompt.ts
const NATIVE_APPROVAL_PROMPT_RUNTIME_CAPABILITY = exports.t = "nativeApprovals";
const NATIVE_APPROVAL_PROMPT_RUNTIME_CAPABILITY_NORMALIZED = "nativeapprovals";
const KNOWN_NATIVE_APPROVAL_PROMPT_CHANNELS = new Set([
"discord",
"matrix",
"qqbot",
"slack",
"telegram"]
);
function channelPluginHasNativeApprovalPromptUi(plugin) {
  const capability = (0, _pluginsDYTHbmt.n)(plugin);
  return Boolean(capability?.native || capability?.nativeRuntime);
}
function isKnownNativeApprovalPromptChannel(channel) {
  const normalized = (0, _stringCoerceDyL154ka.s)(channel);
  return Boolean(normalized && KNOWN_NATIVE_APPROVAL_PROMPT_CHANNELS.has(normalized));
}
function hasNativeApprovalPromptRuntimeCapability(capabilities) {
  return Boolean(capabilities?.some((capability) => (0, _stringCoerceDyL154ka.s)(capability) === NATIVE_APPROVAL_PROMPT_RUNTIME_CAPABILITY_NORMALIZED));
}
//#endregion /* v9-345636d0cf9cbca6 */
