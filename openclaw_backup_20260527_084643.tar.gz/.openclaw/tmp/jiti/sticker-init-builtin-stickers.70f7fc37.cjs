"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.initBuiltinStickers = initBuiltinStickers;





var _builtinStickers = _interopRequireDefault(require("./builtin-stickers.json"));
var _stickerCache = require("./sticker-cache.js");function _interopRequireDefault(e) {return e && e.__esModule ? e : { default: e };} /**
 * Write built-in stickers to cache on startup.
 *
 * Called once in index.ts register().
 * Builtin entries are only written when not yet cached; they won't overwrite user received data.
 */ /**
 * Write the built-in sticker list to local cache on process startup.
 * Uses `cacheStickers` for batch write; builtin-sourced entries won't overwrite existing received data.
 */function initBuiltinStickers() {const now = new Date().toISOString();const list = _builtinStickers.default;const stickers = list.map((s) => ({
    sticker_id: s.emoji_id,
    package_id: s.emoji_pack_id,
    name: s.name,
    description: s.description?.trim() ? `${s.name} ${s.description.trim()}` : s.name,
    cachedAt: now,
    source: "builtin",
    width: s.width,
    height: s.height,
    formats: s.formats
  }));
  (0, _stickerCache.cacheStickers)(stickers);
} /* v9-f75aa5791217e55b */
