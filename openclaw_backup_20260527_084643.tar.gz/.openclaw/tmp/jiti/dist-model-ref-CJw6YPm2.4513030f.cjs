"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.t = parseGenerationModelRef;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
//#region src/media-generation/model-ref.ts
function parseGenerationModelRef(raw) {
  const trimmed = (0, _stringCoerceDyL154ka.c)(raw);
  if (!trimmed) return null;
  const slashIndex = trimmed.indexOf("/");
  if (slashIndex <= 0 || slashIndex === trimmed.length - 1) return null;
  const provider = (0, _stringCoerceDyL154ka.c)(trimmed.slice(0, slashIndex));
  const model = (0, _stringCoerceDyL154ka.c)(trimmed.slice(slashIndex + 1));
  if (!provider || !model) return null;
  return {
    provider,
    model
  };
}
//#endregion /* v9-d8e12d556635fb45 */
