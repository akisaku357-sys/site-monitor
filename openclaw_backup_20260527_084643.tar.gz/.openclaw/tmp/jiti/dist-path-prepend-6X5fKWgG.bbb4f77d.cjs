"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.a = removePathPrepend;exports.i = normalizePathPrepend;exports.n = findPathKey;exports.r = mergePathPrepend;exports.t = applyPathPrepend;var _nodePath = _interopRequireDefault(require("node:path"));function _interopRequireDefault(e) {return e && e.__esModule ? e : { default: e };}
//#region src/infra/path-prepend.ts
/**
* Find the actual key used for PATH in the env object.
* On Windows, `process.env` stores it as `Path` (not `PATH`),
* and after copying to a plain object the original casing is preserved.
*/
function findPathKey(env) {
  if ("PATH" in env) return "PATH";
  for (const key of Object.keys(env)) if (key.toUpperCase() === "PATH") return key;
  return "PATH";
}
function normalizePathPrepend(entries) {
  if (!Array.isArray(entries)) return [];
  const seen = /* @__PURE__ */new Set();
  const normalized = [];
  for (const entry of entries) {
    if (typeof entry !== "string") continue;
    const trimmed = entry.trim();
    if (!trimmed || seen.has(trimmed)) continue;
    seen.add(trimmed);
    normalized.push(trimmed);
  }
  return normalized;
}
function mergePathPrepend(existing, prepend) {
  if (prepend.length === 0) return existing;
  const partsExisting = (existing ?? "").split(_nodePath.default.delimiter).map((part) => part.trim()).filter(Boolean);
  const merged = [];
  const seen = /* @__PURE__ */new Set();
  for (const part of [...prepend, ...partsExisting]) {
    if (seen.has(part)) continue;
    seen.add(part);
    merged.push(part);
  }
  return merged.join(_nodePath.default.delimiter);
}
function removePathPrepend(existing, prepend) {
  if (!existing || prepend.length === 0) return existing;
  const prependEntries = new Set(prepend.map((part) => part.trim()).filter(Boolean));
  return (existing ?? "").split(_nodePath.default.delimiter).map((part) => part.trim()).filter(Boolean).filter((part) => !prependEntries.has(part)).join(_nodePath.default.delimiter);
}
function applyPathPrepend(env, prepend, options) {
  if (!Array.isArray(prepend) || prepend.length === 0) return;
  const pathKey = findPathKey(env);
  if (options?.requireExisting && !env[pathKey]) return;
  const merged = mergePathPrepend(env[pathKey], prepend);
  if (merged) env[pathKey] = merged;
}
//#endregion /* v9-634622482046970f */
