"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = clearSessionResetRuntimeState;exports.t = resolveResetPreservedSelection;var _agentScopeCtLXGcWm = require("./agent-scope-CtLXGcWm.js");
var _systemEvents11EG3LzK = require("./system-events-11EG3LzK.js");
var _queueDskPlua = require("./queue-DskPlua9.js");
//#region src/auto-reply/reply/session-reset-cleanup.ts
function clearSessionResetRuntimeState(keys) {
  const cleared = (0, _queueDskPlua.a)(keys);
  let systemEventsCleared = 0;
  for (const key of cleared.keys) systemEventsCleared += (0, _systemEvents11EG3LzK.r)(key).length;
  return {
    ...cleared,
    systemEventsCleared
  };
}
//#endregion
//#region src/config/sessions/reset-preserved-selection.ts
/**
* Decide which model/provider/auth overrides survive a `/new` or `/reset`.
*
* Only user-driven overrides (explicit `/model`, `sessions.patch`, etc.) are
* preserved. Auto-created overrides (runtime fallbacks, rate-limit rotations)
* are cleared so resets actually return the session to the configured default.
*
* Legacy entries persisted before `modelOverrideSource` was tracked are
* treated as user-driven, matching the prior reset behavior so explicit
* selections made before the source field existed are not silently dropped.
*/
function resolveResetPreservedSelection(params) {
  const { entry } = params;
  if (!entry) return {};
  const preserved = {};
  const recoveredAutoFallbackOverride = entry.modelOverrideSource === void 0 && (0, _agentScopeCtLXGcWm.C)(entry);
  if ((entry.modelOverrideSource === "user" || entry.modelOverrideSource === void 0 && Boolean(entry.modelOverride) && !recoveredAutoFallbackOverride) && entry.modelOverride) {
    preserved.providerOverride = entry.providerOverride;
    preserved.modelOverride = entry.modelOverride;
    preserved.modelOverrideSource = "user";
  }
  if (entry.authProfileOverrideSource === "user" && entry.authProfileOverride) {
    preserved.authProfileOverride = entry.authProfileOverride;
    preserved.authProfileOverrideSource = entry.authProfileOverrideSource;
    if (entry.authProfileOverrideCompactionCount !== void 0) preserved.authProfileOverrideCompactionCount = entry.authProfileOverrideCompactionCount;
  }
  return preserved;
}
//#endregion /* v9-04e70e55f970d5e6 */
