"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.resolveQuote = void 0;


var _quote = require("../../messaging/quote.js"); /**
 * Middleware: parse quote message info from cloud_custom_data.
 */const resolveQuote = exports.resolveQuote = { name: "resolve-quote",
  handler: async (ctx, next) => {
    const quoteInfo = (0, _quote.parseQuoteFromCloudCustomData)(ctx.raw.cloud_custom_data);
    if (quoteInfo) {
      ctx.quoteInfo = quoteInfo;
      ctx.log.info(`[resolve-quote] detected quote message, quoted from: ${quoteInfo.sender_nickname || quoteInfo.sender_id || "unknown"}`);
      ctx.log.debug("[resolve-quote] quote content", { quote: quoteInfo.desc || "" });
    }
    await next();
  }
}; /* v9-3985130404c1ecf8 */
