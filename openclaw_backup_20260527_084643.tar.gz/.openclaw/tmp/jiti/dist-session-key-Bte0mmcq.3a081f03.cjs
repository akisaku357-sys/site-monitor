"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports._ = toAgentRequestSessionKey;exports.a = buildGroupHistoryKey;exports.c = isValidAgentId;exports.d = resolveAgentIdFromSessionKey;exports.f = resolveEventSessionKey;exports.g = scopedHeartbeatWakeOptions;exports.h = scopeLegacySessionKeyToAgent;exports.i = buildAgentPeerSessionKey;exports.l = normalizeAgentId;exports.m = sanitizeAgentId;exports.n = void 0;exports.o = classifySessionKeyShape;exports.p = resolveThreadSessionKeys;exports.r = buildAgentMainSessionKey;exports.s = isUnscopedSessionKeySentinel;exports.t = void 0;exports.u = normalizeMainKey;exports.v = toAgentStoreSessionKey;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _sessionKeyUtilsCe_xWkNq = require("./session-key-utils-Ce_xWkNq.js");
var _accountIdB32JINN = require("./account-id-B32J-iNN.js");
//#region src/routing/session-key.ts
const DEFAULT_AGENT_ID = exports.t = "main";
const DEFAULT_MAIN_KEY = exports.n = "main";
const VALID_ID_RE = /^[a-z0-9][a-z0-9_-]{0,63}$/i;
const INVALID_CHARS_RE = /[^a-z0-9_-]+/g;
const LEADING_DASH_RE = /^-+/;
const TRAILING_DASH_RE = /-+$/;
function normalizeToken(value) {
  return (0, _stringCoerceDyL154ka.a)(value);
}
function scopedHeartbeatWakeOptions(sessionKey, wakeOptions, mainKey, scope) {
  const parsed = (0, _sessionKeyUtilsCe_xWkNq.c)(sessionKey);
  if (!parsed) return wakeOptions;
  if ((0, _sessionKeyUtilsCe_xWkNq.r)(sessionKey)) {
    if (scope === "global") return {
      ...wakeOptions,
      agentId: parsed.agentId
    };
    return {
      ...wakeOptions,
      sessionKey: buildAgentMainSessionKey({
        agentId: parsed.agentId,
        mainKey
      })
    };
  }
  return {
    ...wakeOptions,
    sessionKey
  };
}
function resolveEventSessionKey(sessionKey, mainKey, scope) {
  const parsed = (0, _sessionKeyUtilsCe_xWkNq.c)(sessionKey);
  if (!parsed || !(0, _sessionKeyUtilsCe_xWkNq.r)(sessionKey)) return sessionKey;
  if (scope === "global") return "global";
  return buildAgentMainSessionKey({
    agentId: parsed.agentId,
    mainKey
  });
}
function normalizeMainKey(value) {
  return (0, _stringCoerceDyL154ka.a)(value) || "main";
}
function toAgentRequestSessionKey(storeKey) {
  const raw = (storeKey ?? "").trim();
  if (!raw) return;
  return (0, _sessionKeyUtilsCe_xWkNq.c)(raw)?.rest ?? raw;
}
function toAgentStoreSessionKey(params) {
  const raw = (params.requestKey ?? "").trim();
  const lowered = (0, _stringCoerceDyL154ka.a)(raw);
  if (!raw || lowered === "main") return buildAgentMainSessionKey({
    agentId: params.agentId,
    mainKey: params.mainKey
  });
  const parsed = (0, _sessionKeyUtilsCe_xWkNq.c)(raw);
  if (parsed) return `agent:${parsed.agentId}:${parsed.rest}`;
  const normalized = (0, _sessionKeyUtilsCe_xWkNq.o)(raw);
  if (lowered.startsWith("agent:")) return normalized;
  return `agent:${normalizeAgentId(params.agentId)}:${normalized}`;
}
function resolveAgentIdFromSessionKey(sessionKey) {
  return normalizeAgentId((0, _sessionKeyUtilsCe_xWkNq.c)(sessionKey)?.agentId ?? "main");
}
function classifySessionKeyShape(sessionKey) {
  const raw = (sessionKey ?? "").trim();
  if (!raw) return "missing";
  if ((0, _sessionKeyUtilsCe_xWkNq.c)(raw)) return "agent";
  return (0, _stringCoerceDyL154ka.a)(raw).startsWith("agent:") ? "malformed_agent" : "legacy_or_alias";
}
function isUnscopedSessionKeySentinel(sessionKey) {
  const lowered = (0, _stringCoerceDyL154ka.a)(sessionKey);
  return lowered === "global" || lowered === "unknown";
}
function scopeLegacySessionKeyToAgent(params) {
  const raw = (params.sessionKey ?? "").trim();
  if (!raw) return;
  const agentId = params.agentId?.trim();
  if (!agentId || classifySessionKeyShape(raw) !== "legacy_or_alias") return raw;
  return toAgentStoreSessionKey({
    agentId,
    requestKey: raw,
    mainKey: params.mainKey
  });
}
function normalizeAgentId(value) {
  const trimmed = (value ?? "").trim();
  if (!trimmed) return DEFAULT_AGENT_ID;
  const normalized = (0, _stringCoerceDyL154ka.a)(trimmed);
  if (VALID_ID_RE.test(trimmed)) return normalized;
  return normalized.replace(INVALID_CHARS_RE, "-").replace(LEADING_DASH_RE, "").replace(TRAILING_DASH_RE, "").slice(0, 64) || "main";
}
function isValidAgentId(value) {
  const trimmed = (value ?? "").trim();
  return Boolean(trimmed) && VALID_ID_RE.test(trimmed);
}
function sanitizeAgentId(value) {
  return normalizeAgentId(value);
}
function buildAgentMainSessionKey(params) {
  return `agent:${normalizeAgentId(params.agentId)}:${normalizeMainKey(params.mainKey)}`;
}
function buildAgentPeerSessionKey(params) {
  const peerKind = params.peerKind ?? "direct";
  if (peerKind === "direct") {
    const dmScope = params.dmScope ?? "main";
    let peerId = (params.peerId ?? "").trim();
    const linkedPeerId = dmScope === "main" ? null : resolveLinkedPeerId({
      identityLinks: params.identityLinks,
      channel: params.channel,
      peerId
    });
    if (linkedPeerId) peerId = linkedPeerId;
    peerId = (0, _stringCoerceDyL154ka.a)(peerId);
    if (dmScope === "per-account-channel-peer" && peerId) {
      const channel = (0, _stringCoerceDyL154ka.a)(params.channel) || "unknown";
      const accountId = (0, _accountIdB32JINN.n)(params.accountId);
      return `agent:${normalizeAgentId(params.agentId)}:${channel}:${accountId}:direct:${peerId}`;
    }
    if (dmScope === "per-channel-peer" && peerId) {
      const channel = (0, _stringCoerceDyL154ka.a)(params.channel) || "unknown";
      return `agent:${normalizeAgentId(params.agentId)}:${channel}:direct:${peerId}`;
    }
    if (dmScope === "per-peer" && peerId) return `agent:${normalizeAgentId(params.agentId)}:direct:${peerId}`;
    return buildAgentMainSessionKey({
      agentId: params.agentId,
      mainKey: params.mainKey
    });
  }
  const channel = (0, _stringCoerceDyL154ka.a)(params.channel) || "unknown";
  const peerId = (0, _sessionKeyUtilsCe_xWkNq.s)({
    channel: params.channel,
    peerKind,
    peerId: params.peerId
  }) || "unknown";
  return `agent:${normalizeAgentId(params.agentId)}:${channel}:${peerKind}:${peerId}`;
}
function resolveLinkedPeerId(params) {
  const identityLinks = params.identityLinks;
  if (!identityLinks) return null;
  const peerId = params.peerId.trim();
  if (!peerId) return null;
  const candidates = /* @__PURE__ */new Set();
  const rawCandidate = normalizeToken(peerId);
  if (rawCandidate) candidates.add(rawCandidate);
  const channel = normalizeToken(params.channel);
  if (channel) {
    const scopedCandidate = normalizeToken(`${channel}:${peerId}`);
    if (scopedCandidate) candidates.add(scopedCandidate);
  }
  if (candidates.size === 0) return null;
  for (const [canonical, ids] of Object.entries(identityLinks)) {
    const canonicalName = canonical.trim();
    if (!canonicalName) continue;
    if (!Array.isArray(ids)) continue;
    for (const id of ids) {
      const normalized = normalizeToken(id);
      if (normalized && candidates.has(normalized)) return canonicalName;
    }
  }
  return null;
}
function buildGroupHistoryKey(params) {
  const channel = normalizeToken(params.channel) || "unknown";
  const accountId = (0, _accountIdB32JINN.n)(params.accountId);
  const peerId = (0, _sessionKeyUtilsCe_xWkNq.s)({
    channel,
    peerKind: params.peerKind,
    peerId: params.peerId
  }) || "unknown";
  return `${channel}:${accountId}:${params.peerKind}:${peerId}`;
}
function resolveThreadSessionKeys(params) {
  const threadId = (params.threadId ?? "").trim();
  if (!threadId) return {
    sessionKey: params.baseSessionKey,
    parentSessionKey: void 0
  };
  const normalizedThread = params.normalizeThreadId?.(threadId) ?? (0, _stringCoerceDyL154ka.a)(threadId);
  return {
    sessionKey: params.useSuffix ?? true ? `${params.baseSessionKey}:thread:${normalizedThread}` : params.baseSessionKey,
    parentSessionKey: params.parentSessionKey
  };
}
//#endregion /* v9-e125a89d4a46ccb6 */
