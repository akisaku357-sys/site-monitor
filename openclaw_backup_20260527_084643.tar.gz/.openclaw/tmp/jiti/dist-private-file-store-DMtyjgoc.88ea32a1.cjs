"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = privateFileStoreSync;exports.t = privateFileStore;require("./fs-safe-defaults-B7hUN42l.js");
var _fileStoreBcfkC1se = require("./file-store-BcfkC1se.js");
//#region src/infra/private-file-store.ts
function privateFileStore(rootDir) {
  return (0, _fileStoreBcfkC1se.t)({
    rootDir,
    private: true
  });
}
function privateFileStoreSync(rootDir) {
  return (0, _fileStoreBcfkC1se.n)({
    rootDir,
    private: true
  });
}
//#endregion /* v9-026049d92b0c5a86 */
