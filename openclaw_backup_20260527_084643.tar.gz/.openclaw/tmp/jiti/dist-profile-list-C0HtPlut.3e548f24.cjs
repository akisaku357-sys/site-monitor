"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = listProfilesForProvider;exports.t = dedupeProfileIds;var _providerAuthAliases4jqi6Djx = require("./provider-auth-aliases-4jqi6Djx.js");
//#region src/agents/auth-profiles/profile-list.ts
function dedupeProfileIds(profileIds) {
  return [...new Set(profileIds)];
}
function listProfilesForProvider(store, provider) {
  const providerKey = (0, _providerAuthAliases4jqi6Djx.r)(provider);
  return Object.entries(store.profiles).filter(([, cred]) => (0, _providerAuthAliases4jqi6Djx.r)(cred.provider) === providerKey).map(([id]) => id);
}
//#endregion /* v9-194fdb5632ccc9c2 */
