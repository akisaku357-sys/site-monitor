"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.registerGroupTools = registerGroupTools;







var _member = require("../../infra/cache/member.js");
var _logger = require("../../logger.js");
var _utils = require("../utils/utils.js"); /**
 * Group info tools.
 *
 * Contains:
 * - query_group_info: Query basic info of the current group (name, owner, member count)
 *
 * Fetches group info via the queryGroupInfo interface (WS protocol).
 */ /**
 * Create the query_group_info tool definition.
 *
 * Queries basic group info including name, owner (userId + nickname), and member count.
 */function createQueryGroupInfoTool(ctx) {const log = (0, _logger.createLog)("tools.group");if (!ctx.messageChannel?.includes('yuanbao')) return null;const sessionKey = ctx.sessionKey ?? "";const accountId = ctx.agentAccountId ?? "";
  return {
    name: "query_group_info",
    label: "Query Group Info",
    description: 'Query basic info about the current group (called "派/Pai" in the app), ' +
    "including group name, group owner, and member count.",
    parameters: {
      type: "object",
      properties: {},
      required: []
    },
    /**
     * Execute group info query.
     *
     * 1. No groupCode -> inform model no group context
     * 2. Call queryGroupInfo to get basic group info
     */
    async execute(toolCallId, _params) {
      log.debug("execute", { toolCallId });
      const groupCode = (0, _utils.extractGroupCode)(sessionKey);
      // 1. No groupCode -> cannot locate group
      if (!groupCode) {
        return (0, _utils.json)({
          success: false,
          msg: "No group context available, unable to query group info."
        });
      }
      // Get Member instance for current account
      const memberInst = (0, _member.getMember)(accountId);
      // 2. Call queryGroupInfo to get group info
      const groupInfo = await memberInst.queryGroupInfo(groupCode);
      if (!groupInfo) {
        return (0, _utils.json)({
          success: false,
          msg: "Failed to query group info. The API may be unavailable."
        });
      }
      return (0, _utils.json)({
        success: true,
        msg: "Group info retrieved.",
        note: 'The group is called "派 (Pai)" in the app.',
        groupInfo: {
          groupName: groupInfo.groupName,
          groupSize: groupInfo.groupSize,
          owner: {
            nickname: groupInfo.ownerNickName,
            userId: groupInfo.ownerUserId
          }
        }
      });
    }
  };
}
/**
 * Register all tools under the "group info" category.
 *
 * Currently contains:
 * - query_group_info: Query basic group info (always available)
 */
function registerGroupTools(api) {
  const log = (0, _logger.createLog)("tools.group");
  log.info("register tool", { name: "query_group_info", optional: false });
  api.registerTool(createQueryGroupInfoTool, { name: "query_group_info", optional: false });
} /* v9-2f87b47f63143473 */
