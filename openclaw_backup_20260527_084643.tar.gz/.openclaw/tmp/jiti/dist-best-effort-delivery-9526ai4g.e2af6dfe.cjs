"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = shouldDowngradeDeliveryToSessionOnly;exports.t = resolveExternalBestEffortDeliveryTarget;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
require("./message-channel-core-BoUoCGOD.js");
var _messageChannelCYCKkVrh = require("./message-channel-CYCKkVrh.js");
var _channelRouteL2PJXNE = require("./channel-route-L2PJ-xNE.js");
//#region src/infra/outbound/best-effort-delivery.ts
function resolveExternalBestEffortDeliveryTarget(params) {
  const normalizedChannel = (0, _messageChannelCYCKkVrh.u)(params.channel);
  const channel = normalizedChannel && (0, _messageChannelCYCKkVrh.s)(normalizedChannel) ? normalizedChannel : void 0;
  const to = (0, _stringCoerceDyL154ka.c)(params.to);
  const deliver = Boolean(channel && to);
  return {
    deliver,
    channel: deliver ? channel : void 0,
    to: deliver ? to : void 0,
    accountId: deliver ? (0, _stringCoerceDyL154ka.c)(params.accountId) : void 0,
    threadId: deliver && params.threadId != null && params.threadId !== "" ? (0, _channelRouteL2PJXNE.h)(params.threadId) : void 0
  };
}
function shouldDowngradeDeliveryToSessionOnly(params) {
  return params.wantsDelivery && params.bestEffortDeliver && params.resolvedChannel === "webchat";
}
//#endregion /* v9-a9f3691bba5e8ff9 */
