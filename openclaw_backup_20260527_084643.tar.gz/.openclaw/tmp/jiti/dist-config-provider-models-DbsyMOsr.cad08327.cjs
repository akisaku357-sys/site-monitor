"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.t = resolveImageCapableConfigProviderIds;var _providerIdBETgOIvU = require("./provider-id-BETgOIvU.js");
//#region src/media-understanding/config-provider-models.ts
function hasImageCapableModel(providerCfg) {
  return (providerCfg.models ?? []).some((model) => Array.isArray(model?.input) && model.input.includes("image"));
}
function resolveImageCapableConfigProviderIds(cfg) {
  const configProviders = cfg?.models?.providers;
  if (!configProviders || typeof configProviders !== "object") return [];
  const providerIds = [];
  for (const [providerKey, providerCfg] of Object.entries(configProviders)) {
    if (!providerKey?.trim() || !hasImageCapableModel(providerCfg)) continue;
    providerIds.push((0, _providerIdBETgOIvU.n)(providerKey));
  }
  return providerIds;
}
//#endregion /* v9-a50e2e28dea85b89 */
