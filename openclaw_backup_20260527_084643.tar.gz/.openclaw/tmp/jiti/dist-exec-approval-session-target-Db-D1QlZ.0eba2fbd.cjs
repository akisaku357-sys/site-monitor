"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.a = doesApprovalRequestMatchChannelAccount;exports.i = resolveExecApprovalSessionTarget;exports.n = resolveApprovalRequestSessionConversation;exports.o = resolveApprovalRequestAccountId;exports.r = resolveApprovalRequestSessionTarget;exports.s = resolveApprovalRequestChannelAccountId;exports.t = resolveApprovalRequestOriginTarget;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _sessionKeyUtilsCe_xWkNq = require("./session-key-utils-Ce_xWkNq.js");
var _accountIdB32JINN = require("./account-id-B32J-iNN.js");
var _messageChannelCYCKkVrh = require("./message-channel-CYCKkVrh.js");
var _pathsBg3PO6Gj = require("./paths-Bg3PO6Gj.js");
var _storeLoadZ4thf6ld = require("./store-load-z4thf6ld.js");
var _sessionConversationXHNnUnBT = require("./session-conversation-XHNnUnBT.js");
var _targetsSessionBPkKm7E = require("./targets-session-B-pkKm7E.js");
require("./targets-CNDTJ9IB.js");
//#region src/infra/approval-request-account-binding.ts
function normalizeOptionalChannel$1(value) {
  return (0, _messageChannelCYCKkVrh.u)(value);
}
function resolvePersistedApprovalRequestSessionEntry(params) {
  const sessionKey = (0, _stringCoerceDyL154ka.c)(params.request.request.sessionKey);
  if (!sessionKey) return null;
  const agentId = (0, _sessionKeyUtilsCe_xWkNq.c)(sessionKey)?.agentId ?? params.request.request.agentId ?? "main";
  const entry = (0, _storeLoadZ4thf6ld.t)((0, _pathsBg3PO6Gj.u)(params.cfg.session?.store, { agentId }), { maintenanceConfig: (0, _storeLoadZ4thf6ld.w)(params.cfg.session?.maintenance) })[sessionKey];
  if (!entry) return null;
  return {
    sessionKey,
    entry
  };
}
function resolvePersistedApprovalRequestSessionBinding(params) {
  const persisted = resolvePersistedApprovalRequestSessionEntry(params);
  if (!persisted) return null;
  const { entry } = persisted;
  const channel = normalizeOptionalChannel$1(entry.origin?.provider ?? entry.lastChannel);
  const accountId = (0, _accountIdB32JINN.r)(entry.origin?.accountId ?? entry.lastAccountId);
  return channel || accountId ? {
    channel,
    accountId
  } : null;
}
function resolveApprovalRequestAccountId(params) {
  const expectedChannel = normalizeOptionalChannel$1(params.channel);
  const turnSourceChannel = normalizeOptionalChannel$1(params.request.request.turnSourceChannel);
  if (expectedChannel && turnSourceChannel && turnSourceChannel !== expectedChannel) return null;
  const turnSourceAccountId = (0, _accountIdB32JINN.r)(params.request.request.turnSourceAccountId);
  if (turnSourceAccountId) return turnSourceAccountId;
  const sessionBinding = resolvePersistedApprovalRequestSessionBinding(params);
  const sessionChannel = sessionBinding?.channel;
  if (expectedChannel && sessionChannel && sessionChannel !== expectedChannel) return null;
  return sessionBinding?.accountId ?? null;
}
function resolveApprovalRequestChannelAccountId(params) {
  const expectedChannel = normalizeOptionalChannel$1(params.channel);
  if (!expectedChannel) return null;
  const turnSourceChannel = normalizeOptionalChannel$1(params.request.request.turnSourceChannel);
  if (!turnSourceChannel || turnSourceChannel === expectedChannel) return resolveApprovalRequestAccountId(params);
  const sessionBinding = resolvePersistedApprovalRequestSessionBinding(params);
  return sessionBinding?.channel === expectedChannel ? sessionBinding.accountId ?? null : null;
}
function doesApprovalRequestMatchChannelAccount(params) {
  const expectedChannel = normalizeOptionalChannel$1(params.channel);
  if (!expectedChannel) return false;
  const turnSourceChannel = normalizeOptionalChannel$1(params.request.request.turnSourceChannel);
  if (turnSourceChannel && turnSourceChannel !== expectedChannel) return false;
  const turnSourceAccountId = (0, _accountIdB32JINN.r)(params.request.request.turnSourceAccountId);
  const expectedAccountId = (0, _accountIdB32JINN.r)(params.accountId);
  if (turnSourceAccountId) return !expectedAccountId || expectedAccountId === turnSourceAccountId;
  const sessionBinding = resolvePersistedApprovalRequestSessionBinding(params);
  const sessionChannel = sessionBinding?.channel;
  if (sessionChannel && sessionChannel !== expectedChannel) return false;
  const boundAccountId = sessionBinding?.accountId;
  return !expectedAccountId || !boundAccountId || expectedAccountId === boundAccountId;
}
//#endregion
//#region src/infra/exec-approval-session-target.ts
function normalizeOptionalThreadValue(value) {
  if (typeof value === "number") return Number.isFinite(value) ? value : void 0;
  if (typeof value !== "string") return;
  const normalized = value.trim();
  return normalized ? normalized : void 0;
}
function isExecApprovalRequest(request) {
  return "command" in request.request;
}
function toExecLikeApprovalRequest(request) {
  if (isExecApprovalRequest(request)) return request;
  return {
    id: request.id,
    request: {
      command: request.request.title,
      sessionKey: request.request.sessionKey ?? void 0,
      turnSourceChannel: request.request.turnSourceChannel ?? void 0,
      turnSourceTo: request.request.turnSourceTo ?? void 0,
      turnSourceAccountId: request.request.turnSourceAccountId ?? void 0,
      turnSourceThreadId: request.request.turnSourceThreadId ?? void 0
    },
    createdAtMs: request.createdAtMs,
    expiresAtMs: request.expiresAtMs
  };
}
function normalizeOptionalChannel(value) {
  return (0, _messageChannelCYCKkVrh.u)(value);
}
function resolveApprovalRequestSessionConversation(params) {
  const sessionKey = (0, _stringCoerceDyL154ka.c)(params.request.request.sessionKey);
  if (!sessionKey) return null;
  const resolved = (0, _sessionConversationXHNnUnBT.n)(sessionKey, { bundledFallback: params.bundledFallback });
  if (!resolved) return null;
  const expectedChannel = normalizeOptionalChannel(params.channel);
  if (expectedChannel && normalizeOptionalChannel(resolved.channel) !== expectedChannel) return null;
  return {
    channel: resolved.channel,
    kind: resolved.kind,
    id: resolved.id,
    rawId: resolved.rawId,
    threadId: resolved.threadId,
    baseSessionKey: resolved.baseSessionKey,
    baseConversationId: resolved.baseConversationId,
    parentConversationCandidates: resolved.parentConversationCandidates
  };
}
function resolveExecApprovalSessionTarget(params) {
  if (!(0, _stringCoerceDyL154ka.c)(params.request.request.sessionKey)) return null;
  const persisted = resolvePersistedApprovalRequestSessionEntry({
    cfg: params.cfg,
    request: params.request
  });
  if (!persisted) return null;
  const target = (0, _targetsSessionBPkKm7E.t)({
    entry: persisted.entry,
    requestedChannel: "last",
    turnSourceChannel: (0, _stringCoerceDyL154ka.c)(params.turnSourceChannel),
    turnSourceTo: (0, _stringCoerceDyL154ka.c)(params.turnSourceTo),
    turnSourceAccountId: (0, _stringCoerceDyL154ka.c)(params.turnSourceAccountId),
    turnSourceThreadId: normalizeOptionalThreadValue(params.turnSourceThreadId)
  });
  if (!target.to) return null;
  return {
    channel: (0, _stringCoerceDyL154ka.c)(target.channel),
    to: target.to,
    accountId: (0, _stringCoerceDyL154ka.c)(target.accountId),
    threadId: normalizeOptionalThreadValue(target.threadId)
  };
}
function resolveApprovalRequestSessionTarget(params) {
  const execLikeRequest = toExecLikeApprovalRequest(params.request);
  return resolveExecApprovalSessionTarget({
    cfg: params.cfg,
    request: execLikeRequest,
    turnSourceChannel: execLikeRequest.request.turnSourceChannel ?? void 0,
    turnSourceTo: execLikeRequest.request.turnSourceTo ?? void 0,
    turnSourceAccountId: execLikeRequest.request.turnSourceAccountId ?? void 0,
    turnSourceThreadId: execLikeRequest.request.turnSourceThreadId ?? void 0
  });
}
function resolveApprovalRequestStoredSessionTarget(params) {
  const execLikeRequest = toExecLikeApprovalRequest(params.request);
  return resolveExecApprovalSessionTarget({
    cfg: params.cfg,
    request: execLikeRequest
  });
}
function resolveApprovalRequestOriginTarget(params) {
  if (!doesApprovalRequestMatchChannelAccount({
    cfg: params.cfg,
    request: params.request,
    channel: params.channel,
    accountId: params.accountId
  })) return null;
  const turnSourceTarget = params.resolveTurnSourceTarget(params.request);
  const expectedChannel = normalizeOptionalChannel(params.channel);
  const sessionTargetBinding = resolveApprovalRequestStoredSessionTarget({
    cfg: params.cfg,
    request: params.request
  });
  const sessionTarget = sessionTargetBinding && normalizeOptionalChannel(sessionTargetBinding.channel) === expectedChannel ? params.resolveSessionTarget(sessionTargetBinding) : null;
  if (turnSourceTarget && sessionTarget && !params.targetsMatch(turnSourceTarget, sessionTarget)) return null;
  return turnSourceTarget ?? sessionTarget ?? params.resolveFallbackTarget?.(params.request) ?? null;
}
//#endregion /* v9-ce893af1a21f63a5 */
